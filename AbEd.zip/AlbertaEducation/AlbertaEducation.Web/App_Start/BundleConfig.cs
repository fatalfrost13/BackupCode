﻿using System.Web.Optimization;

namespace AlbertaEducation.Web
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {

            //shared script bundles
            bundles.Add(new ScriptBundle("~/bundles/jQueryBundle").Include(
            "~/Scripts/jquery.min.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/jQueryUiBundle").Include(
            "~/Scripts/jquery-ui.min.js"
            ));

            //shared css bundles
            bundles.Add(new StyleBundle("~/bundles/mainCss").Include(
            "~/css/styles.css"
            ));

            //~/css/jquery-ui/themes/base/all.css   //does not like @import so we need to include all css manually and bundle
            bundles.Add(new StyleBundle("~/bundles/jQueryUiTheme").Include(
            //"~/css/jquery-ui/themes/base/base.css",
            "~/css/jquery-ui/themes/base/core.css",
            "~/css/jquery-ui/themes/base/accordion.css",
            "~/css/jquery-ui/themes/base/autocomplete.css",
            "~/css/jquery-ui/themes/base/button.css",
            "~/css/jquery-ui/themes/base/datepicker.css",
            "~/css/jquery-ui/themes/base/dialog.css",
            "~/css/jquery-ui/themes/base/draggable.css",
            "~/css/jquery-ui/themes/base/menu.css",
            "~/css/jquery-ui/themes/base/progressbar.css",
            "~/css/jquery-ui/themes/base/resizable.css",
            "~/css/jquery-ui/themes/base/selectable.css",
            "~/css/jquery-ui/themes/base/selectmenu.css",
            "~/css/jquery-ui/themes/base/sortable.css",
            "~/css/jquery-ui/themes/base/slider.css",
            "~/css/jquery-ui/themes/base/spinner.css",
            "~/css/jquery-ui/themes/base/tabs.css",
            "~/css/jquery-ui/themes/base/tooltip.css",
            "~/css/jquery-ui/themes/base/theme.css"
            ));

            //home css bundles
            bundles.Add(new StyleBundle("~/bundles/homeExternalCss").Include(
            "~/Css/font/materialIcons.css",
            "~/Css/jsTree/themes/default/jsTree.min.css",
            "~/css/MDL/material.css",
            "~/css/flexslider.css",
            "~/css/mobile.css",
            "~/Css/appConversions/appconversion.css"
            ));

            //home script bundles
            bundles.Add(new ScriptBundle("~/bundles/homeExternalJs").Include(
            "~/Scripts/jquery.flexslider.min.js",
            "~/Scripts/jquery.fitvid.min.js",
            "~/css/MDL/material.min.js",
            "~/Scripts/jwplayer/jwplayer.js"
            ));

            bundles.Add(new Bundle("~/bundles/homeUnminifiableJs").Include(
            "~/Scripts/froogaloop.min.js"
            ));

            //default css bundles
            bundles.Add(new StyleBundle("~/bundles/defaultExternalCss").Include(
            "~/Css/font/materialIcons.css",
            "~/Css/jsTree/themes/default/jsTree.min.css",
            "~/css/MDL/material.css",
            "~/css/MDL/magnific-popup.css",
            "~/css/flexslider.css",
            "~/css/timeline-new.css",
            "~/css/PollOption.css",
            "~/css/calendar.css",
            "~/css/accordion.css",
            "~/css/mobile.css",
            "~/Css/appConversions/appconversion.css"
            ));

            //default script bundles
            bundles.Add(new ScriptBundle("~/bundles/defaultExternalJs").Include(
            "~/Scripts/angular.min.js",
            "~/Scripts/modernizr.min.js",
            "~/Scripts/masonry.pkgd.min.js",
            "~/Scripts/jquery.flexslider.min.js",
            "~/Scripts/jquery.fitvid.min.js",
            "~/Scripts/moment.min.js",
            "~/Scripts/calendario/js/jquery.calendario.min.js",
            "~/css/MDL/material.min.js",
            "~/Scripts/tocca.js",
            "~/Scripts/jwplayer/jwplayer.js",
            "~/Scripts/iscroll.js",
            "~/Scripts/velocity.min.js"
            ));

            bundles.Add(new ScriptBundle("~/bundles/defaultCustomJs").Include(
            "~/Scripts/custom/app.js",
            "~/Scripts/project-timeline/timeline-locales.min.js",
            "~/Scripts/project-timeline/timeline-new.js"
            ));

            bundles.Add(new Bundle("~/bundles/defaultUnminifiableJs").Include(
            "~/Scripts/froogaloop.min.js",
            "~/Scripts/angular-animate.min.js",
            "~/Scripts/slick.js",
            "~/Scripts/ng-infinite-scroll.min.js",
            "~/Scripts/app/main.js",
            "~/Scripts/app/controller.js",
            "~/Scripts/app/services.js",
            "~/Scripts/app/filters.js",
            "~/Scripts/app/directives.js"
            ));
        }
    }
}
