﻿'use strict'

angular.module("umbraco").controller("Iomer.MultiTopicPickerController", function ($scope, dialogService, iconHelper, entityResource) {
    var currenturl = window.location.href;
    var nodeId = currenturl.split('/').pop();

    if (nodeId.indexOf("?") > 0) {
        nodeId = nodeId.split('?')[0];
    }
    if (nodeId.indexOf(" ") > 0) {
        nodeId = nodeId.split(' ')[0];
    }

    var url = "/umbraco/api/backoffice/GetTopicsByJourney/?journeyNodeId=" + nodeId;
            $.ajax({
                dataType: "json",
                type: "GET",
                url: url,
                async: false,
                success: function (data) {
                    $scope.topics = data;

                    var documentIds = []
                                    , mediaIds = []

                    $scope.renderModel = []

                    $scope.sortableOptions = { handle: '.handle' }

                    if ($scope.model.value) {
                        _.each($scope.model.value, function (item, i) {
                            $scope.renderModel.push(new Topic(item))
                            if (item.id) {
                                (item.isMedia ? mediaIds : documentIds).push(item.id)
                            }
                        })
                        $scope.$apply();
                    }

                    var setIcon = function (nodes) {
                        if (_.isArray(nodes)) {
                            _.each(nodes, setIcon)
                        } else {
                            var item = _.find($scope.renderModel, function (item) {
                                return +item.id === nodes.id
                            })
                            item.icon = iconHelper.convertFromLegacyIcon(nodes.icon);
                        }
                    }

                    entityResource.getByIds(documentIds, 'Document').then(setIcon)
                    entityResource.getByIds(mediaIds, 'Media').then(setIcon)

                    $scope.openTopicPicker = function () {
                        dialogService.contentPicker({
                            callback: $scope.onContentSelected,
                            entityType: "Document",
                            filter: function (value) { for (var i = 0; i < $scope.topics.length; i++) { if (value.id == $scope.topics[i]) { return false; } } return true; },
                            filterCssClass: "not-allowed not-published",
                            maxNumber: null,
                            minNumber: null,
                            multiPicker: true,
                            section: "content",
                            show: true,
                            showEditButton: false,
                            treeAlias: "content"
                        })
                    }

                    $scope.remove = function (index) {
                        $scope.renderModel.splice(index, 1)
                        $scope.model.value = $scope.renderModel
                    }

                    $scope.$watch(
                        function () {
                            return $scope.renderModel.length
                        }
                      , function (newVal) {
                          if ($scope.renderModel.length) {
                              $scope.model.value = $scope.renderModel
                          } else {
                              $scope.model.value = null
                          }
                      }
                    )

                    $scope.$on("formSubmitting", function (ev, args) {
                        if ($scope.renderModel.length) {
                            $scope.model.value = $scope.renderModel
                        } else {
                            $scope.model.value = null
                        }
                    })


                    $scope.onContentSelected = function (e) {
                        for (var i = 0; i < e.length; i++) {
                            var topic = new Topic(e[i]);
                            if (e[i].index != null) {
                                $scope.renderModel[e[i].index] = topic
                            } else {
                                $scope.renderModel.push(topic)
                            }

                            if (e[i].id && e[i].id > 0) {
                                entityResource.getById(e[i].id, 'Document').then(setIcon)
                            }

                            $scope.model.value = $scope.renderModel
                            dialogService.closeAll()
                        }
                    }

                    function Topic(topic) {
                        this.id = topic.id;
                        this.name = topic.name;
                        this.icon = topic.icon || topic.metaData.Icon;
                    }
                }
            });
})