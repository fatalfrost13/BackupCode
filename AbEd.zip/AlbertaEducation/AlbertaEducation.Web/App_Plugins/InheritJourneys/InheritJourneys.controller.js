﻿angular.module("umbraco")
    .controller("InheritJourneys.Controller",
        function($scope) {
            $scope.journeys = null;
            var url = window.location.href;
            var nodeId = url.split('/').pop();
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }

            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }

            var url = "/umbraco/api/backoffice/GetInheritItems/?nodeId=" + nodeId + "&alias=journeys";
            $.ajax({
                dataType: "json",
                type: 'GET',
                url: url,
                async: false,
                success: function(data) {
                    $scope.journeys = data;
                }
            });
});

