﻿angular.module("umbraco")
    .controller("WorkflowAction.Controller",
        function ($scope, $route, $timeout, notificationsService) {
            $scope.action = 0;
            $scope.notes = "";
            $scope.workflowActions = [];
            $scope.workflowGroups = [];
            $scope.selectedGroupId = null;
            $scope.loggedInUserGroups = [];
            $scope.loading = 0;
            $scope.currentUploadFile = '';
            $scope.rejectedAction = null;
            $scope.noWorkflowMessage = '';
            $scope.showWorkflowAction = false;

            var url = window.location.href;
            var nodeId = url.split('/').pop();
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }
            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }
            $scope.nodeId = nodeId;

            loadCurrentUploadFile();
            loadLoggedInUser();

            workflowSecurityLock();


            function loadCurrentUploadFile() {
                var url = "/umbraco/api/backoffice/GetCurrentUploadFile/?nodeId=" + nodeId;
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url
                }).done(function (data) {
                    //console.log(data);
                    $scope.currentUploadFile = data;
                });
            }

            function workflowSecurityLock() {
                var url = "/api/CustomWorkflow/GetIsUserInWorkflow/?nodeId=" + nodeId;
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url,
                    async: false,
                    error: function (jqxhr, status, error) {
                        console.log("Error getting workflow items: " + error);
                        var topInput = $(".umb-headline-editor-wrapper input[type=text].umb-headline");
                        topInput.after("<img src='/images/pencil.png' style='float:right;margin-top:-28px;margin-right:-60px'>");
                    }
                }).done(function (data) {
                    var topInput = $(".umb-headline-editor-wrapper input[type=text].umb-headline");
                    if (data == false) {
                        //do something to show that user can't edit
                        topInput.after("<img src='/images/pencil-off.png' style='float:right;margin-top:-28px;margin-right:-60px'>");
                    } else {
                        topInput.after("<img src='/images/pencil.png' style='float:right;margin-top:-28px;margin-right:-60px'>");
                    }
                });
            }

            function loadLoggedInUser() {

                var lStorage = sessionStorage.getItem("GetLoggedInUser")
                var initialLoggedInUser = null;
                if (lStorage != null) {
                    initialLoggedInUser = JSON.parse(sessionStorage.getItem("GetLoggedInUser"))
                }

                if (initialLoggedInUser == null) {
                    var url = "/umbraco/api/backoffice/GetLoggedInUser";
                    $.ajax({
                        dataType: "json",
                        type: 'GET',
                        url: url,
                        async: false,
                        success: function (data) {
                            sessionStorage.setItem("GetLoggedInUser", JSON.stringify(data));
                            loadLoggedInUserData(data)
                        },
                        error: function (jqxhr, status, error) {
                            console.log("Error getting logged in umbraco user: " + error);
                        }
                    });
                } else {
                    loadLoggedInUserData(initialLoggedInUser);
                }
            }

            function loadLoggedInUserData(data) {
                $scope.loggedInUserGroups = data.Groups;
                for (var i = 0; i < $scope.nextGroups.length; i++) {
                    for (var j = 0; j < $scope.loggedInUserGroups.length; j++) {
                        if ($scope.nextGroups[i] == $scope.loggedInUserGroups[j].EducationGroupName) {
                            $scope.workflowGroups.push($scope.loggedInUserGroups[j]);
                            if (!$scope.selectedGroupId) {
                                $scope.selectedGroupId = $scope.loggedInUserGroups[j].EducationGroupId;
                            }
                        }
                    }
                }
                loadWorkflowActions();
            }
            
            function loadWorkflowActions() {
                var url = "/umbraco/api/backoffice/GetWorkflowActions";
                $.ajax({
                        dataType : 'json',
                        type: 'GET',
                        url: url,
                        timeout: 60000, //60 second timeout
                        async: true,
                        contentType: 'application/json; charset=utf-8',
                        success: function (data) {

                            $scope.showWorkflowAction = true;
                            $scope.noWorkflowMessage = '';

                            if ($scope.workflowState.NodeId != nodeId) {
                                //workflow node not the same as current node. must be inheriting so do not show
                                $scope.showWorkflowAction = false;
                                $scope.noWorkflowMessage = 'No Workflow Action Available. Workflow is inherited.';
                            }

                            if ($scope.workflowState.CurrentLevel == 0) {
                                //No allowed actions
                                $scope.workflowActions = [];
                                $scope.showWorkflowAction = false;
                                $scope.noWorkflowMessage = 'No Workflow Action Available';
                                $scope.$apply();
                            }
                            else if ($scope.loggedInUserInCurrentLevel && $scope.workflowGroups.length > 0 && $scope.workflowState.CurrentLevel == $scope.baseLevel) {
                                //Allowed options: Approved 
                                var index = 0;
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].Alias == "Approved") {
                                        $scope.workflowActions[index] = data[i];
                                        index++;
                                    }
                                    if (data[i].Alias == "Rejected") {
                                        $scope.rejectedAction = data[i].Id
                                    }
                                }
                            }
                            else if (($scope.loggedInUserInCurrentLevel && $scope.workflowGroups.length == 0) || !$scope.loggedInUserInCurrentLevel && $scope.loggedInUserMinLevel > $scope.workflowState.CurrentLevel) {
                                //Allowed options: Reset
                                var index = 0;
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].Alias == "Reset") {
                                        $scope.workflowActions[index] = data[i];
                                        index++;
                                    }
                                    if (data[i].Alias == "Rejected") {
                                        $scope.rejectedAction = data[i].Id
                                    }
                                }
                            }
                            else if($scope.loggedInUserInCurrentLevel) {
                                //Allowed options: Approved, Rejected
                                var index = 0;
                                for (var i = 0; i < data.length; i++) {
                                    if (data[i].Alias == "Approved" || data[i].Alias == "Rejected") {
                                        $scope.workflowActions[index] = data[i];
                                        index++;
                                    }
                                    if (data[i].Alias == "Rejected") {
                                        $scope.rejectedAction = data[i].Id
                                    }
                                }
                            } else {
                                //logged in user not part of current level
                                $scope.workflowActions = [];
                                $scope.showWorkflowAction = false;
                                $scope.noWorkflowMessage = "Workflow currently not in your approval level. You may 'Save' this content to reset it to your level.";
                                $scope.$apply();
                            }
                        },
                            error : function (jqxhr, status, error) {
                        var foo = "Failed";
                    }
                });
            }

            $scope.submitWorkflowAction = function () {
                //$(".loading").show();
                $scope.loading = 1;

                //add check if node is dirty and display dialog if so
                var contentForm = angular.element('form[name=contentForm]').scope().contentForm;
                if (contentForm.$dirty) {
                    if (!notificationsService.hasView()) {
                        var msg = { view: "confirmsubmitworkflow", args: { action: $scope.action, notes: $scope.notes, selectedGroupId: $scope.selectedGroupId, level: $scope.level } };
                        notificationsService.add(msg);
                    }
                }
                else
                {
                    var uploadForm = $('form[name="contentForm"]');
                    var data = new FormData();
                    var files = $("#uploadFile").get(0).files;
                    if (files.length > 0) {
                        uploadForm.attr("enctype", "multipart/form-data");
                        uploadForm.attr("encoding", "multipart/form-data");
                        data.append("UploadedFile", files[0]);
                    }

                    var url = window.location.href;
                    var nodeId = url.split('/').pop();
                    var workflowAction = $scope.action;
                    var notes = $scope.notes;

                    var url = "/umbraco/api/backoffice/SubmitSendToPublish/?nodeId=" + nodeId + "&workflowAction=" + workflowAction;
                    if (notes.trim() !== "") {
                        url += "&notes=" + notes;
                    }
                    if ($scope.selectedGroupId) {
                        url += "&selectedGroupId=" + $scope.selectedGroupId;
                    }
                    if ($scope.level) {
                        url += "&level=" + $scope.level.Level;
                    }

                    $.ajax({
                        //dataType: "json",
                        type: 'POST',
                        url: url,
                        contentType: false,
                        processData: false,
                        data: data,
                        cache: false,
                        //async: false,
                        error: function (jqxhr, status, error) {
                            console.log("Error: " + error);
                        }
                    }).done(function (data)
                    {
                        //window.location.reload();
                        $route.reload();

                        //for some reason $route.reload() won't occur unless a click action on the screen occurs.
                        //otherwise it will just sit there with the loading image.
                        $("#notes").click();

                        if (data.ContinuePublishing == true) {
                            //check if treeview needs to be refreshed
                            UmbClientMgr.mainTree().reloadActionNode();
                        }
                        $scope.loading = 0;

                        
                    });
                }
                return false;
            }

            $scope.continue = function (not) {
                //$(".loading").show();
                $scope.loading = 1;

                var contentForm = angular.element('form[name=contentForm]').scope().contentForm;

                $scope.action = not.args.action;
                $scope.notes = not.args.notes;
                $scope.selectedGroupId = not.args.selectedGroupId;
                $scope.level = not.args.level;

                notificationsService.remove(not);
                var url = window.location.href;
                var nodeId = url.split('/').pop();
                var workflowAction = $scope.action;
                var notes = $scope.notes;

                var data = new FormData();
                var files = $("#uploadFile").get(0).files;
                if (files.length > 0) {
                    var uploadForm = $('form[name="contentForm"]');
                    uploadForm.attr("enctype", "multipart/form-data");
                    uploadForm.attr("encoding", "multipart/form-data");
                    data.append("UploadedFile", files[0]);
                }

                var url = "/umbraco/api/backoffice/SubmitSendToPublish/?nodeId=" + nodeId + "&workflowAction=" + workflowAction;
                if (notes.trim() !== "") {
                    url += "&notes=" + notes;
                }
                if ($scope.selectedGroupId) {
                    url += "&selectedGroupId=" + $scope.selectedGroupId;
                }
                if ($scope.level) {
                    url += "&level=" + $scope.level.Level;
                }
                var datetime = $.now();
                url += "&datetime=" + datetime;
                //console.log(url);

                $.ajax({
                    //dataType: "json",
                    type: 'POST',
                    url: url,
                    contentType: false,
                    processData: false,
                    data: data,
                    cache: false,
                    //async: false,
                    error: function (jqxhr, status, error) {
                        console.log("Error: " + error);
                    }
                }).done(function (data) {
                    $route.reload();

                    //for some reason $route.reload() won't occur unless a click action on the screen occurs.
                    //otherwise it will just sit there with the loading image.
                    $("#notes").click();    

                    if (data.ContinuePublishing == true) {
                        //check if treeview needs to be refreshed
                        UmbClientMgr.mainTree().reloadActionNode();
                    }

                    // $(".loading").hide();
                    $scope.loading = 0;
                });
            };

            $scope.cancel = function (not) {
                notificationsService.remove(not);
            };
        });