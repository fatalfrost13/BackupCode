﻿'use strict';

angular.module("umbraco")
    .controller("Iomer.MultiUserTypePickerController", function($scope, userService) {
        $scope.userTypes = null;

        if (!$scope.model.value) {
            $scope.model.value = [];
        }

        var url = "/umbraco/api/backoffice/GetUserTypes";
        $.ajax({
            dataType: "json",
            type: "GET",
            url: url,
            async: false,
            success: function(data) {
                $scope.userTypes = data.filter(function (userType) {
                    var typeFound = $scope.model.value.filter(function(selectedType) {
                        //Values in model.value will likely have a string for Value
                        //Values in data will likely have a number for Value
                        return userType.id == selectedType.id;
                    });
                    return typeFound.length === 0;
                });
            }
        });

        function swap(array, indexA, indexB) {
            var temp = array[indexA];
            array[indexA] = array[indexB];
            array[indexB] = temp;
        }

        function getSelectedValues(selectId) {
            var userTypeIds = [];
            $("#" + selectId + " option:selected").each(function (index, value) {
                userTypeIds.push(value.value);
            });
            return userTypeIds;
        }

        function getUserTypesById(types, ids) {
            return types.filter(function (userType) {
                return ids.indexOf(userType.id.toString()) > -1;
            });
        }

        function moveTypes(typesToMove, from, to) {
            $.each(typesToMove, function (index, value) {
                var fromIndex = from.indexOf(value);
                from.splice(fromIndex, 1);
                to.push(value);
            });
        }

        $scope.moveTypeUp = function() {
            var selected = getSelectedValues("selectedTypes");
            if (selected.length === 1) {
                var type = getUserTypesById($scope.model.value, selected);
                if (type.length === 1) {
                    var index = $scope.model.value.indexOf(type[0]);
                    if (index > 0) {
                        swap($scope.model.value, index, index - 1);
                    }
                }
            }
        }

        $scope.moveTypeDown = function() {
            var selected = getSelectedValues("selectedTypes");
            if (selected.length === 1) {
                var type = getUserTypesById($scope.model.value, selected);
                if (type.length === 1) {
                    var index = $scope.model.value.indexOf(type[0]);
                    if (index < $scope.model.value.length - 1) {
                        swap($scope.model.value, index, index + 1);
                    }
                }
            }
        }

        $scope.selectUserTypes = function() {
            var userTypeIds = getSelectedValues("userTypes");
            var userTypesToMove = getUserTypesById($scope.userTypes, userTypeIds);
            moveTypes(userTypesToMove, $scope.userTypes, $scope.model.value);

        }

        $scope.deselectUserType = function() {
            var userTypeIds = getSelectedValues("selectedTypes");
            var userTypesToMove = getUserTypesById($scope.model.value, userTypeIds);
            moveTypes(userTypesToMove, $scope.model.value, $scope.userTypes);
        }
});