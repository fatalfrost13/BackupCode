﻿angular.module("umbraco")
    .controller("WorkflowProgress.Controller",
        function ($scope, $http, $timeout, userService) {
            $scope.workflowState = null;
            $scope.loggedInUser = null;
            $scope.levels = [];
            $scope.workflowMessage = null;

            var url = window.location.href;
            var nodeId = url.split('/').pop();
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }

            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }

            $scope.nodeId = nodeId;

            loadWorkflowState();
            loadLoggedInUser();

            $timeout(function () {
                ($("a[rel='popover']")).popover({ html: true, animation: false })
            }, 100);

            function loadLoggedInUser() {

                var lStorage = sessionStorage.getItem("GetLoggedInUser")
                var initialLoggedInUser = null;
                if (lStorage != null) {
                    initialLoggedInUser = JSON.parse(sessionStorage.getItem("GetLoggedInUser"))
                }
                if (initialLoggedInUser == null) {
                    var url = "/umbraco/api/backoffice/GetLoggedInUser";
                    $.ajax({
                        dataType: "json",
                        type: 'GET',
                        url: url,
                        async: false,
                        success: function (data) {
                            sessionStorage.setItem("GetLoggedInUser", JSON.stringify(data));
                            $scope.loggedInUser = data;
                        },
                        error: function (jqxhr, status, error) {
                            console.log("Error getting logged in umbraco user: " + error)
                        }
                    });
                } else {
                    $scope.loggedInUser = initialLoggedInUser;
                }
            }

            function loadWorkflowState() {
                var url = "/api/CustomWorkflow/GetWorkflow/?id=" + nodeId + "&inherited=true&loadUsers=true";
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url,
                    async: false,
                    success: function (data) {
                        $scope.workflowState = data;
                        loadLevels();
                        if (nodeId != data.NodeId) {
                            //workflow exists on a higher level node.
                            var url = "/api/CustomWorkflow/GetNoWorkflowMessage/?nodeId=" + nodeId;
                            $.ajax({
                                dataType: "json",
                                type: 'GET',
                                url: url,
                                async: false,
                                success: function (data) {
                                    $scope.workflowMessage = data;
                                    //console.log(data);
                                },
                                error: function (jqxhr, status, error) {
                                    console.log("Error getting workflow progress message: " + error);
                                }
                            });
                        }

                    },
                    error: function (jqxhr, status, error) {
                        console.log("Error getting workflow state: " + error);
                    }
                });
            };

            function loadLevels() {
                for (var i = $scope.workflowState.ApprovalLevels.length - 1; i >= 0 ; --i) {
                    $scope.workflowState.ApprovalLevels[i].InProgress = $scope.workflowState.ApprovalLevels[i].Level >= $scope.workflowState.CurrentLevel;
                    $scope.levels.push($scope.workflowState.ApprovalLevels[i]);
                }
                //console.log($scope.levels);
                //console.log($scope.workflowState.CurrentLevel)
            }
        });


