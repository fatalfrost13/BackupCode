﻿'use strict';

angular.module("umbraco")
    .controller("WorkflowHistory.Controller",
        function ($scope, $http, userService) {

            $scope.workflowActions = null;
            $scope.workflowStatuses = null;
            $scope.users = null;
            $scope.groups = null;
            $scope.userTypes = null;
            
            $scope.workflowHistoryItems = null;
            $scope.selectedUserTypes = null;
            $scope.currentStatus = "";
            $scope.lastUserType = null;
            $scope.lastUserTypeIndex = null;
            $scope.loggedInUser = null;
            $scope.loggedInUserMinLevel = null;
            $scope.loggedInUserInCurrentLevel = false;
            $scope.nextUserType = null;
            $scope.showWorkflowAction = false;

            $scope.nextGroups = [];
            $scope.nextGroupsString = null;

            $scope.top = false;

            $scope.workflowState = null;
            $scope.baseLevel = null;
            $scope.levels = [];
            $scope.level = null;

            $scope.currentPage = 0;
            $scope.pageSize = 10;
            $scope.numberOfPages = function () {
                return Math.ceil($scope.workflowHistoryItems.length / $scope.pageSize);
            }

            initialize();

            var url = window.location.href;
            var nodeId = url.split('/').pop();
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }

            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }

            $scope.nodeId = nodeId;

            loadWorkflowState();
            loadLoggedInUser();
            loadWorkflowHistory();

            if ($scope.workflowState.NodeId != nodeId) {
                $scope.workflowHistoryItems = [];
            }
            
            function loadWorkflowHistory() {
                var url = "/umbraco/api/backoffice/GetWorkflowHistoryItems/?nodeId=" + nodeId;
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url,
                    async: false,
                    error: function (jqxhr, status, error) {
                        console.log("Error getting workflow items: " + error);
                    }
                }).done(function (data) {
                    for (var i = 0; i < data.length; i++) {
                        data[i].isUser = false;
                        if (data[i].UserId == $scope.loggedInUser.id) {
                            data[i].isUser = true;
                        }
                        data[i].isGroup = false;
                        for (var j = 0; j < $scope.loggedInUserGroups.length; j++) {
                            if (data[i].EducationGroupId == $scope.loggedInUserGroups[j].EducationGroupId) {
                                data[i].isGroup = true;
                            }
                        }

                    }
                    $scope.workflowHistoryItems = data;
                });

            }

            function loadLoggedInUser() {

                var lStorage = sessionStorage.getItem("GetLoggedInUser")
                var initialLoggedInUser = null;
                if (lStorage != null) {
                    initialLoggedInUser = JSON.parse(sessionStorage.getItem("GetLoggedInUser"))
                }

                if (initialLoggedInUser == null) {
                    var url = "/umbraco/api/backoffice/GetLoggedInUser";
                    $.ajax({
                        dataType: "json",
                        type: 'GET',
                        url: url,
                        async: false,
                        error: function (jqxhr, status, error) {
                            console.log("Error getting logged in umbraco user: " + error)
                        }
                    }).done(function (data) {
                        sessionStorage.setItem("GetLoggedInUser", JSON.stringify(data));
                        loadLoggedInUserData(data);
                    });
                } else
                {
                    loadLoggedInUserData(initialLoggedInUser);
                }

                var url = "/umbraco/api/backoffice/GetUserLevels/?nodeId=" + nodeId;
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url,
                    async: false,
                    error: function (jqxhr, status, error) {
                        console.log("Error getting workflow items: " + error);
                    }
                }).done(function (data) {
                    if (data.length > 0) {
                        $scope.showWorkflowAction = true;
                        $scope.loggedInUserMinLevel = Math.min.apply(Math, data);
                        $scope.loggedInUserInCurrentLevel = data.indexOf($scope.workflowState.CurrentLevel) > -1;
                    }
                });
            }

            function loadLoggedInUserData(data)
            {
                $scope.loggedInUser = data;
                $scope.loggedInUserGroups = data.Groups;
            }

            
            //function loadCurrentStatus() {
            //    var url = "/umbraco/api/backoffice/GetCurrentStatus/?nodeId=" + nodeId + "&top=" + $scope.top;
            //    $.ajax({
            //        dataType: "json",
            //        type: 'GET',
            //        url: url,
            //        //async: false,
            //        error: function (jqxhr, status, error) {
            //            console.log("Error getting current status: " + error);
            //        }
            //    }).done(function (data) {
            //        $scope.currentStatus = data.Alias;
            //    });
            //};

            function loadWorkflowState() {
                var url = "/api/CustomWorkflow/GetWorkflow/" + nodeId;
                $.ajax({
                    dataType: "json",
                    type: 'GET',
                    url: url,
                    async: false,
                    error: function (jqxhr, status, error) {
                        console.log("Error getting workflow state: " + error);
                    }
                }).done(function (data) {
                    $scope.workflowState = data;
                    loadNextGroups();
                    loadLevels();
                });
            };

            function loadNextGroups() {
                var currentLevel = $scope.workflowState.CurrentLevel;
                var approvalLevels = $scope.workflowState.ApprovalLevels;
                $scope.nextGroups = [];
                if (currentLevel == 0) {
                    for (var i = 0; i < approvalLevels.length; i++) {
                        for (var j = 0; j < approvalLevels[i].ApprovalGroup.length; j++) {
                            $scope.nextGroups.push(approvalLevels[i].ApprovalGroup[j].EducationGroupName);
                        }
                    }
                }
                else {
                    for (var i = 0; i < approvalLevels.length; i++) {
                        if (approvalLevels[i].Level == currentLevel) {
                            for (var j = 0; j < approvalLevels[i].ApprovalGroup.length; j++) {
                                if (approvalLevels[i].ApprovalGroup[j].CurrentAction != "Approved") {
                                    $scope.nextGroups.push(approvalLevels[i].ApprovalGroup[j].EducationGroupName);
                                }
                            }
                        }
                    }
                }                

                $scope.nextGroupsString = $scope.nextGroups.join(', ');
            }

            function loadLevels() {
                //var topLevel = 0;
                $scope.baseLevel = Math.max.apply(Math, $scope.workflowState.ApprovalLevels.map(function (o) { return o.Level; }))
                for (var i = 0; i < $scope.workflowState.ApprovalLevels.length; i++) {
                    if ($scope.workflowState.ApprovalLevels[i].Level > $scope.workflowState.CurrentLevel) {
                        $scope.levels.push($scope.workflowState.ApprovalLevels[i]);
                    }
                }
                $scope.level = null;
                for (var j = 0; j < $scope.levels.length; j++){
                    if ($scope.level == null || $scope.levels[j].Level < $scope.level.Level) {
                        $scope.level = $scope.levels[j];
                    }
                }
            }

            function initialize() {

                var lStorage = sessionStorage.getItem("WorkflowInitialState")
                var initialData = null;
                if (lStorage != null) {
                    initialData = JSON.parse(sessionStorage.getItem("WorkflowInitialState"))
                }

                if (initialData == null) {
                    //initial state, load everything in here
                    var url = "/umbraco/api/backoffice/GetWorkflowInitialState";
                    $.ajax({
                        dataType: 'json',
                        type: 'GET',
                        url: url,
                        timeout: 60000, //60 second timeout
                        async: false,
                        contentType: 'application/json; charset=utf-8',
                        error: function (jqxhr, status, error) {
                            console.log("Error getting workflow actions: " + error);
                        }
                    }).done(function (data) {
                        sessionStorage.setItem("WorkflowInitialState", JSON.stringify(data));
                        loadWorkflowData(data);
                    });
                } else {
                    var data = initialData;
                    loadWorkflowData(data);
                }

            };

            function loadWorkflowData(data)
            {
                $scope.workflowActions = data.WorkflowActionList;
                $scope.workflowStatuses = data.WorkflowStatusList;
                $scope.userTypes = data.UserTypeList;
                $scope.users = data.UserList;
                $scope.groups = data.GroupList;

                $scope.prevPage = function () {
                    if ($scope.currentPage != 0) {
                        $scope.currentPage = $scope.currentPage - 1;
                    }
                }
                $scope.nextPage = function () {
                    if ($scope.currentPage < ($scope.workflowHistoryItems.length / $scope.pageSize - 1)) {
                        $scope.currentPage = $scope.currentPage + 1;
                    }
                }

                $scope.setPage = function () {
                    $scope.currentPage = this.n;
                };
            }
        })

    .filter('displayAction', function ($filter) {
        return function (action, actions) {
            var i = 0;
            if (actions) {
                for (; i < actions.length; i++) {
                    if (actions[i].Id == action) {
                        return actions[i].Alias;
                    }
                }
            }
            return "";
        };
    })

    .filter('displayStatus', function ($filter) {
        return function (status, statuses) {
            var i = 0;
            for (; i < statuses.length; i++) {
                if (statuses[i].Id == status) {
                    return statuses[i].Alias;
                }
            }
            return "";
        };
    })

    .filter('displayUserType', function ($filter) {
        return function (userType, userTypes) {
            var i = 0;
            for (; i < userTypes.length; i++) {
                if (userTypes[i].Id == userType) {
                    return userTypes[i].userTypeName;
                }
            }
            return "";
        };
    })

    .filter('displayUser', function ($filter) {
        return function (user, users) {
            var i = 0;
            for (; i < users.length; i++) {
                if (users[i].id == user) {
                    return users[i].userName;
                }
            }
            return "";
        };
    })

    .filter('displayGroup', function ($filter) {
        return function (group, groups) {
            var i = 0;
            for (; i < groups.length; i++) {
                if (groups[i].Id == group) {
                    return groups[i].Name;
                }
            }
            return "";
        };
    })

    .filter('startFrom', function () {
        return function (input, start) {
            start = +start; //parse to int
            return input.slice(start);
        };
    })

    .filter('range', function() {
        return function(input, total) {
            total = parseInt(total);

            for (var i=0; i<total; i++) {
                input.push(i);
            }

            return input;
        };
    })

    .filter('moment', function () {
        return function (dateString, format) {
            return moment(dateString).format(format);
        };
    });


