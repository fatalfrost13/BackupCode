﻿'use strict'

angular.module("umbraco").controller("Iomer.CommentApprover", function ($scope, $http, notificationsService) {
    var currenturl = window.location.href;
    var nodeId = currenturl.split('/').pop();

    if (nodeId.indexOf("?") > 0) {
        nodeId = nodeId.split('?')[0];
    }
    if (nodeId.indexOf(" ") > 0) {
        nodeId = nodeId.split(' ')[0];
    }

    $scope.comments = [];

    function LoadComments() {
        var url = "/umbraco/api/backoffice/GetBlogComments/?blogItemId=" + nodeId;
        $http.get(url).then(function (data) {
            $scope.comments = data.data;
            for (var i = 0; i < $scope.comments; i++) {
                $scope.comments[i].selected = false;
            }
        });
    }
    LoadComments();

    $scope.commentStatus = function(comment) {
        if (comment.RequiresApproval) {
            return "Awaiting Moderation";
        } else {
            return comment.Approved ? "Approved" : "Denied";
        }
    }

    $scope.selectedStatus = 'Awaiting Moderation';
    $scope.statusFilter = function (comment) {
        if ($scope.selectedStatus == 'Awaiting Moderation') {
            return comment.RequiresApproval;
        } else if (comment.RequiresApproval) {
            return false;
        } else if ($scope.selectedStatus == "Approved") {
            return comment.Approved;
        } else if ($scope.selectedStatus == "Denied") {
            return !comment.Approved;
        }
        return false;
    }  

    $scope.approveComment = function(comment) {
        comment.Approved = true;
        ModerateBlogComment(comment);
    }

    $scope.denyComment = function (comment) {
        comment.Approved = false;
        ModerateBlogComment(comment);
    }

    $scope.approveSelected = function () {
        var currentComments = $scope.comments.filter(function (comment) {
            return comment.selected;
        });
        for (var i = 0; i < currentComments.length; i++) {
            currentComments[i].Approved = true;
        }
        ModerateBlogComments(currentComments);
    }

    $scope.denySelected = function () {
        var currentComments = $scope.comments.filter(function (comment) {
            return comment.selected;
        });
        for (var i = 0; i < currentComments.length; i++) {
            currentComments[i].Approved = false;
        }
        ModerateBlogComments(currentComments);
    }

    function ModerateBlogComment(comment) {
        var url = "/umbraco/api/backoffice/ModerateBlogComment/";
        $http.post(url, comment)
            .then(function (result) {
                notificationsService.success("Comment Moderation succesful");
                LoadComments();
            }).error(function () { notificationsService.success("Comment Moderation failed") });
    }

    function ModerateBlogComments(comments) {
        if (comments.length > 0) {
            var url = "/umbraco/api/backoffice/ModerateBlogComments/";
            $http.post(url, comments)
                .then(function (result) {
                    notificationsService.success("Comment Moderation succesful");
                    LoadComments();
                }).error(function () { notificationsService.success("Comment Moderation failed") });
        }        
    }

    $scope.selectAllComments = false;
    $scope.selectAll = function () {
        for (var i = 0; i < $scope.comments.length; i++) {
            if ($scope.statusFilter($scope.comments[i])) {
                $scope.comments[i].selected = $scope.selectAllComments;
            }            
        }
    }

    $scope.$watch('selectedStatus', function () {
        for (var i = 0; i < $scope.comments.length; i++) {
            $scope.comments[i].selected = false;
        }
        $scope.selectAllComments = false;
    });
})