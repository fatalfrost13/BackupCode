﻿angular.module("umbraco")
    .controller("InheritMetaKeywords.Controller",
        function ($scope) {
            
            $scope.language = null;
            var url = window.location.href;
            var nodeId = url.split('/').pop();
            
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }
            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }

            var url = "/umbraco/api/backoffice/GetInheritStrings/?nodeId=" + nodeId + "&alias=metaKeywords";
            $.ajax({
                dataType: "json",
                type: 'GET',
                url: url,
                async: false,
                success: function (data) {
                    $scope.metaKeywords = data;
                }
            });
});

