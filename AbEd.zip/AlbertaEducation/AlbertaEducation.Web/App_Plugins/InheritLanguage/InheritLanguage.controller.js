﻿angular.module("umbraco")
    .controller("InheritLanguage.Controller",
        function ($scope) {
            
            $scope.language = null;
            var url = window.location.href;
            var nodeId = url.split('/').pop();
            
            if (nodeId.indexOf("?") > 0) {
                nodeId = nodeId.split('?')[0];
            }
            if (nodeId.indexOf(" ") > 0) {
                nodeId = nodeId.split(' ')[0];
            }
            if (isNaN(nodeId)) {
                nodeId = 0;
                return;
            }

            var url = "/umbraco/api/backoffice/GetInheritField/?nodeId=" + nodeId + "&alias=language";
            $.ajax({
                dataType: "json",
                type: 'GET',
                url: url,
                async: false,
                success: function (data) {
                    $scope.language = data.Text;
                }
            });
});

