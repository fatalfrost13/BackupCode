﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.AuthoritiesAndSchoolsDirectorySearch.Controllers
{
    public class AuthoritiesAndSchoolsDirectoryController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] AuthoritiesAndSchoolsDirectory.SearchRequest searchRequest)
        {
            try
            {
                var authoritiesAndSchoolsDirectory = new AuthoritiesAndSchoolsDirectory.AuthoritiesAndSchoolsDirectory();
                var results = authoritiesAndSchoolsDirectory.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on AuthoritiesAndSchoolsDirectoryController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchAuthorityOrSchool([FromBody]AuthoritiesAndSchoolsDirectory.SearchRequest searchRequest)
        {
            try
            {
                var authoritiesAndSchoolsDirectory = new AuthoritiesAndSchoolsDirectory.AuthoritiesAndSchoolsDirectory();
                var results = authoritiesAndSchoolsDirectory.FetchAuthorityOrSchool(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;

            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on AuthoritiesAndSchoolsDirectoryController.FetchAuthorityOrSchool().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}