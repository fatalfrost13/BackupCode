﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.JurisdictionFactSheet.Controllers
{
    public class JurisdictionFactSheetController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] JurisdictonFactsheets.SearchRequest searchRequest)
        {
            try
            {
                var jurisdictionFactSheet = new JurisdictonFactsheets.JurisdictionFactSheet();
                var results = jurisdictionFactSheet.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on JurisdictionFactSheetController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchPdfUrls([FromBody] JurisdictonFactsheets.PdfUrlsRequest pdfUrlsRequest)
        {
            try
            {
                var jurisdictionFactSheet = new JurisdictonFactsheets.JurisdictionFactSheet();
                var results = jurisdictionFactSheet.FetchPdfUrls(pdfUrlsRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on JurisdictionFactSheetController.PdfUrlsRequest().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}