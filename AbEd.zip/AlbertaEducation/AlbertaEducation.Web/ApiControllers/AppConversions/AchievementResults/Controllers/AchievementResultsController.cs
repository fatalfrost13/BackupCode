﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.AchievementResults.Controllers
{
    public class AchievementResultsController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] AchievementTestResults.SearchRequest searchRequest)
        {
            try
            {
                var achievementTestResults = new AchievementTestResults.AchievementTestResults();
                var results = achievementTestResults.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on AchievementResultsController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchPdfUrls([FromBody] AchievementTestResults.PdfUrlsRequest pdfUrlsRequest)
        {
            try
            {
                var achievementTestResults = new AchievementTestResults.AchievementTestResults();
                var results = achievementTestResults.FetchPdfUrls(pdfUrlsRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on AchievementResultsController.FetchPdfUrls().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}