﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.DiplomaExamination.Controllers
{
    public class DiplomaSearchController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] DiplomaSearch.SearchRequest diplomaSearchRequest)
        {
            try
            {
                var diplomaSearch = new DiplomaSearch.DiplomaSearch();
                var results = diplomaSearch.Fetch(diplomaSearchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on DiplomaSearchController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchPdfUrls([FromBody] DiplomaSearch.PdfUrlsRequest pdfUrlsRequest)
        {
            try
            {
                var diplomaSearch = new DiplomaSearch.DiplomaSearch();
                var results = diplomaSearch.FetchPdfUrls(pdfUrlsRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;

            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on DiplomaSearchController.FetchPdfUrls().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}