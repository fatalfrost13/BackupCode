﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Web.WebApi;
using System.Linq;
using Persits.PDF;
using System.Collections;
using System.Data;
using System.Net.Http.Headers;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace AlbertaEducation.Web.AppConversions.ElectionsForm.Controllers
{
    public class ElectionsFormController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage GetPDF(JToken jsonbody)
        {
            // generate pdf template
            //var myPDF = TestPDF(jsonbody.ToString());
            string fileName = "ElectionsFormA_Template.pdf";
            var myBlob = GeneratePDF(jsonbody.ToString(), fileName);

            // return file to client
            if (myBlob != null)
                return FileAsAttachment(myBlob, fileName);
            return new HttpResponseMessage(HttpStatusCode.NotFound);
        }

        public static HttpResponseMessage FileAsAttachment(byte[] pdfBlob, string fileName)
        {
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new ByteArrayContent(pdfBlob);
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/pdf");
            result.Content.Headers.ContentDisposition = new ContentDispositionHeaderValue("attachment");
            result.Content.Headers.ContentDisposition.FileName = fileName;
            return result;
        }
        
        private byte[] GeneratePDF(string data, string fileName)
        {
            int RowIndex = 0;
            PdfManager oPDF = new PdfManager();
            PdfDocument oDoc = default(PdfDocument);
            ArrayList DocArray = new ArrayList();
            int t = 0;
            PdfDocument oDocEdited = default(PdfDocument);
            string Address = null;
            //DataSet dsElection = default(DataSet);

            const int EntriesPerPage = 5;

            //int EntriesCount = dsElection.ElectionsTable.Rows.Count();
            JArray jsonVal = JArray.Parse(data) as JArray;
            int EntriesCount = jsonVal.Count();
            int NoOfPages = (EntriesCount / EntriesPerPage) + (1 - (1 / EntriesPerPage));
            int z = 0;
            DataRow oRow = null;
            //DataView SortedDV = new DataView(dsElection.Tables[0]);
            DataView SortedDV = new DataView(JsonConvert.DeserializeObject<DataTable>(jsonVal.ToString()));
            DataTable SortedDT = null;
            string Authority = "";
            SortedDV.Sort = "subdivision,votes DESC";

            SortedDT = SortedDV.ToTable();

            byte[] FileBlob = null;

            for (t = 1; t <= NoOfPages; t++)
            {

                oDoc = oPDF.OpenDocument(System.Web.HttpContext.Current.Server.MapPath("../../ApiControllers/AppConversions/ElectionsForm/PDFTemplates/" + fileName));

                for (z = 1; z <= 5; z++)
                {

                    try
                    {
                        //oRow = dsElection.ElectionsTable.Rows(RowIndex)
                        oRow = SortedDT.Rows[RowIndex];

                    }
                    catch
                    {
                        oRow = null;
                    }


                    if ((oRow != null))
                    {
                        var _with1 = oRow;

                        if (RowIndex == 0)
                        {
                            Authority = oRow["authority"].ToString();
                        }

                        if (z == 1)
                        {
                            SetReadOnlyPDFField(ref oDoc, "Authority", Authority);
                            SetReadOnlyPDFField(ref oDoc, "Maxpage", "Page " + t + " of " + NoOfPages);

                        }

                        SetReadOnlyPDFField(ref oDoc, ("sub" + z), oRow["subdivision"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("votes" + z), oRow["votes"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("elect" + z), oRow["elected"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("inc" + z), oRow["incumbent"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("gend" + z), oRow["gender"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("name" + z), oRow["name"].ToString());

                        Address = oRow["address"].ToString() + System.Environment.NewLine;
                        //if (!string.IsNullOrEmpty(oRow.Field<string>("Address2")))
                        //    Address += oRow.Field<string>("Address2") + System.Environment.NewLine;
                        Address += oRow["city"].ToString() + ", " + oRow["province"].ToString() + System.Environment.NewLine + oRow["postalCode"].ToString();

                        if (oRow["name"].ToString() == "vacant")
                            Address = "";

                        SetReadOnlyPDFField(ref oDoc, ("add" + z), Address);
                        SetReadOnlyPDFField(ref oDoc, ("phone" + z), oRow["phone"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("fax" + z), oRow["fax"].ToString());
                        SetReadOnlyPDFField(ref oDoc, ("email" + z), oRow["email"].ToString());


                    }
                    else {
                        //Set the fields to empty and lock them 
                        SetReadOnlyPDFField(ref oDoc, ("sub" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("votes" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("elect" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("inc" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("gend" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("name" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("add" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("phone" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("fax" + z), "");
                        SetReadOnlyPDFField(ref oDoc, ("email" + z), "");

                    }

                    RowIndex += 1;
                }

                oDocEdited = oPDF.OpenDocument(oDoc.SaveToMemory());
                DocArray.Add(oDocEdited);


            }

            PdfDocument FinalDoc = oPDF.CreateDocument();
            //PdfDocument q = default(PdfDocument);


            if (DocArray.Count > 0)
            {
                foreach (PdfDocument q in DocArray)
                {
                    FinalDoc.AppendDocument(q);
                }
            }

            try
            {
                //FinalDoc.SaveHttp("filename=ElectionsFormA.pdf");
                FileBlob = FinalDoc.SaveToMemory();
            }
            catch// (System.Exception ex)
            {
                //Response.Write("got this far");
                //Response.End();
            }

            //var blobTest = FinalDoc.SaveToMemory();

            FinalDoc.Close();
            oPDF = null;

            if (DocArray.Count > 0)
            {
                foreach (PdfDocument q in DocArray)
                {
                    q.Close();
                }
            }

            //return FinalDoc;
            return FileBlob;
        }

        private void SetReadOnlyPDFField(ref PdfDocument oDoc, string FieldName, string FieldValue)
        {
            PdfFont oFont = oDoc.Fonts["Courier"];
            PdfAnnot oField = default(PdfAnnot);

            oField = oDoc.Form.FindField("topmostSubform[0].Page1[0]." + FieldName + "[0]");

            if ((oField != null))
            {
                oField.SetFieldValue(FieldValue, oFont);
                oField.FieldFlags = oField.FieldFlags | 1;
            }

        }

        private PdfDocument TestPDF(string data)
        {
            PdfManager oPDF = new PdfManager();
            //PdfDocument oDoc = default(PdfDocument);
            ArrayList DocArray = new ArrayList();
            PdfDocument oDocEdited = default(PdfDocument);
            //string z = "1";

            PdfDocument oDoc = oPDF.OpenDocument(System.Web.HttpContext.Current.Server.MapPath("../../ApiControllers/AppConversions/ElectionsForm/PDFTemplates/Template.pdf"));

            //SetReadOnlyPDFField(oDoc, ("sub" & z), "")
            //SetReadOnlyPDFField(oDoc, ("votes" & z), "")
            //SetReadOnlyPDFField(oDoc, ("elect" & z), "")
            //SetReadOnlyPDFField(oDoc, ("inc" & z), "")
            //SetReadOnlyPDFField(oDoc, ("gend" & z), "")
            //SetReadOnlyPDFField(oDoc, ("name" & z), "")
            //SetReadOnlyPDFField(oDoc, ("add" & z), "")
            //SetReadOnlyPDFField(oDoc, ("phone" & z), "")
            //SetReadOnlyPDFField(oDoc, ("fax" & z), "")
            //SetReadOnlyPDFField(oDoc, ("email" & z), "")


            SetReadOnlyPDFField(ref oDoc, ("add2"), "1");
            SetReadOnlyPDFField(ref oDoc, ("add3"), "2");
            SetReadOnlyPDFField(ref oDoc, ("add4"), "3");
            SetReadOnlyPDFField(ref oDoc, ("add5"), "4");





            oDocEdited = oPDF.OpenDocument(oDoc.SaveToMemory());

            DocArray.Add(oDocEdited);


            PdfDocument FinalDoc = oPDF.CreateDocument();
            //PdfDocument q = default(PdfDocument);

            if (DocArray.Count > 0)
            {
                foreach (PdfDocument q in DocArray)
                {
                    FinalDoc.AppendDocument(q);
                }
            }

            FinalDoc.SaveHttp("filename=test.pdf");

            FinalDoc.Close();

            FinalDoc = null;
            oPDF = null;

            if (DocArray.Count > 0)
            {
                foreach (PdfDocument q in DocArray)
                {
                    q.Close();
                    //q = null;
                }
            }

            return FinalDoc;
        }

    }
}
