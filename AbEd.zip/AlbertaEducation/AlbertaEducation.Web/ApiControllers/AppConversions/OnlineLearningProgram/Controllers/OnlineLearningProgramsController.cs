﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.OnlineLearningProgram.Controllers
{
    public class OnlineLearningProgramsController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] OnlineLearningPrograms.SearchRequest searchRequest)
        {
            try
            {
                var onlineLearningPrograms = new OnlineLearningPrograms.OnlineLearningPrograms();
                var results = onlineLearningPrograms.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on OnlineLearningProgramsController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}