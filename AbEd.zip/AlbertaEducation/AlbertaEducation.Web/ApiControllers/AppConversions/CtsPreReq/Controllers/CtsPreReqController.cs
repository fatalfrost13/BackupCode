﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.CtsPreReq.Controllers
{
    public class CtsPreReqController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] CtsPre.SearchRequest searchRequest)
        {
            try
            {
                var ctsPre = new CtsPre.CtsPre();
                var results = ctsPre.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on CtsPreReqController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchPreReqs([FromBody] CtsPre.FetchPreReqsRequest fetchPreReqsRequest)
        {
            try
            {
                var ctsPre = new CtsPre.CtsPre();
                var results = ctsPre.FetchPreReqs(fetchPreReqsRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on CtsPreReqController.FetchPreReqs().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}