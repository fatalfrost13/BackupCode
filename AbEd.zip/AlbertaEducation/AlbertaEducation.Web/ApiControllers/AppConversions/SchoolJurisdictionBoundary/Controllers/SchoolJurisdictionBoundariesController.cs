﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.SchoolJurisdictionBoundary.Controllers
{
    public class SchoolJurisdictionBoundariesController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] SchoolJurisdictionBoundaries.SearchRequest searchRequest)
        {
            try
            {
                var schoolJurisdictionBoundaries = new SchoolJurisdictionBoundaries.SchoolJurisdictionBoundaries();
                var results = schoolJurisdictionBoundaries.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on SchoolJurisdictionBoundariesController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}