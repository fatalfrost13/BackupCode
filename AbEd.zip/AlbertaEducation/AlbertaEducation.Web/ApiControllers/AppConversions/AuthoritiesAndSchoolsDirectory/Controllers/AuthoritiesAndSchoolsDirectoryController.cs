﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppConversion;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.AuthoritiesAndSchoolsDirectory.Controllers
{
    public class AuthoritiesAndSchoolsDirectoryController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] SearchRequest searchRequest)
        {
            var authoritiesAndSchoolsDirectory = new AppConversion.AuthoritiesAndSchoolsDirectory();
            var results = authoritiesAndSchoolsDirectory.Fetch(searchRequest);
            var response = Request.CreateResponse(HttpStatusCode.OK, results);
            return response;
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchAuthorityOrSchool([FromBody]SearchRequest searchRequest)
        {
            var authoritiesAndSchoolsDirectory = new AppConversion.AuthoritiesAndSchoolsDirectory();
            var results = authoritiesAndSchoolsDirectory.FetchAuthorityOrSchool(searchRequest);
            var response = Request.CreateResponse(HttpStatusCode.OK, results);
            return response;
        }
    }
}