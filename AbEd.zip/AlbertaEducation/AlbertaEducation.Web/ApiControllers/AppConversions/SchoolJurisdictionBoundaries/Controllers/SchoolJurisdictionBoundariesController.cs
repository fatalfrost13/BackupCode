﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppConversion;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.SchoolJurisdictionBoundaries.Controllers
{
    public class SchoolJurisdictionBoundariesController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] SearchRequest searchRequest)
        {
            var schoolJurisdictionBoundaries = new AppConversion.SchoolJurisdictionBoundaries();
            var results = schoolJurisdictionBoundaries.Fetch(searchRequest);
            var response = Request.CreateResponse(HttpStatusCode.OK, results);
            return response;
        }
    }
}