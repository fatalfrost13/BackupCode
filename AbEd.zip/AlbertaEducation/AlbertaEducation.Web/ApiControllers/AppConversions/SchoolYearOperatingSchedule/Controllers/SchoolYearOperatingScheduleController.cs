﻿using System.Net;
using System.Net.Http;
using System.Web.Http;
using AppConversion;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.SchoolYearOperatingSchedule.Controllers
{
    public class SchoolYearOperatingScheduleController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] SearchRequest searchRequest)
        {
            var schoolYearOperatingSchedule = new AppConversion.SchoolYearOperatingSchedule();
            var results = schoolYearOperatingSchedule.Fetch(searchRequest);
            var response = Request.CreateResponse(HttpStatusCode.OK, results);
            return response;
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchOperatingSchedule([FromBody] OperatingScheduleRequest operatingScheduleRequest)
        {
            var schoolYearOperatingSchedule = new AppConversion.SchoolYearOperatingSchedule();
            var results = schoolYearOperatingSchedule.FetchOperatingSchedule(operatingScheduleRequest);
            var response = Request.CreateResponse(HttpStatusCode.OK, results);
            return response;
        }
    }
}