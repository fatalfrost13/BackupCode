﻿using System;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Umbraco.Core.Logging;
using Umbraco.Web.WebApi;

namespace AlbertaEducation.Web.ApiControllers.AppConversions.SchoolYearOperatingSchedules.Controllers
{
    public class SchoolYearOperatingScheduleController : UmbracoAuthorizedApiController
    {
        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage Fetch([FromBody] SchoolYearOperatingSchedule.SearchRequest searchRequest)
        {
            try
            {
                var schoolYearOperatingSchedule = new SchoolYearOperatingSchedule.SchoolYearOperatingSchedule();
                var results = schoolYearOperatingSchedule.Fetch(searchRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on SchoolYearOperatingScheduleController.Fetch().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public HttpResponseMessage FetchOperatingSchedule([FromBody] SchoolYearOperatingSchedule.OperatingScheduleRequest operatingScheduleRequest)
        {
            try
            {
                var schoolYearOperatingSchedule = new SchoolYearOperatingSchedule.SchoolYearOperatingSchedule();
                var results = schoolYearOperatingSchedule.FetchOperatingSchedule(operatingScheduleRequest);
                var response = Request.CreateResponse(HttpStatusCode.OK, results);
                return response;
            }
            catch (Exception ex)
            {
                LogHelper.Error<JurisdictonFactsheets.SearchRequest>("Iomer caught error on SchoolYearOperatingScheduleController.FetchOperatingSchedule().", ex);
                var errorResponse = Request.CreateErrorResponse(HttpStatusCode.InternalServerError, ex.Message);
                return errorResponse;
            }
        }
    }
}