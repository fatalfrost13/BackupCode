﻿using System;
using System.Linq;
using System.Web.Http;

namespace AlbertaEducation.Web.Controllers
{
    using System.Collections.Generic;

    using Helpers;

    using Iomer.Umbraco.Extensions.Query;

    using Models;

    using IomerBase.U7.DataDefinition;

    using Umbraco.Core.Logging;
    using Umbraco.Core.Models;
    public class TimelineController : ApiController
    {

        private static IPublishedContent _timelineNode;
        public static IPublishedContent TimelineNode
        {
            get
            {
                if (_timelineNode == null)
                {
                    _timelineNode = QueryUtility.GetPublishedContentByType(DocumentTypes.timelineContainer.ToString()).FirstOrDefault();
                }
                return _timelineNode;
            }
        }

        [HttpPost]
        public List<CustomTimelineItem> GetCustomTimeline(string language = "")
        {
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                var timelineNode = TimelineNode;
                var timeline = new List<CustomTimelineItem>();
                if (timelineNode != null && timelineNode.Id > 0)
                {
                    timeline = TimelineHelper.GetCustomTimeline(timelineNode, language, userFilter);
                }
                return timeline;
            }
            catch (Exception ex)
            {
                LogHelper.Error<TimelineController>("Iomer caught error on TimelineController.GetCustomTimeline().", ex);
                throw;
            }
        }
    }
}