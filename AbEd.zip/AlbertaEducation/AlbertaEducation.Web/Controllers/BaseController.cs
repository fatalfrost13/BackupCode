﻿namespace AlbertaEducation.Web.Controllers
{
    using System.Web;
    using System.Web.Http;

    using AlbertaEducation.Web.Helpers;

    using Umbraco.Web;

    public abstract class BaseController : ApiController
    {

        public static UmbracoHelper _umbracoHelper;
        public static UmbracoHelper umbracoHelper
        {
            get
            {
                if (_umbracoHelper == null || HttpContext.Current == null)
                {
                    _umbracoHelper = CustomUmbracoHelper.GetUmbracoHelper();
                }
                return _umbracoHelper;
            }
        }
    }
}