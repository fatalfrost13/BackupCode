﻿namespace AlbertaEducation.Web.Controllers
{
    using System;
    using System.Linq;

    using AlbertaEducation.Web.DataDefinition;
    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    using Iomer.Umbraco.Extensions.Content;

    using IomerBase.U7.DataDefinition;
    using Umbraco.Core;
    using Umbraco.Core.Logging;

    using CacheHelper = AlbertaEducation.Web.Helpers.CacheHelper;

    public class ToolboxController: BaseController
    {
        //public ToolboxItem GetInitialToolboxItem(int currentNodeId)
        //{
        //    ToolboxItem toolboxItem = null;
        //    var currNode = umbracoHelper.GetById(currentNodeId);
        //    try
        //    {
        //        var userFilter = CacheHelper.GetUserSearchFilter();

        //        if (currNode != null && currNode.Id > 0)
        //        {
        //            var toolboxNodeId = !CombinationTypes.ToolboxTypeAliases.Contains(currNode.DocumentTypeAlias) ? currNode.FindAllNodeIDs(CombinationTypes.ToolboxTypeAliases).FirstOrDefault(i => i.ToolboxHasData()) : currentNodeId;
        //            if (toolboxNodeId == 0)
        //            {
        //                toolboxNodeId = currNode.FindContainerNodeId(CombinationTypes.ToolboxTypeAliases);
        //            }
        //            if (toolboxNodeId > 0)
        //            {
        //                toolboxItem = ToolboxHelper.GetToolboxItem(toolboxNodeId);
        //            }
        //            else if (currNode.DocumentTypeAlias == DocumentTypes.subTopic.ToString())
        //            {
        //                //get first
        //                var personaNode = currNode.Children.FirstOrDefault(i => i.DocumentTypeAlias == DocumentTypes.personaContent.ToString() && i.Name == userFilter.Persona);
        //                var firstToolboxNode = personaNode?.Children.FirstOrDefault(i => i.Id.ToolboxHasData());
        //                if (firstToolboxNode != null)
        //                {
        //                    toolboxItem = ToolboxHelper.GetToolboxItem(firstToolboxNode);
        //                }
        //            }
        //            else if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
        //            {
        //                var topic = TopicHelper.GetTopic(currNode.Id, userFilter);
        //                toolboxItem = topic.FirstToolboxItem;
        //            }
        //        }
        //        return toolboxItem;
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.Error<ToolboxController>($"Iomer caught error on ToolboxController.GetInitialToolboxItem(). Node: {currNode.Id} - {currNode.Name}", ex);
        //        throw;
        //    }
        //}

        public int GetCountAddPostCount(string nodeId)
        {
            try
            {
                var contentService = ApplicationContext.Current.Services.ContentService;
                var nodeInt = int.Parse(nodeId);
                var doc = contentService.GetById(nodeInt);
                var existingCountText = doc.GetValue(DocumentFields.pollResponseCount.ToString())?.ToString();
                var newCount = 1;
                if (!string.IsNullOrEmpty(existingCountText))
                {
                    var existingCountInt = int.Parse(existingCountText);
                    newCount = existingCountInt + 1;
                }
                doc.SetValue(DocumentFields.pollResponseCount.ToString(), newCount);
                contentService.Save(doc);
                contentService.Publish(doc);

                return newCount;
            }
            catch (Exception ex)
            {
                LogHelper.Error<ToolboxController>("Iomer caught error on ToolboxController.GetCountAddPostCount().", ex);
                throw;
            }
        }
    }
}
