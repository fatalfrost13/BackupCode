﻿using System.Collections.Generic;
using System.Net;
using System.Web.Http;
using System.Net.Mail;
using System.ComponentModel.DataAnnotations;
using IomerBase.U7.DataDefinition;
using Iomer.Extensions.Email;
using Newtonsoft.Json;
using System.Configuration;

namespace AlbertaEducation.Web.Controllers
{
    using System;

    using AlbertaEducation.Web.Helpers;

    using Iomer.Umbraco.Extensions.Content;

    using Umbraco.Core.Logging;

    public class ContactController : BaseController
    {
        private readonly string secret = ConfigurationManager.AppSettings["reCaptchaSecret"];

        [HttpPost]
        public Email.EmailStatus SendEmail(SubmitEmail email)
        {
            try
            {
                
                if (!this.ModelState.IsValid || email.ContactId <= 0)
                {
                    return new Email.EmailStatus { EmailSent = false, ErrorMessage = "Invalid input" };
                }
                var contactId = email.ContactId ?? 0;
                var contact = umbracoHelper.GetById(contactId);
                if (contact != null && contact.Id > 0)
                {
                    return new Email.EmailStatus { EmailSent = false, ErrorMessage = "Contact not found" };
                }

                var contactEmail = contact.GetContentValue(DocumentFields.email.ToString());
                if (string.IsNullOrWhiteSpace(contactEmail))
                {
                    return new Email.EmailStatus { EmailSent = false, ErrorMessage = "Contact does not have an email address" };
                }

                var client = new WebClient();
                var reply = client.DownloadString($"https://www.google.com/recaptcha/api/siteverify?secret={this.secret}&response={email.Captcha}");
                var captchaResponse = JilSerializer.DeserializeObject<CaptchaResponse>(reply);

                if (!captchaResponse.Success)
                {
                    return new Email.EmailStatus { EmailSent = false, ErrorMessage = this.GetCaptchaError(captchaResponse) };
                }

                var message = new MailMessage(email.EmailAddress, contactEmail, email.Subject, email.Message);
                var status = Email.SendEmail(message);
                return status;
            }
            catch (Exception ex)
            {
                LogHelper.Error<ContactController>("Iomer caught error on ContactController.SendEmail().", ex);
                throw;
            }
        }

        private string GetCaptchaError(CaptchaResponse captchaResponse)
        {
            try
            {
                if (captchaResponse.ErrorCodes.Count <= 0) return "Unknown error";

                var error = captchaResponse.ErrorCodes[0].ToLower();
                switch (error)
                {
                    case ("missing-input-secret"):
                        return "The secret parameter is missing.";
                    case ("invalid-input-secret"):
                        return "The secret parameter is invalid or malformed.";
                    case ("missing-input-response"):
                        return "The response parameter is missing.";
                    case ("invalid-input-response"):
                        return "The response parameter is invalid or malformed.";
                    default:
                        return "Error occured. Please try again";
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error<ContactController>("Iomer caught error on ContactController.GetCaptchaError().", ex);
                throw;
            }
        }

        public class CaptchaResponse
        {
            [JsonProperty("success")]
            public bool Success { get; set; }

            [JsonProperty("error-codes")]
            public List<string> ErrorCodes { get; set; }
        }

        public class SubmitEmail
        {
            [Required]
            public int? ContactId { get; set; }
            [Required]
            public string Name { get; set; }
            [Required]
            public string Subject { get; set; }
            [Required]
            [EmailAddress]
            public string EmailAddress { get; set; }
            [Required]
            public string Message { get; set; }
            [Required]
            public string Captcha { get; set; }
        }
    }
}
