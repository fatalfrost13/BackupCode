﻿using AlbertaEducation.Web.Helpers;
using AlbertaEducation.Web.Models;
using System;
using System.Configuration;
using System.Linq;
using System.Web;
using IomerBase.U7.DataDefinition;
using AlbertaEducation.Web.DataDefinition;

namespace AlbertaEducation.Web.Controllers
{
    using Iomer.Umbraco.Extensions.Content;

    using Umbraco.Core.Logging;

    public class SiteSearchController : BaseController
    {

        public bool GetInitializeSearch(string searchQuery)
        {
            var userFilter = SearchHelper.ResetFilter();
            userFilter.FilterChangeSearchQuery(searchQuery, true, true);
            return true;
        }

        public SearchResults GetSearchResults(string query = "", int skip = 0, int batchSize = 10, string type = "")
        {
            var site = ConfigurationManager.AppSettings["GoogleSearchApplianceSite"];
            var client = ConfigurationManager.AppSettings["GoogleSearchApplianceClient"];

            var userFilter = CacheHelper.GetUserSearchFilter();
            if (!userFilter.ShowSearch)
            {
                userFilter.ShowSearch = true;
                userFilter.ApplyChanges();
            }

            if (string.IsNullOrEmpty(site) || string.IsNullOrEmpty(client))
            {
                return SiteSearchHelper.GetSearchResultsFromUmbraco(query, userFilter, skip, batchSize, type);
            }
            else
            {
                return SiteSearchHelper.GetSearchResultsFromGoogle(query, userFilter, skip, batchSize, type);
            }
        }

        public Topic GetSearchTopic(int currentNodeId, string persona = "")
        {
            Topic topic = null;
            var currNode = umbracoHelper.GetById(currentNodeId);

            try
            {
                var searchFilter = CacheHelper.GetUserSearchFilter();
                if (string.IsNullOrEmpty(persona))
                {
                    searchFilter.Persona = CacheHelper.DefaultPersonaFilter;
                }
                else
                {
                    searchFilter.Persona = persona;
                }

                if (currNode != null && currNode.Id > 0)
                {
                    var topicList = TopicHelper.TopicList(searchFilter).TopicList;
                    if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
                    {
                        //topic = TopicHelper.GetTopic(currentNodeId, searchFilter);
                        topic = topicList.SingleOrDefault(i => i.NodeId == currentNodeId);
                    }
                    else if (currNode.DocumentTypeAlias == DocumentTypes.internalNewsItem.ToString())
                    {
                        var MinistryId = JourneyHelper.MinistryJourneyId;
                        if (MinistryId.HasValue)
                        {
                            searchFilter = searchFilter.FilterJourney(MinistryId.Value, true);
                        }
                        //topic = NewsHelper.GetNewsTopic(searchFilter, HttpContext.Current);
                        topic = topicList.SingleOrDefault(i => i.NewsTopic);
                    }
                    else
                    {
                        var topicNodeId = currNode.FindContainerNodeId(DocumentTypes.topic.ToString());
                        //topic = TopicHelper.GetTopic(topicNodeId, searchFilter);
                        topic = topicList.SingleOrDefault(i => i.NodeId == topicNodeId);
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error<SiteSearchController>($"Iomer caught error on SiteSearchController.GetSearchTopic(). Node: {currNode.Id} - {currNode.Name}", ex);
            }
            return topic;
        }

        public SubTopic GetSearchSubTopic(int currentNodeId, string persona = "")
        {
            SubTopic subTopic = null;
            var currNode = umbracoHelper.GetById(currentNodeId);

            try
            {
                var searchFilter = CacheHelper.GetUserSearchFilter();
                if (string.IsNullOrEmpty(persona))
                {
                    searchFilter.Persona = CacheHelper.DefaultPersonaFilter;
                }
                else
                {
                    searchFilter.Persona = persona;
                }

                if (currNode != null && currNode.Id > 0)
                {
                    var topicList = TopicHelper.TopicList(searchFilter).TopicList;
                    int subTopicNodeId = 0;
                    Topic topic = null;
                    if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
                    {
                        //var topic = TopicHelper.GetTopic(currentNodeId, searchFilter);
                        topic = FilterHelper.GetFilteredTopicById(currentNodeId, searchFilter);
                        if (topic != null)
                        {
                            subTopicNodeId = topic.SubTopics.Any() ? topic.SubTopics[0].NodeId : 0;
                            searchFilter.Language = topic.Language;
                        }
                    }
                    else
                    {
                        subTopicNodeId = currNode.DocumentTypeAlias != DocumentTypes.subTopic.ToString() ? currNode.FindContainerNodeId(DocumentTypes.subTopic.ToString()) : currentNodeId;
                    }

                    if (subTopicNodeId > 0)
                    {
                        if (currNode.DocumentTypeAlias != DocumentTypes.subTopic.ToString())
                        {
                            if (topic == null)
                            {
                                var topicNodeId = currNode.FindContainerNodeId(DocumentTypes.topic.ToString());
                                topic = FilterHelper.GetFilteredTopicById(topicNodeId, searchFilter);
                            }
                            var subtopicPersonaNodeId = currNode.FindContainerNodeId(DocumentTypes.personaContent.ToString());
                            if (subtopicPersonaNodeId > 0)
                            {
                                var toolboxPersona = umbracoHelper.GetById(subtopicPersonaNodeId).Name;
                                searchFilter.Persona = toolboxPersona;
                            }
                        }
                        if (topic != null)
                        {
                            subTopic = topic.GetSubTopicFromCache(subTopicNodeId);
                            searchFilter.Language = subTopic?.Language;
                        }
                        //subTopic = SubTopicHelper.GetSubTopic(subTopicNodeId, searchFilter);
                        //searchFilter.Language = subTopic?.Language;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error<SiteSearchController>($"Iomer caught error on SiteSearchController.GetSearchSubTopic(). Node: {currNode.Id} - {currNode.Name}", ex);
            }
            return subTopic;
        }

        public ToolboxItem GetSearchToolboxItem(int currentNodeId, string persona = "")
        {
            ToolboxItem toolboxItem = null;
            var currNode = umbracoHelper.GetById(currentNodeId);
            try
            {
                var searchFilter = CacheHelper.GetUserSearchFilter();
                var topicNodeId = currNode.FindContainerNodeId(DocumentTypes.topic.ToString());

                if (string.IsNullOrEmpty(persona))
                {
                    searchFilter.Persona = CacheHelper.DefaultPersonaFilter;
                }
                else
                {
                    searchFilter.Persona = persona;
                }

                if (currNode != null && currNode.Id > 0 && topicNodeId > 0)
                {
                    var topic = FilterHelper.GetFilteredTopicById(topicNodeId, searchFilter);
                    var toolboxNodeId = !CombinationTypes.ToolboxTypeAliasesSet.Contains(currNode.DocumentTypeAlias) ? currNode.FindAllNodes(CombinationTypes.ToolboxTypeAliasesSet).FirstOrDefault(i => i.ToolboxHasData()).Id : currentNodeId;
                    if (toolboxNodeId > 0)
                    {
                        //toolboxItem = ToolboxHelper.GetToolboxItem(toolboxNodeId);
                        toolboxItem = topic.GetToolboxFromCache(toolboxNodeId);
                    }
                    else if (currNode.DocumentTypeAlias == DocumentTypes.subTopic.ToString())
                    {
                        //get first
                        var personaNode = currNode.Children.FirstOrDefault(i => i.DocumentTypeAlias == DocumentTypes.personaContent.ToString() && i.Name == searchFilter.Persona && i.ToolboxHasData());
                        var firstToolboxNode = personaNode.Children.FirstOrDefault(i => i.ToolboxHasData());
                        if (firstToolboxNode != null)
                        {
                            //toolboxItem = ToolboxHelper.GetToolboxItem(firstToolboxNode);
                            toolboxItem = topic.GetToolboxFromCache(firstToolboxNode.Id);
                        }
                    }
                    else if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
                    {
                        //var topic = TopicHelper.GetTopic(currNode.Id, searchFilter);
                        toolboxItem = topic.FirstToolboxItem;
                    }
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error<SiteSearchController>($"Iomer caught error on SiteSearchController.GetSearchToolboxItem(). Node: {currNode.Id} - {currNode.Name}", ex);
            }
            return toolboxItem;
        }
    }
}