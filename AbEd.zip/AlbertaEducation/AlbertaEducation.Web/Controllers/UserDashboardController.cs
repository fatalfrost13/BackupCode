﻿namespace AlbertaEducation.Web.Controllers
{
    using System;
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    public class UserDashboardController: ApiController
    {
        public WorkflowUserConfigurationModel GetUserConfiguration()
        {
            return WorkflowNotificationHelper.GetUserConfiguration();
        }

        public HttpResponseMessage SaveUserConfiguration([FromBody] WorkflowUserConfigurationModel config)
        {
            var savedConfig = WorkflowNotificationHelper.SaveUserConfiguration(config);
            var response = this.Request.CreateResponse(HttpStatusCode.Accepted);
            response.Content = new StringContent("User settings have been saved!");
            return response;
        }
    }
}