﻿using System.Collections.Generic;

namespace AlbertaEducation.Web.Controllers
{
    using System.Web.Http;

    using Helpers;
    using Models;

    public class FilterController: ApiController
    {

        public SearchFilter GetToggleSideFilter(int open = -1)
        {
            //toggle the cache filter
            var userFilter = CacheHelper.GetUserSearchFilter();
            if (open == -1)
            {
                userFilter.ToggleFilters = !userFilter.ToggleFilters;
            }
            else if(open == 0)
            {
                userFilter.ToggleFilters = false;
            }
            else
            {
                userFilter.ToggleFilters = true;
            }
            userFilter.ApplyChanges();
            return userFilter;
        }

        // GET api/<controller>/id/nodetypealias/maxlevel
        public SearchFilter GetSearchFilter()
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            return userFilter;
        }

        [HttpPost]
        public SearchFilter UpdateSearchFilter(SearchFilter searchFilter)
        {
            searchFilter.ApplyChanges();
            return searchFilter;
        }

        public SearchFilter GetClearedCategoryFilter() {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter.CategoryIds.Clear();
            userFilter.ApplyChanges();
            return userFilter;
        }

        public SearchFilter GetSearchModeFilter(int searchMode)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter = userFilter.FilterToggleMode(searchMode, true);
            return userFilter;
        }

        public List<TopicCategory> GetCategoryList()
        {
            return TopicCategoryHelper.AllCategories;
        }

        public List<PersonaItem> GetPersonaList()
        {
            return PersonaHelper.AllPersonas;
        }

        public SearchFilter GetShowSearch(bool showSearch = true)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter.ShowSearch = showSearch;
            userFilter.ApplyChanges();
            return userFilter;
        }

        public SearchFilter GetTopicsByMonth(int month = 0)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            if (month > 0)
            {
                userFilter.Sort.OrderBy = OrderBy.Month;
                userFilter.Sort.Parameters.Month = month;
                userFilter.ApplyChanges();
            }
            else
            {
                //default sort
                userFilter.Sort.OrderBy = OrderBy.Default;
                userFilter.ApplyChanges();
            }
            return userFilter;
        }

        public SearchFilter GetTopicsAlphabetically(int direction = 0)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            //direction = 1 is ascending
            //direction = 2 is descending
            if (direction > 0)
            {
                userFilter.Sort.OrderBy = OrderBy.Alphabetically;
                userFilter.Sort.SortDirection = (SortDirection)direction;
                userFilter.ApplyChanges();
            }
            return userFilter;
        }

        public string GetTranslation(string key, string language)
        {
            var translationValue = LanguageHelper.GetDictionaryText(key, language);
            return translationValue;
        }

        public TranslateWords GetTranslations(string language)
        {
            var translateWords = new TranslateWords
            {
                ApplicationLinks = LanguageHelper.GetDictionaryText("Application Links", language),
                Applications = LanguageHelper.GetDictionaryText("Applications", language),
                Blog = LanguageHelper.GetDictionaryText("Blog", language),
                Blogs = LanguageHelper.GetDictionaryText("Blogs", language),
                Content = LanguageHelper.GetDictionaryText("Content", language),
                Calendar = LanguageHelper.GetDictionaryText("Calendar", language),
                CollapseTimeline = LanguageHelper.GetDictionaryText("Collapse Timeline", language),
                Contact = LanguageHelper.GetDictionaryText("Contact", language),
                Contacts = LanguageHelper.GetDictionaryText("Contacts", language),
                Document = LanguageHelper.GetDictionaryText("Document", language),
                Documents = LanguageHelper.GetDictionaryText("Documents", language),
                Events = LanguageHelper.GetDictionaryText("Events", language),
                ExpandTimeline = LanguageHelper.GetDictionaryText("Expand Timeline", language),
                ExternalLink = LanguageHelper.GetDictionaryText("External Link", language),
                ExternalLinks = LanguageHelper.GetDictionaryText("External Links", language),
                FAQ = LanguageHelper.GetDictionaryText("FAQ", language),
                Find = LanguageHelper.GetDictionaryText("Find", language),
                InternalLink = LanguageHelper.GetDictionaryText("Internal Link", language),
                InternalLinks = LanguageHelper.GetDictionaryText("Internal Links", language),
                Jobs = LanguageHelper.GetDictionaryText("Jobs", language),
                Media = LanguageHelper.GetDictionaryText("Media", language),
                Multimedia = LanguageHelper.GetDictionaryText("Multimedia", language),
                News = LanguageHelper.GetDictionaryText("News", language),
                Newsletter = LanguageHelper.GetDictionaryText("Newsletter", language),
                Newsletters = LanguageHelper.GetDictionaryText("Newsletters", language),
                Poll = LanguageHelper.GetDictionaryText("Poll", language),
                RelevantNow = LanguageHelper.GetDictionaryText("Relevant Now", language),
                SeeEvents = LanguageHelper.GetDictionaryText("See Events", language),
                Toolbox = LanguageHelper.GetDictionaryText("Toolbox", language),
                
            };

            return translateWords;
        }
    }

}
