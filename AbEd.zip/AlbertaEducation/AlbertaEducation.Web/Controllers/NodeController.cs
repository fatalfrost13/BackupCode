﻿using System.Collections.Generic;
using System.Web.Http;

namespace IomerBase.U7.ApiControllers
{
    using Models;
    using ApiClasses;
    using AlbertaEducation.Web.Helpers;
    public class NodeController : ApiController
    {
        readonly UmbracoNode[] umbracoNodes = {
               new UmbracoNode{ Id = 0 }
            };

        // GET api/<controller>
        public IEnumerable<UmbracoNode> GetAllUmbracoNodes()
        {
            return this.umbracoNodes;
        }

        public UmbracoNode GetSingleNodeData(int id)
        {
            var umbracoNode = UmbracoNodeHelper.GetSingleNodeData(id);
            return umbracoNode;
        }

        // GET api/<controller>/id/nodetypealias/maxlevel
        public UmbracoNode GetNodeData(int id, string nodetypealias, string maxlevel)
        {
            var umbracoNode = UmbracoNodeHelper.GetNodeData(id.ToString(), nodetypealias, maxlevel);
            return umbracoNode;
        }

        public int GetNodeIdByUrl(string url)
        {
            if (url.StartsWith("/") == false)
            {
                url = $"/{url}";
            }
            var nodeId = CustomUmbracoHelper.GetNodeIdFromUrl(url);
            return nodeId;
        }

        // POST api/<controller>
        public void Post([FromBody]string value)
        {
        }

        // PUT api/<controller>/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/<controller>/5
        public void Delete(int id)
        {
        }
    }
}