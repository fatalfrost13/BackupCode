﻿using AlbertaEducation.Web.Helpers;
using AlbertaEducation.Web.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AlbertaEducation.Web.Controllers
{
    public class CategoryController : BaseController
    {
        //public List<CardCategory> GetCategoryList(bool loadTopics = false)
        //{
        //    var searchFilter = CacheHelper.GetUserSearchFilter();
        //    var topicList = TopicHelper.TopicList(searchFilter).TopicList;
        //    var categoryCardList = CardCategoryHelper.GetCardCategoryList(searchFilter, topicList, loadTopics);
        //    return categoryCardList.ToList();
        //}

        public List<CardCategory> GetAllCategories(bool customCategorySort = false)
        {
            var newSearchFilter = new SearchFilter { };
            
            var categoryCardList = CardCategoryHelper.GetCardCategoryList(newSearchFilter, null, false, true);

            if (customCategorySort)
            {
                var searchFilter = CacheHelper.GetUserSearchFilter();
                //if (searchFilter.CardStackCategoryId > 0)
                //{
                //    var topicList = TopicHelper.TopicList(searchFilter).TopicList;
                //    var fullCategory = CardCategoryHelper.GetCardCategory(searchFilter.CardStackCategoryId, searchFilter, topicList, true);
                //    var index = categoryCardList.FindIndex(i => i.NodeId == searchFilter.CardStackCategoryId);
                //    if (index > 0)
                //    {
                //        categoryCardList[index] = fullCategory;
                //    }
                    
                //}

                //sort by custom items.
                if (searchFilter.Sort.OrderBy == OrderBy.Alphabetically)
                {
                    if (searchFilter.Sort.SortDirection == SortDirection.Ascending)
                    {
                        if (searchFilter.Language == "English")
                        {
                            categoryCardList = categoryCardList.OrderBy(i => i.Title).ToList();
                        }
                        else
                        {
                            categoryCardList = categoryCardList.OrderBy(i => i.FrenchTitle).ToList();
                        }
                    }
                    else
                    {
                        if (searchFilter.Language == "English")
                        {
                            categoryCardList = categoryCardList.OrderByDescending(i => i.Title).ToList();
                        }
                        else
                        {
                            categoryCardList = categoryCardList.OrderByDescending(i => i.FrenchTitle).ToList();
                        }
                    }
                }
                else if(searchFilter.Sort.OrderBy == OrderBy.Month)
                {
                    //load months first
                    var sortMonth = searchFilter.Sort.Parameters.Month > 0 ? searchFilter.Sort.Parameters.Month : DateTime.Now.Month;
                    var sortedMonthCategoryList = categoryCardList.Where(i => i.MonthList.Contains(sortMonth)).ToList();
                    sortedMonthCategoryList.AddRange(categoryCardList.Except(sortedMonthCategoryList));
                    //sortedTopics.AddRange(sortedMonthTopics);   //add the remaining sorted items
                    categoryCardList = sortedMonthCategoryList;
                }
            }
            return categoryCardList.ToList();
        }

        //[HttpPost]
        //public CardCategory RefreshCategoryCard(TopicSearch topicSearch)
        //{
        //    var searchFilter = CacheHelper.GetUserSearchFilter();
        //    var categoryId = topicSearch.CategoryIds.FirstOrDefault();
        //    var topicList = topicSearch.TopicList;
        //    var cardCategory = CardCategoryHelper.GetCardCategory(categoryId, searchFilter, topicList, false);
        //    return cardCategory;
        //}

        public CardCategory GetCategory(int categoryId = 0, bool loadTopics = false)
        {
            var searchFilter = CacheHelper.GetUserSearchFilter();
            var topicList = TopicHelper.TopicList(searchFilter).TopicList;
            var category = CardCategoryHelper.GetCardCategory(categoryId, searchFilter, topicList, loadTopics);

            if (categoryId > 0 && !searchFilter.CategoryIds.Contains(categoryId))
            {
                searchFilter.CategoryIds.Add(categoryId);
                searchFilter.ApplyChanges();
            }

            return category;
        }
    }
}
