﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlbertaEducation.Web.Controllers
{
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    using AlbertaEducation.Web.DataContext;
    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    using Umbraco.Web.WebApi;

    public class PublishedPagesController : UmbracoApiController
    {
        public List<PublishedPagesModel> GetPublishedPages(string sD, string eD)
        {
            try
            {
                using (var db = new AbEdEntities())
                {
                    DateTime dtSD = DateTime.Parse(sD);
                    DateTime dtED = DateTime.Parse(eD).AddDays(1);

                    var PublishedPagesList = db.PublishedPages.Where(i => (i.Datestamp >= dtSD && i.Datestamp < dtED)).OrderByDescending(i => i.Datestamp).ToList();
                    var PublishedPagesModelList = PublishedPagesList.Select(i => GetPublishedPagesModel(i)).ToList();
                    return PublishedPagesModelList;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static PublishedPagesModel GetPublishedPagesModel(PublishedPage PageItem)
        {
            try
            {
                var model = new PublishedPagesModel
                {
                    id = PageItem.id,
                    userId = PageItem.userId,
                    userName = PageItem.userName,
                    NodeId = PageItem.NodeId,
                    text = PageItem.text,
                    path = PageItem.path,
                    URL = PageItem.URL,
                    Datestamp = PageItem.Datestamp,
                    logHeader = PageItem.logHeader,
                    logComment = PageItem.logComment
                };

                return model;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
    }
}