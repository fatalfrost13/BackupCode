﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlbertaEducation.Web.Controllers
{
    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;
    using System.Web.Security;
    using Umbraco.IdentityExtensions;
    using Umbraco.Web.WebApi;

    public class UmbracoUserController : UmbracoApiController
    {
        public List<UmbracoUserModel> GetUserList()
        {
            var users = SecurityHelper.GetUsers();
            return users.OrderBy(i => i.userName).ToList();
        }

        public bool GetNewUserAdded(string userName)
        {
            return SecurityHelper.CheckNewUserAdded(userName);
        }
    }
}