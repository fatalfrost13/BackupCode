﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AlbertaEducation.Web.Controllers
{
    using AlbertaEducation.Web.DataContext;
    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    using Umbraco.Web.WebApi;

    public class CustomWorkflowController : UmbracoApiController
    {

        // GET api/<controller>/5
        public WorkflowState GetWorkflow(int id, bool inherited = false, bool loadUsers = false)
        {
            var workflowState = WorkflowStateHelper.GetWorkflowState(id, inherited, loadUsers);
            return workflowState;
        }

        public NotificationViewer GetSentNotifications()
        {
            return WorkflowNotificationHelper.EmailWorkflowNotification();
        }

        public bool GetIsUserInWorkflow(int nodeId)
        {
            var userInWorkflow = true;
            var currentUser = SecurityHelper.GetLoggedInUser();
            if (nodeId > 0 && currentUser.id > -1)
            {
                var userIds = WorkflowStateHelper.GetWorkflowUserIds(nodeId);
                if (userIds != null && userIds.Any() && !userIds.Contains(currentUser.id))
                {
                    userInWorkflow = false;
                }
            }
            return userInWorkflow;
        }

        public List<WorkflowNotificationModel> GetNotificationList(string filterBy = "all")
        {
            bool? sent = null;
            bool? deleted = null;

            if (filterBy == "sent")
            {
                sent = true;
            }
            else if(filterBy == "deleted")
            {
                deleted = true;
            }
            else if(filterBy == "queued")
            {
                sent = false;
                deleted = false;
            }
            else if(filterBy == "all")
            {
                sent = null;
                deleted = false;    //don't show deleted by default
            }

            var notificationList = WorkflowNotificationHelper.GetNotificationList(sent, deleted);
            return notificationList;
        }

        public string GetNoWorkflowMessage(int nodeId = 0)
        {
            var message = WorkflowHelper.GetNoWorkflowMessage(nodeId);
            return message;
        }

        public List<NodeItem> GetDefaultAssignmentList()
        {
            return WorkflowHelper.SetDefaultWorkflowAssignment();
        }

    }
}