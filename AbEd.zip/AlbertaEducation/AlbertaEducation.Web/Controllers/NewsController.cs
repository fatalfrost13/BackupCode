﻿namespace AlbertaEducation.Web.Controllers
{
    using System.Linq;

    using Helpers;
    using Models;

    using System.Web;

    public class NewsController : BaseController
    {
        public NewsItem GetNewsByNodeId(int id)
        {
            // return NewsHelper.GetNewsItem(umbracoHelper.GetById(id), HttpContext.Current);
            return NewsHelper.GetNewsItemCached(umbracoHelper.GetById(id), HttpContext.Current);
        }

        public Topic GetNewsTopic(bool loadNews = false, string newsType = "")
        {
            var searchFilter = CacheHelper.GetUserSearchFilter();
            if (loadNews)
            {
                searchFilter.NewsType = newsType;
                searchFilter.ApplyChanges();
            }

            var newsTopic = TopicHelper.TopicList(searchFilter).TopicList.SingleOrDefault(i => i.NewsTopic);
            if (newsTopic != null)
            {
                return newsTopic;
            }
            
            return NewsHelper.GetNewsTopic(searchFilter, HttpContext.Current);
        }
    }
}