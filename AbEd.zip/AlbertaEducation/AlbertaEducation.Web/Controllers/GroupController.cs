﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlbertaEducation.Web.Controllers
{
    using System.Net;
    using System.Net.Http;
    using System.Web.Http;

    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    using Umbraco.Web.WebApi;

    public class GroupController: UmbracoApiController
    {
        public List<EducationGroupModel> GetGroupList()
        {
            return GroupHelper.GetGroupList();
        }
        
        public List<EducationGroupModel> GetUnassignedGroupList(int nodeId)
        {
            return GroupHelper.GetUnassignedGroupList(nodeId);
        }

        public EducationGroupModel GetGroup(int groupId, bool loadAssignedUsers = false)
        {
            List<UmbracoUserModel> allUsers = null;
            if (loadAssignedUsers)
            {
                allUsers = SecurityHelper.GetUsers();
            }
            return GroupHelper.GetGroup(groupId, allUsers);
        }

        public List<UmbracoUserModel> GetUserList()
        {
            return null;
        } 

        public EducationGroupModel GetNewGroup(string groupName)
        {
            var educationGroup = GroupHelper.AddGroup(groupName);
            return educationGroup;
        }

        public HttpResponseMessage DeleteGroup([FromBody] EducationGroupModel groupItem)
        {
            var deleted = GroupHelper.DeleteGroup(groupItem.Id);
            HttpResponseMessage response;
            if (deleted)
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent($"The group '{groupItem.Name}' has been removed.");
            }
            else
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent($"The group '{groupItem.Name}' could not be removed.");
            }
            return response;
        }

        public HttpResponseMessage SaveGroup([FromBody] EducationGroupModel groupItem)
        {
            var sessionId = GroupHelper.SaveGroup(groupItem);
            var saved = sessionId != Guid.Empty;
            HttpResponseMessage response;
            if (saved)
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent(sessionId.ToString());
            }
            else
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent(string.Empty);
            }
            return response;
        }

        public List<UmbracoUserModel> GetSavedUserAssignments(int groupId, Guid sessionId, string savedUserIds = "")
        {
            var usersAdded = new List<UmbracoUserModel>();
            if (!string.IsNullOrEmpty(savedUserIds))
            {
                var userIds = savedUserIds.Split(',').Select(int.Parse).ToList();
                usersAdded = GroupHelper.AddUserAssignments(groupId, userIds, sessionId);
            }
            return usersAdded;
        }

        public List<UmbracoUserModel> GetRemovedUserAssignments(int groupId, Guid sessionId, string removedUserIds)
        {
            var usersRemoved = new List<UmbracoUserModel>();
            if (!string.IsNullOrEmpty(removedUserIds))
            {
                var userIds = removedUserIds.Split(',').Select(int.Parse).ToList();
                usersRemoved = GroupHelper.RemoveUserAssignments(groupId, userIds, sessionId);
            }
            return usersRemoved;
        }
    }
}