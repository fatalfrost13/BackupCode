﻿using System.Web.Http;
using IomerBase.U7.DataDefinition;

using Umbraco.Core;

namespace AlbertaEducation.Web.Controllers
{
    using System;

    using Umbraco.Core.Logging;

    public class BlogController : ApiController
    { 
        [HttpPost]
        public bool SubmitBlogComment([FromBody]SubmitComment comment)
        {
            try
            {
                var contentService = ApplicationContext.Current.Services.ContentService;
                var blogItem = contentService.GetById(comment.blogItemId);
                if (blogItem.Id > 0 && blogItem.ContentType.Alias == DocumentTypes.blogItem.ToString())
                {
                    var newComment = contentService.CreateContent(comment.title, comment.blogItemId, DocumentTypes.blogComment.ToString());
                    newComment.SetValue(DocumentFields.userComment.ToString(), comment.comment);
                    newComment.SetValue(DocumentFields.userName.ToString(), comment.username);
                    newComment.SetValue(DocumentFields.requiresApproval.ToString(), true);
                    contentService.Save(newComment);
                }
                return true;
            }
            catch (Exception ex)
            {
                LogHelper.Error<BlogController>("Iomer caught error on BlogController.SubmitBlogComment().", ex);
                return false;
            }
        }

        public class SubmitComment
        {
            public int blogItemId { get; set; }
            public string comment { get; set; }
            public string title { get; set; }
            public string username { get; set; }
        }
    }
}
