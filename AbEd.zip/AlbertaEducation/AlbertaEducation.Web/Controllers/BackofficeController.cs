﻿using System.Collections.Generic;
using System.Linq;

using Umbraco.Core.Models;

namespace AlbertaEducation.Web
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Web;

    using IomerBase.Models;
    using IomerBase.U7.ApiClasses;
    using IomerBase.U7.DataDefinition;
    using IomerBase.U7.Models;

    using Umbraco.Web.WebApi;

    using DataContext;
    using Models;
    using Helpers;
    using System.Web.Http;

    using Iomer.Umbraco.Extensions.Content;

    using Umbraco.Core.Logging;
    using Umbraco.Web;
    using System.Net.Http;
    using System.Net;
    public class BackofficeController : UmbracoApiController
    {
        public static UmbracoHelper _umbracoHelper;
        public static UmbracoHelper umbracoHelper
        {
            get
            {
                if (_umbracoHelper == null || HttpContext.Current == null)
                {
                    _umbracoHelper = CustomUmbracoHelper.GetUmbracoHelper();
                }
                return _umbracoHelper;
            }
        }
        // GET: /Backoffice/
        public List<GenericItem> GetInheritItems(int nodeId, string alias)
        {
            var myList = new List<GenericItem>();

            var currentNode = umbracoHelper.GetById(nodeId);

            if (currentNode == null || currentNode.Id == 0)
            {
                //not published
                var firstPublishedNodeId = ContentUtility.FirstPublishedParentNodeId(nodeId);
                if (firstPublishedNodeId > 0)
                {
                    currentNode = umbracoHelper.GetById(firstPublishedNodeId);
                }
            }
            else
            {
                var parentId = currentNode.Parent.Id;
                if (parentId > 0)
                {
                    currentNode = umbracoHelper.GetById(parentId);
                }
            }
            //var currentNodeId = nodeId;
            if (currentNode != null && currentNode.Id > 0)
            {
                var itemNodes = currentNode.GetNodeListInherit(alias);

                foreach (var itemNode in itemNodes)
                {
                    myList.Add(new GenericItem { Value = itemNode.Id.ToString(), Text = itemNode.GetTitle() });
                }
            }

            return myList;
        }

        // GET: /Backoffice/
        public GenericItem GetInheritField(int nodeId, string alias)
        {
            var myField = new GenericItem();

            var currentNode = umbracoHelper.GetById(nodeId);

            if (currentNode != null && currentNode.Id == 0)
            {
                //not published
                var firstPublishedNodeId = ContentUtility.FirstPublishedParentNodeId(nodeId);
                if (firstPublishedNodeId > 0)
                {
                    currentNode = umbracoHelper.GetById(firstPublishedNodeId);
                }
            }

            if (currentNode != null && currentNode.Id > 0)
            {
                var nodeValue = currentNode.GetNodeValueInherit(alias);
                myField.Value = nodeValue;
                myField.Text = nodeValue;
            }

            return myField;
        }

        // GET: /Backoffice/
        public List<string> GetInheritStrings(int nodeId, string alias)
        {
            var currentNode = umbracoHelper.GetById(nodeId);
            return currentNode.GetNodeStringsInherit(alias).ToList();
        }

        // GET: /Backoffice/
        public UmbracoNode GetDashboardContent(int nodeId)
        {
            var node = UmbracoNodeHelper.GetNodeData(nodeId.ToString(), "", "-1");
            return node;
        }

        public NodeItem GetNodeData(int nodeId)
        {
            return NodeItemHelper.GetNodeData(nodeId);
        }

        // GET: /Backoffice/
        public int[] GetWorkflowLevels()
        {
            var levels = WorkflowHelper.GetWorkflowLevels();
            return levels;
        }
        
        public Guid GetSessionId()
        {
            return Guid.NewGuid();
        }

        // GET: /Backoffice/
        public List<WorkflowAssignmentModel> GetWorkflowAssignments(int nodeId)
        {
            var assignments = WorkflowHelper.GetWorkflowAssignments(nodeId);
            return assignments;
        }

        public List<WorkflowAssignmentModel> GetWorkflowNotificationAssignments(int nodeId)
        {
            var assignments = WorkflowHelper.GetWorkflowAssignments(nodeId, true);
            return assignments;
        }

        public HttpResponseMessage SaveAssignment([FromBody] WorkflowAssignmentModel assignmentItem)
        {
            WorkflowHelper.SaveAssignment(assignmentItem, assignmentItem.SessionId);
            HttpResponseMessage response;
            response = this.Request.CreateResponse(HttpStatusCode.Accepted);
            response.Content = new StringContent(assignmentItem.SessionId.ToString());
            return response;
        }


        public HttpResponseMessage DeleteAssignment([FromBody] WorkflowAssignmentModel assignmentItem)
        {
            var deleted = WorkflowHelper.DeleteWorkflowAssignment(assignmentItem.Id, assignmentItem.SessionId, assignmentItem.Notification);
            HttpResponseMessage response;
            if (deleted)
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent($"The workflowAssignment for group '{assignmentItem.EducationGroupName}' on node '{assignmentItem.NodeId}' has been removed.");
            }
            else
            {
                response = this.Request.CreateResponse(HttpStatusCode.Accepted);
                response.Content = new StringContent($"The workflowAssignment for group '{assignmentItem.EducationGroupName}' on node '{assignmentItem.NodeId}' could not be removed.");
            }
            return response;
        }

        public WorkflowInitialState GetWorkflowInitialState()
        {
            var userList = SecurityHelper.GetUsers();
            var groupList = GroupHelper.GetGroupList(userList);

            var workflowConfiguration = new WorkflowInitialState {
                WorkflowActionList = WorkflowHelper.GetWorkflowActions(),
                WorkflowStatusList = WorkflowHelper.GetWorkflowStatuses(),
                UserTypeList = SecurityHelper.GetUserTypes(),
                UserList = userList,
                GroupList = groupList
            };
            return workflowConfiguration;
        }

        // GET: /Backoffice/
        public List<Workflow> GetWorkflowHistoryItems(int nodeId)
        {
            var workflows = WorkflowHelper.GetWorkflowHistoryItems(nodeId);
            return workflows;
        }

        //
        // GET: /Backoffice/
        public List<WorkflowStatus> GetWorkflowStatuses()
        {
            var workflowStatus = WorkflowHelper.GetWorkflowStatuses();
            return workflowStatus;
        }

        //
        // GET: /Backoffice/
        public List<WorkflowAction> GetWorkflowActions()
        {
            var workflowActions = WorkflowHelper.GetWorkflowActions();
            return workflowActions;
        }
        //
        // GET: /Backoffice/
        public List<UmbracoUserTypeModel> GetUserTypes()
        {
            var userTypes = SecurityHelper.GetUserTypes();
            return userTypes;
        }

        //
        // GET: /Backoffice/
        public List<UmbracoUserModel> GetUsers()
        {
            var users = SecurityHelper.GetUsers();
            return users;
        }

        // GET: /Backoffice/
        public WorkflowStatus GetCurrentStatus(int nodeId, bool top)
        {
            var statuses = WorkflowHelper.GetCurrentStatus(nodeId, top);
            return statuses;
        }

        // GET: /Backoffice/
        public List<UmbracoUserTypeModel> GetSelectedUserTypes(int nodeId)
        {
            var list = SecurityHelper.GetSelectedUserTypes(nodeId);
            return list;
        }

        // GET: /Backoffice/
        [HttpPost]
        public PublishRequestWithMessage SubmitSendToPublish(int nodeId, int workflowAction, string notes = "", int selectedGroupId = -1, bool published = false, int level = -1)
        {
            var uploadedFile = WorkflowHelper.UploadFile();
            var publishState = WorkflowHelper.SubmitSendToPublish(nodeId, workflowAction, notes, selectedGroupId, published, level, uploadedFile);
            publishState.NodeData = NodeItemHelper.GetContentData(nodeId);
            return publishState;
        }

        public string GetCurrentUploadFile(int nodeId)
        {
            return WorkflowHelper.CurrentUploadFile(nodeId);
        }

        // GET: /Backoffice/
        public UmbracoUserModel GetLoggedInUser()
        {
            var user = SecurityHelper.GetLoggedInUser();
            return user;
        }

        public void SetSaveWithoutWorkflowFlag(int nodeId)
        {
            HttpCookie workflowFlag = new HttpCookie("SaveWithoutWorkflow-" + nodeId);
            workflowFlag["SaveWithoutWorkflow"] = "True";
            DateTime now = DateTime.Now;
            workflowFlag.Expires = now.AddMinutes(15);
            HttpContext.Current.Response.Cookies.Add(workflowFlag);
        }

        // GET: /Backoffice/
        public List<int> GetUserLevels(int nodeId)
        {
            var userLevels = WorkflowHelper.GetUserLevels(GetLoggedInUser(), nodeId);
            return userLevels;
        }

        public List<int> GetTopicsByJourney(int journeyNodeId)
        {
            var topicList = CacheHelper.GetTopicListCache;
            var topics = topicList.Where(t => t.JourneyIds.Contains(journeyNodeId)).Select(t => t.NodeId).ToList();
            return topics;
        }

        public List<BlogComment> GetBlogComments(int blogItemId)
        {
            var contentService = this.ApplicationContext.Services.ContentService;
            var comments = new List<BlogComment>();
            try
            {
                if (blogItemId > 0)
                {
                    var blogItem = contentService.GetById(blogItemId);
                    var commentDocs = blogItem.Children().Where(n => n.ContentType.Alias == DocumentTypes.blogComment.ToString());
                    comments = commentDocs.Select(n => BlogHelper.GetBlogComment(n)).ToList();
                }
            }
            catch (Exception ex)
            {
                LogHelper.Error<BackofficeController>($"Iomer caught error on BackofficeController.GetBlogComments(). Id: {blogItemId}", ex);
            }
            return comments;
        }

        [HttpPost]
        public bool ModerateBlogComment([FromBody]BlogComment blogComment)
        {
            try
            {
                if (blogComment.NodeId > 0)
                {
                    var contentService = this.ApplicationContext.Services.ContentService;
                    var comment = contentService.GetById(blogComment.NodeId);
                    if (comment.ContentType.Alias == DocumentTypes.blogComment.ToString())
                    {
                        try
                        {
                            comment.SetValue(DocumentFields.approved.ToString(), blogComment.Approved);
                            comment.SetValue(DocumentFields.requiresApproval.ToString(), false);
                            contentService.SaveAndPublishWithStatus(comment);
                        }
                        catch (System.Configuration.ConfigurationErrorsException ex)
                        {
                            //Sometimes getting a mysql authorization exception (inner) though the save and publish occurs
                            //Catching here allows ModerateBlogComments to moderate all of its comments without issue
                            LogHelper.Error<BackofficeController>("Iomer Error. MySQL Authorization Exception on BackofficeController.ModerateBlogComment()", ex);
                        }
                        return true;
                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                LogHelper.Error<BackofficeController>("Iomer caught error on BackofficeController.ModerateBlogComment().", ex);
                throw;
            }
        }

        public bool ModerateBlogComments([FromBody]List<BlogComment> blogComments)
        {
            try
            {
                if (blogComments.Any())
                {
                    blogComments.ForEach(n => this.ModerateBlogComment(n));
                    return true;
                }
                return false;
            }
            catch (Exception ex)
            {
                LogHelper.Error<BackofficeController>("Iomer caught error on BackofficeController.ModerateBlogComments().", ex);
                throw;
            }
        }

        [HttpGet]
        public bool EmptyRecycleBin()
        {
            try
            {
                this.Services.ContentService.EmptyRecycleBin();
                return true;
            }
            catch (Exception ex)
            {
                LogHelper.Error<BackofficeController>("Iomer caught error on BackofficeController.EmptyRecycleBin().", ex);
                return false;
            }
        }
    }
}
