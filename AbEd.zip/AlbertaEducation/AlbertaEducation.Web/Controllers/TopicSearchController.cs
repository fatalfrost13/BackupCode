﻿namespace AlbertaEducation.Web.Controllers
{
    using System.Collections.Generic;
    using System.Web.Http;

    using Helpers;
    using Models;

    public class TopicSearchController: ApiController
    {

        public SearchFilter GetJourneyFilter(int journeyId)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter.JourneyIds = new List<int> { journeyId };
            userFilter.ShowSearch = false;
            userFilter.ApplyChanges();
            return userFilter;
        }

        public SearchFilter GetCategoryFilter(int categoryId)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            var categoryIds = userFilter.CategoryIds;
            if (categoryIds.Contains(categoryId))
            {
                userFilter = userFilter.FilterRemoveCategory(categoryId, true);
            }
            else
            {
                userFilter = userFilter.FilterAddCategory(categoryId, true);
            }
            userFilter.ApplyChanges();
            return userFilter;
        }

        public SearchFilter GetPersonaFilter(string persona)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter.Persona = persona;
            userFilter.ApplyChanges();
            return userFilter;
        }

        public SearchFilter GetLanguageFilter(string language)
        {
            var userFilter = CacheHelper.GetUserSearchFilter();
            userFilter = userFilter.FilterChangeLanguage(language, true);
            userFilter.ApplyChanges();
            return userFilter;
        }

    }
}
