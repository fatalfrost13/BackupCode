﻿

namespace AlbertaEducation.Web.Controllers
{
    using System;
    using System.Web.Http;

    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;
    using System.Web;

    using Iomer.Umbraco.Extensions.Content;

    using IomerBase.U7.DataDefinition;

    using Umbraco.Core.Logging;

    public class JobController : ApiController
    {
        public Topic GetJobTopic()
        {
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                return JobListingHelper.GetJobListingTopic(userFilter, HttpContext.Current);
            }
            catch (Exception ex)
            {
                LogHelper.Error<Topic>("Iomer caught error on JobController.GetJobTopic().", ex);
                throw;
            }
        }
    }
}