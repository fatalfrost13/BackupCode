﻿using System.Linq;

namespace AlbertaEducation.Web.Controllers
{
    using System;

    using Helpers;
    using Models;
    using Iomer.Umbraco.Extensions.Content;

    using IomerBase.U7.DataDefinition;


    using Umbraco.Core.Logging;

    public class SubTopicController : BaseController
    {
        //public SubTopic GetInitialSubTopic(int currentNodeId)
        //{
        //    SubTopic subTopic = null;
        //    var currNode = umbracoHelper.GetById(currentNodeId);
        //    try
        //    {
        //        var userFilter = CacheHelper.GetUserSearchFilter();

        //        if (currNode != null && currNode.Id > 0)
        //        {

        //            int subTopicNodeId;
        //            if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
        //            {
        //                var topic = TopicHelper.GetTopic(currentNodeId, userFilter);
        //                subTopicNodeId = topic.SubTopics.Any() ? topic.SubTopics[0].NodeId : 0;
        //                userFilter.Language = topic.Language;
        //            }
        //            else
        //            {
        //                subTopicNodeId = currNode.DocumentTypeAlias != DocumentTypes.subTopic.ToString() ? currNode.FindContainerNodeId(DocumentTypes.subTopic.ToString()) : currentNodeId;
        //            }
        //            if (subTopicNodeId > 0)
        //            {
        //                //var originalPersona = CacheHelper.UserSearchFilter.Persona;
        //                if (currNode.DocumentTypeAlias != DocumentTypes.subTopic.ToString())
        //                {
        //                    var subtopicPersonaNodeId = currNode.FindContainerNodeId(DocumentTypes.personaContent.ToString());
        //                    if (subtopicPersonaNodeId > 0)
        //                    {
        //                        var toolboxPersona = umbracoHelper.GetById(subtopicPersonaNodeId).Name;
        //                        userFilter.Persona = toolboxPersona;
        //                    }
        //                }
        //                subTopic = SubTopicHelper.GetSubTopic(subTopicNodeId, userFilter);
        //                userFilter.Language = subTopic?.Language;
        //                //CacheHelper.UserSearchFilter.Persona = originalPersona;
        //            }
        //            userFilter.ApplyChanges();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.Error<SubTopicController>($"Iomer caught error on SubTopicController.GetInitialSubTopic(). Node: {currNode.Id} - {currNode.Name}", ex);
        //    }
        //    return subTopic;
        //}

        //public SubTopic GetSubTopic(int subTopicId)
        //{
        //    var userFilter = CacheHelper.GetUserSearchFilter();
        //    return SubTopicHelper.GetSubTopic(subTopicId, userFilter);
        //}
    }
}

