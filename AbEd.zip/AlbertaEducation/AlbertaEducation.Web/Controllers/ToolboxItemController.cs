﻿namespace AlbertaEducation.Web.Controllers
{
    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;

    public class ToolboxItemController : BaseController
    {

        public BlogItem GetBlogItem(int currentNodeId)
        {
            var node = umbracoHelper.GetById(currentNodeId);
            var item = BlogHelper.GetBlogItem(node);
            return item;
        }

        public EventItem GetEventItem(int currentNodeId)
        {
            var node = umbracoHelper.GetById(currentNodeId);
            var item = EventHelper.GetEventItem(node);
            return item;
        }

        public ContactItem GetContactItem(int currentNodeId)
        {
            var node = umbracoHelper.GetById(currentNodeId);
            var item = ContactHelper.GetContactItem(node);
            return item;
        }
    }
}