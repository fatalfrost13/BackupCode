﻿using System.Collections.Generic;

namespace AlbertaEducation.Web.Controllers
{
    using System.Web.Http;

    using AlbertaEducation.Web.Helpers;
    using AlbertaEducation.Web.Models;
    using System.Linq;
    public class JourneyController: ApiController
    {
        public List<Journey> GetJourneyList()
        {
            return JourneyHelper.AllJourneys;
        } 

        //public Journey GetJourney(int journeyId, bool apply = false)
        //{
        //    var journey = JourneyHelper.GetJourney(journeyId, true);
        //    if (apply)
        //    {
        //        var searchFilter = AlbertaEducation.Web.Helpers.CacheHelper.GetUserSearchFilter();
        //        searchFilter.JourneyIds.Clear();
        //        searchFilter.JourneyIds.Add(journey.NodeId);
        //        searchFilter.ApplyChanges();
        //    }
        //    return journey;
        //}

        public Journey GetJourney(int journeyId, bool apply = false)
        {
            //var journey = JourneyHelper.GetJourney(journeyId, true);
            var journey = JourneyHelper.AllJourneys.FirstOrDefault(i => i.NodeId == journeyId);
            if (apply)
            {
                var searchFilter = AlbertaEducation.Web.Helpers.CacheHelper.GetUserSearchFilter();
                searchFilter.JourneyIds.Clear();
                searchFilter.JourneyIds.Add(journey.NodeId);
                searchFilter.ApplyChanges();
            }
            return journey;
        }
    }
}
