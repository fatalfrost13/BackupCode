﻿using Ae.Health;
using AlbertaEducation.Web.Helpers;
using AlbertaEducation.Web.Models;
using Iomer.Umbraco.Extensions.Content;
using Iomer.Umbraco.Extensions.Query;
using IomerBase.U7.DataDefinition;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AlbertaEducation.Web.Controllers
{
    public class TestController : BaseController
    {
        // GET: /api/test/Method
        public List<int> GetPreviewItems()
        {
            var umbracoHelper = CustomUmbracoHelper.GetUmbracoHelper();
            var toolbox = umbracoHelper.GetById(4554);
            var previewItems = ToolboxHelper.GetPreviewItems(toolbox);
            return previewItems;
        }


        /// <summary>
        /// Code for performance testing
        /// can be viewed /app.health
        /// </summary>
        public void TestCode()
        {
            var indicator = Health.GetHealthIndicator("Umbraco", "JourneyList");
            var sw = indicator.Start();
            try
            {
                //some code block
                sw.Success();
            }
            catch (Exception ex)
            {
                //exception
                sw.Failure(ex);
            }
            
        }

        public List<ToolboxItem> GetTestStuff()
        {
            //var topicNodeId = 53854;
            var subTopicNodeId = 53856;
            var testNode = umbracoHelper.GetById(subTopicNodeId);
            var indicator = Health.GetHealthIndicator("Umbraco", "GetToolboxItems");
            var sw = indicator.Start();
            //var ids1 = testNode.GetNodeIdsInherit(DocumentFields.journeys.ToString(),null);
            var toolboxItems = ToolboxHelper.GetToolboxItems(testNode);
            sw.Success();

            //var indicator1 = Health.GetHealthIndicator("Umbraco", "method2");
            //var sw1= indicator1.Start();
            //var ids2 = testNode.GetNodeIdsInherit(DocumentFields.journeys.ToString()).ToList();

            //sw1.Success();
            return toolboxItems;
        }

        public bool GetTestResults()
        {
            var indicator = Health.GetHealthIndicator("Umbraco", "GetTopicDetailsViewModel");
            var sw = indicator.Start();

            var topicNodeId = 53854;
            //var subTopicNodeId = 53856;
            var testNode = umbracoHelper.GetById(topicNodeId);
            var viewModel = ViewModelHelper.GetTopicDetailsViewModel(testNode);
            viewModel.CurrentPage = null;
            viewModel.UmbracoHelper = null;

            sw.Success();

            return true;
        }

        public List<string> GetMetaData()
        {
            //var topicNodeId = 53854;
            var subTopicNodeId = 53856;
            var testNode = umbracoHelper.GetById(subTopicNodeId);

            var keywords = testNode.GetNodeStringsInherit(DocumentFields.metaKeywords.ToString(), true).ToList();

            //var indicator = Health.GetHealthIndicator("Umbraco", "method1");
            //var sw = indicator.Start();
            ////var ids1 = testNode.GetNodeIdsInherit(DocumentFields.journeys.ToString(),null);
            //var values = ContentUtility.GetNodeValueInheritOLD(testNode, "language");
            //sw.Success();

            //var indicator1 = Health.GetHealthIndicator("Umbraco", "method2");
            //var sw1 = indicator1.Start();
            //var values2 = ContentUtility.GetNodeValueInherit(testNode, "language");
            //sw1.Success();


            return keywords;
        }
    }
}