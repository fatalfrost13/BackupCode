﻿using System;
using System.Linq;
using System.Web;

namespace AlbertaEducation.Web.Controllers
{

    using Helpers;

    using Models;

    using Iomer.Umbraco.Extensions.Content;
    using Iomer.Umbraco.Extensions.Query;

    using IomerBase.U7.DataDefinition;

    using Umbraco.Core.Logging;
    using Umbraco.Web;
    using System.Collections.Generic;
    public class TopicController : BaseController
    {

        private static int? MinistryJourneyId = QueryUtility.GetPublishedContentByType(DocumentTypes.journey.ToString()).FirstOrDefault(n => n.GetTitle() == "Ministry")?.Id;
        public TopicSearch GetTopicListBatch(int skip = 0, int batchSize = 0, string journeyIds = "", string categoryIds = "", string persona = "", int orderBy = -1, int direction = -1)
        {
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                var filterChanged = false;
                if (!string.IsNullOrEmpty(journeyIds))
                {
                    userFilter.JourneyIds = journeyIds.Split(',').Select(i => int.Parse(i)).ToList();
                    filterChanged = true;
                }
                if (!string.IsNullOrEmpty(categoryIds))
                {
                    userFilter.CategoryIds = categoryIds.Split(',').Select(i => int.Parse(i)).ToList();
                    filterChanged = true;
                }
                if (!string.IsNullOrEmpty(persona))
                {
                    userFilter.Persona = persona;
                    filterChanged = true;
                }
                if (orderBy >= (int)OrderBy.Default)
                {
                    userFilter.Sort.OrderBy = (OrderBy)orderBy;
                    filterChanged = true;
                }
                if (direction >= (int)SortDirection.Ascending)
                {
                    userFilter.Sort.SortDirection = (SortDirection)direction;
                    filterChanged = true;
                }

                if (filterChanged == true)
                {
                    userFilter.ApplyChanges();
                }
                var topicSearch = TopicHelper.TopicList(userFilter, true);
                topicSearch.TopicCount = topicSearch.TopicList.Count;
                if (batchSize > 0)
                {
                    topicSearch.TopicList = topicSearch.TopicList.Skip(skip).Take(batchSize).ToList();
                }
                else if (batchSize < 0)
                {
                    topicSearch.TopicList.Clear();
                }

                return topicSearch;
            }
            catch (Exception ex)
            {
                LogHelper.Error<TopicController>("Iomer caught error on GetTopicListBatch()", ex);
                throw;
            }

        }
        public TopicSearch GetTopicList()
        {
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                var topicSearch = TopicHelper.TopicList(userFilter, true);
                topicSearch.TopicCount = topicSearch.TopicList.Count;
                return topicSearch;
            }
            catch (Exception ex)
            {
                LogHelper.Error<TopicController>("Iomer caught error on GetTopicList()", ex);
                throw;
            }

        }

        public Topic GetTopicByNodeId(int id)
        {
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                var topicList = TopicHelper.TopicList(userFilter).TopicList;
                var topic = topicList.SingleOrDefault(i => i.NodeId == id);
                //return TopicHelper.GetTopic(id, userFilter);
                return topic;
            }
            catch (Exception ex)
            {
                LogHelper.Error<TopicController>("Iomer caught error on GetTopicByNodeId()", ex);
                throw;
            }
        }

        public Topic GetTopicForceLanguageByNodeId(int id)
        {
            try
            {
                var topicNode = umbracoHelper.GetById(id);
                var language = topicNode.GetNodeValueInherit(DocumentFields.language.ToString());
                var userFilter = CacheHelper.GetUserSearchFilter();
                userFilter.Language = language;

                var topicList = TopicHelper.TopicList(userFilter).TopicList;
                var singleTopic = topicList.SingleOrDefault(i => i.NodeId == id);
                //var singleTopic = TopicHelper.GetTopic(id, userFilter);
                //singleTopic = singleTopic.LoadPromoInfo(userFilter);

                return singleTopic;
            }
            catch (Exception ex)
            {
                LogHelper.Error<TopicController>("Iomer caught error on GetTopicForceLanguageByNodeId()", ex);
                throw;
            }
        }

        //public Topic GetInitialTopic(int currentNodeId)
        //{
        //    Topic topic = null;
        //    var currNode = umbracoHelper.GetById(currentNodeId);
        //    try
        //    {
        //        var userFilter = CacheHelper.GetUserSearchFilter();

        //        if (currNode != null && currNode.Id > 0)
        //        {
        //            if (currNode.DocumentTypeAlias == DocumentTypes.topic.ToString())
        //            {
        //                topic = TopicHelper.GetTopic(currentNodeId, userFilter);
        //            }
        //            else if (currNode.DocumentTypeAlias == DocumentTypes.internalNewsItem.ToString())
        //            {
        //                if (MinistryJourneyId.HasValue)
        //                {
        //                    userFilter = userFilter.FilterJourney(MinistryJourneyId.Value, true);
        //                }
        //                topic = NewsHelper.GetNewsTopic(userFilter, HttpContext.Current);
        //            }
        //            else
        //            {
        //                var topicNodeId = currNode.FindContainerNodeId(DocumentTypes.topic.ToString());
        //                topic = TopicHelper.GetTopic(topicNodeId, userFilter);
        //            }
        //            topic = topic.LoadPromoInfo(userFilter);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        LogHelper.Error<TopicController>($"Iomer caught error on TopicController.GetInitialTopic(). Node: {currNode.Id} - {currNode.Name}", ex);
        //    }
        //    return topic;
        //}

        public List<Topic> GetTopRowTopics()
        {
            List<Topic> topRowTopics;
            try
            {
                var userFilter = CacheHelper.GetUserSearchFilter();
                var topicSearch = TopicHelper.TopicList(userFilter, true);
                //var filteredTopics = topicSearch.TopicList.Where(i => i.PromotedTopic || i.NewsTopic || i.JobTopic).ToList();
                //topRowTopics.AddRange(filteredTopics.Where(i => i.PromotedTopic));
                //topRowTopics.AddRange(filteredTopics.Where(i => i.NewsTopic));
                //topRowTopics.AddRange(filteredTopics.Where(i => i.JobTopic));
                //topRowTopics = topRowTopics.Take(4).ToList();

                topRowTopics = topicSearch.TopicList.Where(i => i.PromotedTopic || i.NewsTopic || i.JobTopic)
                    .OrderBy(i => i.PromotedTopic ? 0 : 1)
                    .ThenBy(i => i.NewsTopic ? 0 : 1)
                    .ThenBy(i => i.JobTopic ? 0 : 1).Take(4).ToList();

            }
            catch (Exception ex)
            {
                LogHelper.Error<Topic>($"Iomer caught error on TopicController.GetTopRowTopics().", ex);
                return null;
            }
            return topRowTopics;
        }

        public TopicDetailsViewModel GetTopicDetailsViewModel(int currentNodeId)
        {
            var currentPage = umbracoHelper.GetById(currentNodeId);
            var searchFilter = SearchHelper.InitializeSearch(false, currentPage);
            var viewModel = ViewModelHelper.GetTopicDetailsViewModel(currentPage, searchFilter);
            viewModel.UmbracoHelper = null;
            viewModel.SearchFilter = null;
            viewModel.ToolboxItem = null;
            viewModel.CurrentPage = null;
            return viewModel;
        }
        public TopicDetailsViewModel GetTopicDetailsViewModelWithParameters(int currentNodeId, string persona = "")
        {
            var currentPage = umbracoHelper.GetById(currentNodeId);
            var searchFilter = SearchHelper.InitializeSearch(false, currentPage);
            if (!string.IsNullOrEmpty(persona))
            {
                searchFilter.Persona = persona;
            }
            var viewModel = ViewModelHelper.GetTopicDetailsViewModel(currentPage, searchFilter);
            viewModel.UmbracoHelper = null;
            viewModel.SearchFilter = null;
            viewModel.ToolboxItem = null;
            viewModel.CurrentPage = null;
            return viewModel;
        }

    }
}
