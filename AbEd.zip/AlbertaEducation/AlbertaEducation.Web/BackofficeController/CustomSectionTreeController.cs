﻿namespace AlbertaEducation.Web.Backoffice
{
    using System.Net.Http.Formatting;
    using umbraco.BusinessLogic.Actions;

    using Umbraco.Web.Models.Trees;
    using Umbraco.Web.Mvc;
    using Umbraco.Web.Trees;

    [PluginController("CustomSection")]
    [Tree("CustomSection", "CustomSectionTree", "Custom Section", iconClosed: "icon-doc")]
    public class CustomSectionTreeController : TreeController
    {
        protected override TreeNodeCollection GetTreeNodes(string id, FormDataCollection queryStrings)
        {
            var nodes = new TreeNodeCollection();
            if (id == "-1") // root
            {
                var itemCache = this.CreateTreeNode("urlTracker", id, queryStrings, "Url Tracker", "icon-umb-content", false, "/CustomSection/");
                nodes.Add(itemCache);
                itemCache = this.CreateTreeNode("refreshCache", id, queryStrings, "Refresh Cache", "icon-help", false, "/CustomSection/CustomSectionTree/refreshCache/0");
                nodes.Add(itemCache);
                itemCache = this.CreateTreeNode("publishedPages", id, queryStrings, "Published Pages", "icon-umb-content", false, "/CustomSection/CustomSectionTree/publishedPages/0");
                nodes.Add(itemCache);
            }
            return nodes;
        }

        protected override MenuItemCollection GetMenuForNode(string id, FormDataCollection queryStrings)
        {
            var menu = new MenuItemCollection { DefaultMenuAlias = ActionNew.Instance.Alias };
            return menu;
        }
    }

    [PluginController("WorkflowSection")]
    [Tree("WorkflowSection", "WorkflowSectionTree", "Workflow Section", iconClosed: "icon-doc")]
    public class WorkflowSectionTreeController : TreeController
    {
        protected override TreeNodeCollection GetTreeNodes(string id, FormDataCollection queryStrings)
        {
            var nodes = new TreeNodeCollection();
            if (id == "-1") // root
            {
                var itemCache = this.CreateTreeNode("manageGroups", id, queryStrings, "Manage Groups", "icon-umb-content", false, "/WorkflowSection/WorkflowSectionTree/manageGroups/0");
                nodes.Add(itemCache);

                itemCache = this.CreateTreeNode("manageWorkflow", id, queryStrings, "Manage Workflow", "icon-umb-content", false, "/WorkflowSection/WorkflowSectionTree/manageWorkflow/0");
                nodes.Add(itemCache);

                itemCache = this.CreateTreeNode("viewNotifications", id, queryStrings, "View Notifications", "icon-umb-content", false, "/WorkflowSection/WorkflowSectionTree/viewNotifications/0");
                nodes.Add(itemCache);
            }
            return nodes;
        }

        protected override MenuItemCollection GetMenuForNode(string id, FormDataCollection queryStrings)
        {
            var menu = new MenuItemCollection { DefaultMenuAlias = ActionNew.Instance.Alias };
            return menu;
        }
    }
}
