﻿namespace IomerBase.Controllers
{
    using System;

    using Umbraco.Web.WebApi;
    using AlbertaEducation.Web.Helpers;

    public class CacheController : UmbracoApiController
    {
        public string GetLastRefreshDate(string type = "")
        {
            var refreshDateTime = new DateTime();
            switch (type)
            {
                case "topics":
                    refreshDateTime = Convert.ToDateTime(CacheHelper.GetTopicCache.RefreshDateTime);
                    break;
            }

            var refreshDate = TimeZoneInfo.ConvertTimeBySystemTimeZoneId(refreshDateTime, "Mountain Standard Time");
            var displayLastRefresh = refreshDate.ToString("MMMM d, yyyy h:mm tt");
            return displayLastRefresh;
        }

        public string GetNewRefreshDate(string type = "")
        {
            string message;
            try
            {
                switch (type)
                {
                    case "topics":
                        CacheHelper.ReloadTopicCache();
                        break;
                }
                
                message = $"<span style=\"color:green;\">Cache Data ({type}) has been refreshed!</span>";
            }
            catch (Exception ex)
            {
                message = $"An error has occurred: <span style=\"color:red;\">{ex}</span>";
            }
            return message;
        }

    }
}
