﻿namespace AlbertaEducation.Web.Backoffice
{
    using umbraco.businesslogic;
    using umbraco.interfaces;

    [Application("CustomSection", "CustomSection", "icon-car", 15)]
    public class CustomSectionApplication : IApplication { }

    [Application("WorkflowSection", "WorkflowSection", "icon-filter-arrows", 16)]
    public class WorkflowSectionApplication : IApplication { }
}
