﻿(function () {
    "use strict";

    window.addEventListener("load", function () {

        var $appWrap = $("#elections-form-app");

        $appWrap.on("click", ".accordion__header", function () {

            var $header = $(this);

            // expand or collapse this panel
            if ($header.next().is(":visible")) {
                $header.next().velocity("slideUp", { duration: 600 });

                // flip arrow icon
                $header.parent().addClass("accordion__panel--closed");
            }
            else {
                $header.next().velocity("slideDown", { duration: 600 });

                // flip arrow icon
                $header.parent().removeClass("accordion__panel--closed");
            }

            // hide the other panels
            $appWrap.find(".accordion__content").not($(this).next())
                .velocity("slideUp", { duration: 600 });

            // flip other arrow icons
            $header.parent().siblings().addClass("accordion__panel--closed");
        });
    });

}());