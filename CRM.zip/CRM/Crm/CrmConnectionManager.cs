﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.ServiceModel.Description;
using System.Web;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Discovery;
using ECC.Web.Data.Crm;

namespace ECC.Web.Data
{
    public class CrmConnectionManager : IDisposable
    {

        /// <summary>
        /// 
        /// </summary>
        public OrganizationServiceProxy Service { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public EccSvcContext EccSvcContext { get; set; }

        /// <summary>
        /// Return the URL of the CRM Organization.
        /// </summary>
        public string WebApplicationUrl { get; set; }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="businessUnitConfiguration"></param>
        public CrmConnectionManager()
        {
            this.Service = this.GetOrganizationService();
            this.EccSvcContext = new EccSvcContext(Service);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="service"></param>
        public CrmConnectionManager(OrganizationServiceProxy service)
        {
            this.Service = service;
            this.EccSvcContext = new EccSvcContext(service);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entityName"></param>
        /// <param name="entityRecordId"></param>
        /// <returns></returns>
        public string CreateCrmFormUrl(string entityName, Guid entityRecordId)
        {
            return string.Format("{0}/main.aspx?etn={1}&pagetype=entityrecord&id={2}", this.WebApplicationUrl, entityName, entityRecordId);
        }

        /// <summary>
        /// Sets the methods of the underlying <see cref="OrganizationServiceProxy" /> to be invoked under the 
        /// context of the System User associated with the specified unique identifier.
        /// </summary>
        /// <param name="systemUserId"></param>
        public void Impersonate(Guid systemUserId)
        {
            this.Service.CallerId = systemUserId;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public OrganizationServiceProxy GetOrganizationService()
        {
            var endpointType =
                (AuthenticationProviderType)
                (Enum.Parse(typeof(AuthenticationProviderType), ConfigurationManager.AppSettings["ConnectionMode"]));

            var url = string.Empty;
            var organizationName = string.Empty;

            if (endpointType == AuthenticationProviderType.ActiveDirectory)
            {
                url = ConfigurationManager.AppSettings["OnPremiseDiscoveryService"];
                organizationName = ConfigurationManager.AppSettings["OnPremiseOrganizationUniqueName"];
            }
            else if (endpointType == AuthenticationProviderType.LiveId)
            {
                url = ConfigurationManager.AppSettings["OnlineDiscoveryService"];
                organizationName = ConfigurationManager.AppSettings["OnlineOrganizationUniqueName"];
            }
            else
                throw new ApplicationException(
                    "The provided endpoint type is invalid. Please check the Connection Mode in the config file.");

            var serviceManagement =
                ServiceConfigurationFactory.CreateManagement<IDiscoveryService>(
                    new Uri(url));

            var credentials = GetCredentials(endpointType);

            // Get the discovery service proxy.
            using (var discoveryProxy =
                GetProxy<IDiscoveryService, DiscoveryServiceProxy>(serviceManagement, credentials))
            {
                // Obtain organization information from the Discovery service. 
                if (discoveryProxy != null)
                {
                    // Obtain information about the organizations that the system user belongs to.
                    var orgs = DiscoverOrganizations(discoveryProxy);
                    // Obtains the Web address (Uri) of the target organization.
                    var org = FindOrganization(organizationName, orgs.ToArray());
                    WebApplicationUrl = org.Endpoints[EndpointType.WebApplication];
                    url = org.Endpoints[EndpointType.OrganizationService];
                }
            }

            if (String.IsNullOrWhiteSpace(url))
            {
                throw new ApplicationException("Organization Service URL could not be determined.");
            }

            var orgServiceManagement =
                    ServiceConfigurationFactory.CreateManagement<IOrganizationService>(
                        new Uri(url));

            // Get the organization service proxy.

            var organizationProxy =
                GetProxy<IOrganizationService, OrganizationServiceProxy>(orgServiceManagement, credentials);
            // This statement is required to enable early-bound type support.
            organizationProxy.EnableProxyTypes();
            return organizationProxy;
        }

        /// <summary>
        /// Obtain the AuthenticationCredentials based on AuthenticationProviderType.
        /// </summary>
        /// <param name="endpointType">An AuthenticationProviderType of the CRM environment.</param>
        /// <returns>Get filled credentials.</returns>
        private AuthenticationCredentials GetCredentials(AuthenticationProviderType endpointType)
        {
            AuthenticationCredentials authCredentials = new AuthenticationCredentials();
            switch (endpointType)
            {
                case AuthenticationProviderType.ActiveDirectory:
                    authCredentials.ClientCredentials.Windows.ClientCredential =
                        new System.Net.NetworkCredential(ConfigurationManager.AppSettings["OnPremiseUsername"],
                            ConfigurationManager.AppSettings["OnPremisePassword"],
                            ConfigurationManager.AppSettings["OnPremiseDomain"]);
                    break;
                case AuthenticationProviderType.LiveId:
                    authCredentials.ClientCredentials.UserName.UserName = ConfigurationManager.AppSettings["OnlineUsername"];
                    authCredentials.ClientCredentials.UserName.Password = ConfigurationManager.AppSettings["OnlinePassword"];
                    authCredentials.SupportingCredentials = new AuthenticationCredentials();
                    //authCredentials.SupportingCredentials.ClientCredentials = Microsoft.Crm.Services.Utility.DeviceIdManager.LoadOrRegisterDevice();
                    break;
                default:
                    throw new ApplicationException("The provided endpoint type is invalid. Please check the Connection Mode in the config file.");
            }

            return authCredentials;
        }

        /// <summary>
        /// Discovers the organizations that the calling user belongs to.
        /// </summary>
        /// <param name="service">A Discovery service proxy instance.</param>
        /// <returns>Array containing detailed information on each organization that 
        /// the user belongs to.</returns>
        private OrganizationDetailCollection DiscoverOrganizations(
            IDiscoveryService service)
        {
            if (service == null) throw new ArgumentNullException("service");
            RetrieveOrganizationsRequest orgRequest = new RetrieveOrganizationsRequest();
            RetrieveOrganizationsResponse orgResponse =
                (RetrieveOrganizationsResponse)service.Execute(orgRequest);

            return orgResponse.Details;
        }

        /// <summary>
        /// Finds a specific organization detail in the array of organization details
        /// returned from the Discovery service.
        /// </summary>
        /// <param name="orgUniqueName">The unique name of the organization to find.</param>
        /// <param name="orgDetails">Array of organization detail object returned from the discovery service.</param>
        /// <returns>Organization details or null if the organization was not found.</returns>
        /// <seealso cref="DiscoveryOrganizations"/>
        private OrganizationDetail FindOrganization(string orgUniqueName,
            OrganizationDetail[] orgDetails)
        {
            if (String.IsNullOrWhiteSpace(orgUniqueName))
                throw new ArgumentNullException("orgUniqueName");
            if (orgDetails == null)
                throw new ArgumentNullException("orgDetails");
            OrganizationDetail orgDetail = null;

            foreach (OrganizationDetail detail in orgDetails)
            {
                if (String.Compare(detail.UniqueName, orgUniqueName,
                    StringComparison.InvariantCultureIgnoreCase) == 0)
                {
                    orgDetail = detail;
                    break;
                }
            }
            return orgDetail;
        }

        /// <summary>
        /// Generic method to obtain discovery/organization service proxy instance.
        /// </summary>
        /// <typeparam name="TService">
        /// Set IDiscoveryService or IOrganizationService type to request respective service proxy instance.
        /// </typeparam>
        /// <typeparam name="TProxy">
        /// Set the return type to either DiscoveryServiceProxy or OrganizationServiceProxy type based on TService type.
        /// </typeparam>
        /// <param name="serviceManagement">An instance of IServiceManagement</param>
        /// <param name="authCredentials">The user's Microsoft Dynamics CRM logon credentials.</param>
        /// <returns></returns>
        private TProxy GetProxy<TService, TProxy>(
            IServiceManagement<TService> serviceManagement,
            AuthenticationCredentials authCredentials)
            where TService : class
            where TProxy : ServiceProxy<TService>
        {
            Type classType = typeof(TProxy);

            if (serviceManagement.AuthenticationType !=
                AuthenticationProviderType.ActiveDirectory)
            {
                AuthenticationCredentials tokenCredentials =
                    serviceManagement.Authenticate(authCredentials);
                // Obtain discovery/organization service proxy for Federated, LiveId and OnlineFederated environments. 
                // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and SecurityTokenResponse.
                return (TProxy)classType
                    .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(SecurityTokenResponse) })
                    .Invoke(new object[] { serviceManagement, tokenCredentials.SecurityTokenResponse });
            }

            // Obtain discovery/organization service proxy for ActiveDirectory environment.
            // Instantiate a new class of type using the 2 parameter constructor of type IServiceManagement and ClientCredentials.
            return (TProxy)classType
                .GetConstructor(new Type[] { typeof(IServiceManagement<TService>), typeof(ClientCredentials) })
                .Invoke(new object[] { serviceManagement, authCredentials.ClientCredentials });
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(true);
        }

        protected virtual void Dispose(bool disposing)
        {
            /*
            if (disposing)
            {
                if (LaaSvcContext != null)
                {
                    LaaSvcContext.Dispose();
                    LaaSvcContext = null;
                }
                if (Service != null)
                {
                    Service.Dispose();
                    Service = null;
                }
            }
            */
        }
    }
}