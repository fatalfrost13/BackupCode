﻿using System.ServiceModel.Web;
namespace IomerBase.U7.Extensions
{
    public static class WebApi
    {
        public static void SetNoCache()
        {
            if (WebOperationContext.Current == null) return;
            var response = WebOperationContext.Current.OutgoingResponse;
            response.Headers.Add("Cache-Control", "no-store");
            response.Headers.Add("Pragma", "no-cache");
        }

    }
}