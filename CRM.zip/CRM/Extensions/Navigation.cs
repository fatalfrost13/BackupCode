﻿namespace IomerBase.U7.Extensions
{
    using global::Iomer.Umbraco.Extensions;

    using umbraco.NodeFactory;

    public static class Navigation
    {

        public static string SecondaryTitle(int Id)
        {
            var title = "";
            var currNode = new Node(Id);
            var tmpNode = currNode;
            var level = tmpNode.Level;

            while (level >= 2)
            {
                title = tmpNode.GetTitle();
                if (tmpNode.Parent != null && tmpNode.Parent.Id > 0)
                {
                    tmpNode = new Node(tmpNode.Parent.Id);
                    level = tmpNode.Level;
                }
                else
                {
                    level = -1;
                }
            }
            return title;
        }

    }
}