﻿using System.Web.Services.Protocols;
using IomerBase.Models;
using Microsoft.Crm.Sdk.Messages;

namespace ECC.Web.Extensions
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web.Security;

    using Applications.Framework.Web.Providers;

    using ECC.Web.Helpers;
    using ECC.Web.SurfaceControllers;

    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;

    using ECC.Web.Data.Crm;
    using ECC.Web.Models;

    public class CrmExtensionsController : CrmController
    {

        public CrmExtensionsController()
        {
        }

        public CrmExtensionsController(IOrganizationService organizationService)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = new EccSvcContext(service);
        }

        public CrmExtensionsController(IOrganizationService organizationService, EccSvcContext context)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = context;
        }

        public bool DeAssociateManyToManyEntityRecords(Entity moniker1, Entity moniker2, string strEntityRelationshipName)
        {
            try
            {
                // Create an AssociateEntities request.
                DisassociateEntitiesRequest request = new DisassociateEntitiesRequest();

                // Set the ID of Moniker1 to the ID of the lead.
                request.Moniker1 = new EntityReference { Id = moniker1.Id, LogicalName = moniker1.LogicalName };

                // Set the ID of Moniker2 to the ID of the contact.
                request.Moniker2 = new EntityReference { Id = moniker2.Id, LogicalName = moniker2.LogicalName };

                // Set the relationship name to associate on.
                request.RelationshipName = strEntityRelationshipName;

                // Execute the request.
                service.Execute(request);

                return true;
            }

            catch (SoapException ex)
            {
                return false;
            }
        }

        public bool AssociateManyToManyEntityRecords(Entity moniker1, Entity moniker2, string strEntityRelationshipName)
        {
            try
            {
                AssociateEntitiesRequest request = new AssociateEntitiesRequest();
                request.Moniker1 = new EntityReference { Id = moniker1.Id, LogicalName = moniker1.LogicalName };
                request.Moniker2 = new EntityReference { Id = moniker2.Id, LogicalName = moniker2.LogicalName };
                request.RelationshipName = strEntityRelationshipName;
                service.Execute(request);
                return true; 
            }
            catch (SoapException ex)
            {
                return false;
            }
        }

        public Account GetAccountById(Guid Id)
        {
            return DataContext.AccountSet.Where(a => a.AccountId == Id).SingleOrDefault();
        }

        public Account GetAccount(string email) 
        {

            return
                (
                    from a in this.DataContext.AccountSet 
                    join wm in this.DataContext.appl_webmembershipSet on a.AccountId.Value equals wm.ecc_account.Id
                    where
                        a.StateCode == AccountState.Active
                    where 
                        wm.statecode == appl_webmembershipState.Active
                        && wm.appl_name == email
                    select a
                )
                .SingleOrDefault();
        }

        public List<Contact> GetContacts(Account account)
        {
            var contactList = (
                    from c in this.DataContext.ContactSet
                    join a in this.DataContext.AccountSet on c.ecc_account_contact_Account.Id equals a.AccountId.Value
                    where
                        c.StateCode == ContactState.Active
                    where
                        a.AccountId.Value == account.AccountId.Value
                        && a.StateCode == AccountState.Active
                    orderby c.LastName
                    select c
                )
                .ToList();
            return contactList;
        }

        public List<GenericItem> GetAccountBuisnessType(Account account)
        {
            var businessTypeList = new List<GenericItem>();
            var existingBusinessTypeRelation = DataContext.ecc_account_ecc_businesstypeSet.Where(a => a.accountid == account.Id).ToList();
            foreach (var relation in existingBusinessTypeRelation)
            {
                var businessType = DataContext.ecc_businesstypeSet.SingleOrDefault(bt => bt.ecc_businesstypeId == relation.ecc_businesstypeid);
                var businessTypeTitle = businessType.ecc_title;
                if (businessType.ecc_businesstypeId != null)
                {
                    var businessTypeId = businessType.ecc_businesstypeId.Value;
                    businessTypeList.Add(new GenericItem { Text = businessTypeTitle, Value = businessTypeId.ToString() });
                }
            }
            return businessTypeList;
        }

        public bool IsMemberActive(Guid accountId, string status = "")
        {
            var membershipStatus = status != string.Empty ? status : GetMembershipStatus(accountId);
            var active = (membershipStatus == "Active");
            return active;
        }

        public string GetMembershipStatus(Guid accountId)
        {
            var status = string.Empty;
            var statusList = new List<string>();

            var statusLookup = new List<string> { 
                "Member", 
                "Prospect",
                "Expired"
            };
            status = "Prospect";
            var myAccount = GetAccountById(accountId);

            if (myAccount != null)
            {
                var accountStatus = service.GetStatusValueLabel(new Entity(Account.EntityLogicalName), myAccount.StatusCode);
                status = accountStatus;
            }
            else
            { status = "Prospect"; }

            return status;
        }

        public void CheckRoles(string email, Guid accountId, bool active, string status = "", bool recreateCookie = false)
        {
            var membershipController = new MembershipSurfaceController(this.service, this.DataContext);

            if (active)
            {
                var crmRoleProvider = new CrmRoleProvider();
                if (!crmRoleProvider.IsUserInRole(email, "Member"))
                {
                    if (!crmRoleProvider.IsUserInRole(email, "Member Non-Admin"))
                    { 
                        AddToWebRole(email, "Member");
                        RemoveFromWebRole(email, "Prospect");
                        if (recreateCookie)
                        {
                            membershipController.CustomSignout();
                            FormsAuthentication.SetAuthCookie(email, false);
                            recreateCookie = true;
                        }
                    }
                }
            }
            else
            {
                var crmRoleProvider = new CrmRoleProvider();
                if (crmRoleProvider.IsUserInRole(email, "Member"))
                {
                    RemoveFromWebRole(email, "Member");
                    AddToWebRole(email, "Prospect");
                    if (recreateCookie)
                    {
                        membershipController.CustomSignout();
                        FormsAuthentication.SetAuthCookie(email, false);
                        recreateCookie = true;
                    }
                }
            }
            if (recreateCookie)
            {
                membershipController.GetMemberInfo(email, accountId, true);
            }
        }

        public bool AddToWebRole(string email, string webRoleName)
        {
            var added = false;
            var webRole = DataContext.appl_webroleSet.SingleOrDefault(i => i.appl_name == webRoleName);
            var crmRoleProvider = new CrmRoleProvider();
            if (email != null && webRole != null)
            {
                crmRoleProvider.AddUsersToRoles(new[] { email }, new[] { webRoleName });
                added = true;
            }
            return added;
        }

        public bool RemoveFromWebRole(string email, string webRoleName)
        {
            var removed = false;
            var webRole = DataContext.appl_webroleSet.SingleOrDefault(i => i.appl_name == webRoleName);
            if (email != null && webRole != null)
            {
                var crmRoleProvider = new CrmRoleProvider();
                crmRoleProvider.RemoveUsersFromRoles(new[] { email }, new[] { webRoleName });
                removed = true;
            }
            return removed;
        }
    }
}