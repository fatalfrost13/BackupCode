﻿using System;

using umbraco.NodeFactory;

using IomerBase.U7.DataDefinition;

namespace IomerBase.U7.Extensions.Comments
{
    using System.Linq;

    using Umbraco.Core.Services;

    public static class Comments
    {
        static readonly ContentService contentService = new ContentService();

        public static string AliasCategory = DocumentTypes.category.ToString();
        public static string FieldAllowComments = DocumentFields.allowComments.ToString();
        public static string FieldRequiresApproval = DocumentFields.requiresApproval.ToString();
        public static string FieldUserName = DocumentFields.userName.ToString();
        public static string FieldComment = DocumentFields.userComment.ToString();
        public static string FieldHidden = DocumentFields.umbracoNaviHide.ToString();
        public static string NameCommentsContainer = "Comments";
        public static string DoctypeContainer = DocumentTypes.container.ToString();
        public static string DoctypeComments = DocumentTypes.comment.ToString();
        public static string DateFormat = "MMMM d, yyyy h:mm tt";

        #region Format Functions
        /// <summary>
        /// Global function to format an object to string.
        /// Error handling so if a value is null will return empty string
        /// </summary>
        /// <param name="objValue">object value</param>
        /// <returns>converted object value to string</returns>
        public static string FormatString(this object objValue)
        {
            var strValue = "";

            if (objValue != null && objValue.ToString() != "")
            {
                strValue = objValue.ToString().Trim();
            }

            return strValue;
        }


        /// <summary>
        /// Global Format Integer method 
        /// Catches invalid or null values and returns 0 for those values.
        /// </summary>
        /// <param name="obj">value to attempt int format</param>
        /// <returns>integer value (0 if error or null)</returns>
        public static int FormatInteger(this object obj)
        {
            int num;
            Int32.TryParse(obj.ToString(), out num);
            //num = Int32.Parse(obj.ToString().Trim()); 
            return num;
        }

        /// <summary>
        /// Global Format Bool method
        /// Will also accept "1", "yes", or "true" and return true. Else will return false.
        /// </summary>
        /// <param name="obj">value to attempt bool format</param>
        /// <returns>boolean value (false if error or null)</returns>
        public static bool FormatBool(this object obj)
        {
            bool blValue;
            var isBool = bool.TryParse(obj.ToString(), out blValue);
            
            if (!isBool)
            {
                var strValue = obj.ToString();
                strValue = strValue.ToLower().Trim();
                if (strValue == "1" || strValue == "yes" || strValue == "true")
                {
                    blValue = true;
                }
            }
            return blValue;
        }

        #endregion

        #region Comment Functions

        public static int ContainerId(this int listItemId)
        {
            int[] containerId = { 0 };
            var listNode = new Node(listItemId);

            if (listNode.Id > 0)
            {
                foreach (var container in from Node container in listNode.Children where containerId[0] == 0 where container.NodeTypeAlias.ToLower() == DoctypeContainer select container)
                {
                    containerId[0] = container.Id;
                }

                if (containerId[0] == 0)
                {                    
                    try
                    {
                        var containerDoc = contentService.CreateContent(NameCommentsContainer, listNode.Id, DoctypeContainer);
                        containerDoc.SetValue(DocumentFields.pageTitle.ToString(), NameCommentsContainer);
                        contentService.SaveAndPublish(containerDoc);
                        containerId[0] = containerDoc.Id;
                    }
                    catch (Exception){}
                }
            }
            return containerId[0];
        }

        public static int ContainerIdByAlias(this Node node, string alias)
        {
            var blExit = false;
            var nodeId = 0;

            var tmpNode = node;
            while (blExit == false)
            {
                if (tmpNode.NodeTypeAlias == alias)
                {
                    nodeId = tmpNode.Id;
                    blExit = true;
                }
                else
                {
                    tmpNode = new Node(tmpNode.Parent.Id);
                    if (tmpNode.Id == 0)
                    {
                        blExit = true;
                    }
                }
            }
            return nodeId;
        }

        #endregion

        #region Other Functions

        //public static void UpdateDocumentCache(this Document doc)
        //{
        //    umbraco.library.UpdateDocumentCache(doc.Id);
        //    //umbraco.library.RefreshContent();
        //}

        public static bool ShowComments(this int nodeid)
        {
            var showComments = false;

            var node = new Node(nodeid);
            if (node.Id > 0)
            {
                var allowComments = false;
                var allowCommentsProp = node.GetProperty(FieldAllowComments);
                if (allowCommentsProp != null)
                {
                    allowComments = FormatBool(node.GetProperty(FieldAllowComments).Value);
                }

                if (allowComments)
                {
                    //show comments
                    showComments = true;
                }
            }
            return showComments;
        }

        public static string ViewComments(this int nodeid, string url)
        {
            var strComments = "";
            var count = 0;
            if (ShowComments(nodeid))
            {
                var containerId = ContainerId(nodeid);
                var containerNode = new Node(containerId);
                foreach (Node commentNode in containerNode.Children)
                {
                    var hidden = false;
                    var hiddenProp = commentNode.GetProperty(FieldHidden);
                    if (hiddenProp != null)
                    {
                        hidden = FormatBool(commentNode.GetProperty(FieldHidden).Value);
                    }

                    if (hidden == false)
                    {
                        count++;
                    }
                }
            }

            if (count == 1)
            {
                //strComments += "<br /><img src=\"/images/comment.jpg\"><b><a href=\"" + url + "\">" + count.ToString() + " comment</a></b>";
                strComments += string.Format("<br /><span class=\"commentsLink\"><img src=\"/images/comment.jpg\">&nbsp;<b><a href=\"{0}\">{1} comment</a></b></span>",url,count.ToString());
            }
            else if (count > 0)
            {
                //strComments += "<br /><img src=\"/images/comment.jpg\"><b><a href=\"" + url + "\">" + count.ToString() + " comments</a></b>";
                strComments += string.Format("<br /><span class=\"commentsLink\"><img src=\"/images/comment.jpg\">&nbsp;<b><a href=\"{0}\">{1} comments</a></b></span>", url, count.ToString());
            }
            return strComments;
        }

        #endregion
    }
}