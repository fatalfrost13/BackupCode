﻿using System;
using System.Collections.Generic;
using System.Linq;
using IomerBase.Models;
using Microsoft.Xrm.Client.Services;

namespace ECC.Web.Helpers
{
    using System.Runtime.Serialization;

    using ECC.Web.Controllers;

    using Iomer.Extensions.JSON;

    using Lucene.Net.Util.Cache;

    using Microsoft.WindowsAzure.Storage.Blob;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;

    using MVCCrm.CrmCore;
    using ECC.Web.Data.Crm;
    using ECC.Web.Models;
    using ECC.Web.SurfaceControllers;
    using log4net;

    public class CacheItemController : CrmController
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public CacheItemController()
        {
        }

        public CacheItemController(IOrganizationService organizationService)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = new EccSvcContext(service);
        }

        public CacheItemController(IOrganizationService organizationService, EccSvcContext context)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = context;
        }

        public class CacheProductsModel
        {
            public List<Product> ProductList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        [Serializable]
        public class CachedEventsModel
        {
            public List<EventModel> EventList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CachedEventTicketTypesModel
        {
            public List<EventTicketTypeModel> EventTicketTypeList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CachedTicketPoolModel
        {
            public List<TicketPoolModel> TicketPoolList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        //public class CachedMembershipsModel
        //{
        //    public List<Account> Membership { get; set; }
        //    public DateTime RefreshDateTime { get; set; }
        //}
        [Serializable]
        public class CachedProvinceStatesModel
        {
            public List<ProvinceModel> ProvinceStateList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        [Serializable]
        public class CachedCityModel
        {
            public List<CityModel> CityList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CachedSponsorshipsModel
        {
            public List<SponsorshipModel> Sponsorships { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        //public class CachedAccountsModel
        //{
        //    public List<AccountModel> Accounts { get; set; }
        //    public DateTime RefreshDateTime { get; set; }
        //}

        public class CachedCouponsModel
        {
            public List<CouponModel> CouponsList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class EnrolledEvent
        {
            public Guid Id;
            public Guid EventId;
            public string EventName;
            public DateTime UserStartDate;
            public DateTime UserEndDate;
            public int OnlineCourseAccessDays;

        }

        public class CachedAccountModel
        {
            public Account Account { get; set; }
            //public appl_webmembership WebMembership { get; set; }
        }

        public class CachedUserEventModel
        {
            public EventModel EventDetail;
            public ecc_registration RegistrationDetail;
        }

        public class CachedUserEventListModel
        {
            public List<CachedUserEventModel> UserEventList { get; set; }
        }

        public class CachedUserContactListModel
        {
            public List<Contact> ContactList { get; set; }
        }

        public class InvoiceDetail
        {
            public ecc_payment PaymentInvoice;
            public Guid EventId; //if not for event payment, keep empty
            public String PaymentType; //Add Event Name if payment for event.
        }

        public class CachedUserInvoicesModel //invoices are called payment in ECC CRM.
        {
            public List<InvoiceDetail> UserInvoiceList { get; set; }

            public CachedUserInvoicesModel()
            {
                UserInvoiceList = new List<InvoiceDetail>();
            }
        }

        [Serializable]
        public class CachedBusinessDirectoryModel
        {
            public List<AccountModel> AccountList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        //public class CachedContactsModel 
        //{
        //    public List<Contact> ContactList { get; set; }
        //    public DateTime RefreshDateTime { get; set; }
        //}

        public class CachedAccountLocationsModel
        {
            public List<AccountLocation> LocationList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CachedBusinessTypeListModel
        {
            public List<GenericItem> BusinessTypes { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CachedAccountBusinessType
        {
            public List<AccountBusinessTypeRelationship> Relationships { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        public class CacheDataContext
        {
            public EccSvcContext DataContext { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        protected void EnsureServiceContext()
        {
            if(this.service != null && this.DataContext != null)
            {
                return;
            }

            if(Log.IsInfoEnabled)
            {
                Log.Info("Initializing Cache OrganizationService...");
            }

            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();

            sw.Start();

            var crmManager = new CrmConnectionManager();
            this.service = crmManager.GetOrganizationService();
            this.DataContext = new EccSvcContext(this.service);

            sw.Stop();

            if(Log.IsInfoEnabled)
            {
                Log.InfoFormat("Cache OrganizationService initialized (Duration={0})", sw.ElapsedMilliseconds);
            }
        }

        public void LoadEvents()
        {
            //var products = CacheProductList;
            var events = CachedEventList;
        }

        //private const int CacheHours = 2;   //will cache items for 2 hours
        private const int CacheMinutes = 720;   //cache events for 12 hours.
        //To clear cache, recompile and truncate table [CacheStorage], also logout to clear session cache

        private static readonly Object LockCachedEventList = new object();
        private static CachedEventsModel _CachedEventList;
        public CachedEventsModel CachedEventList //DB Cached
        {
            get
            {
                var cacheName = CacheNames.CachedEventList.ToString();
                if (_CachedEventList == null)
                {
                    lock (LockCachedEventList)
                    {
                        if (_CachedEventList == null)
                        {
                            this.EnsureServiceContext();

                            if(Log.IsInfoEnabled)
                            {
                                Log.InfoFormat("{0}()=> Retrieving from SQL Cache...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            }

                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();

                            sw.Start();

                            var cacheStorage = SqlHelper.GetCacheStorage(cacheName);
                            if (cacheStorage.CacheData != null)
                            {
                                _CachedEventList = SerializeHelper.BinaryDeserializeObject<CachedEventsModel>(cacheStorage.CacheData);
                            }

                            sw.Stop();

                            if(Log.IsInfoEnabled)
                            {
                                Log.InfoFormat("{0}()=> Retrieved SQL Cache (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                            }
                        }
                    }
                }
                
                if (_CachedEventList == null || IsDataExpired(_CachedEventList.RefreshDateTime))
                {
                    lock (LockCachedEventList)
                    {
                        if (_CachedEventList == null || IsDataExpired(_CachedEventList.RefreshDateTime))
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);

                            if(Log.IsInfoEnabled)
                                Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();

                            _CachedEventList = new CachedEventsModel
                            {
                                EventList = eventService.GetAllActiveEvents(),
                                RefreshDateTime = DateTime.Now
                            };

                            sw.Stop();
                            if(Log.IsInfoEnabled)
                                Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                               

                            var data = SerializeHelper.BinarySerializeObject(_CachedEventList);
                            SqlHelper.SaveCacheData(cacheName, data);
                        }
                    }
                }
                
                return _CachedEventList;
            }
            set
            {
                _CachedEventList = value;
            }
        }

        private static readonly Object LockCachedBusinessDirectory = new object();
        private static CachedBusinessDirectoryModel _CachedBusinessDirectory;
        public CachedBusinessDirectoryModel CachedBusinessDirectory //DB Cached
        {
            get
            {
                var cacheName = CacheNames.CachedBusinessDirectory.ToString();
                if (_CachedBusinessDirectory == null)
                {
                    lock (LockCachedBusinessDirectory)
                    {
                        //after this unlocks, we want to check again to see if this object is still null
                        if (_CachedBusinessDirectory == null)
                        {
                            this.EnsureServiceContext();
                            var cacheStorage = SqlHelper.GetCacheStorage(cacheName);
                            if (cacheStorage.CacheData != null)
                            {
                                _CachedBusinessDirectory = SerializeHelper.BinaryDeserializeObject<CachedBusinessDirectoryModel>(cacheStorage.CacheData);
                            }
                        }
                    }
                }

                if (_CachedBusinessDirectory == null || IsDataExpired(_CachedBusinessDirectory.RefreshDateTime))
                {
                    lock (LockCachedBusinessDirectory)
                    {
                        //after this unlocks, we want to check again to see if this object is still null
                        if (_CachedBusinessDirectory == null || IsDataExpired(_CachedBusinessDirectory.RefreshDateTime))
                        {
                            this.EnsureServiceContext();
                            var accountService = new BusinessDirectoryController(this.service, this.DataContext);

                            if(Log.IsInfoEnabled)
                                Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedBusinessDirectory = new CachedBusinessDirectoryModel
                            {
                                AccountList = accountService.GetAllAccounts(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled)
                                Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                              
                            var data = SerializeHelper.BinarySerializeObject(_CachedBusinessDirectory);
                            SqlHelper.SaveCacheData(cacheName, data);
                        }
                    }
                }
                
                return _CachedBusinessDirectory;
            }
            set
            {
                _CachedBusinessDirectory = value;
            }
        }

        
        private static readonly Object LockCachedAccountLocations = new object();
        private static CachedAccountLocationsModel _CachedAccountLocations;
        public CachedAccountLocationsModel CachedAccountLocations
        {
            get
            {
                if(_CachedAccountLocations == null || _CachedAccountLocations.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedAccountLocations)
                    {
                        if(_CachedAccountLocations == null || _CachedAccountLocations.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();

                            _CachedAccountLocations = new CachedAccountLocationsModel();
                            _CachedAccountLocations.LocationList = new List<AccountLocation>();
                            var locations = this.DataContext.CustomerAddressSet;
                            foreach (var location in locations)
                            {
                                if (location.Account_CustomerAddress.AccountId.Value != null)
                                {
                                    var locationItem = new AccountLocation
                                    {
                                        AccountId = location.Account_CustomerAddress.AccountId.Value,
                                        LocationName = location.Name,
                                        AddressLine1 = location.Line1,
                                        City = location.City,
                                        Country = location.Country,
                                        Fax = location.Fax,
                                        MainPhone = location.Telephone1,
                                        Phone2 = location.Telephone2,
                                        PostalZip = location.PostalCode,
                                        ProvState = location.StateOrProvince,
                                        Website = location.ecc_website
                                    };
                                    _CachedAccountLocations.LocationList.Add(locationItem);
                                }
                            }
                        }
                    }
                }
                return _CachedAccountLocations;
            }
            set
            {
                _CachedAccountLocations = value;
            }
        }
        
        private static readonly Object LockCachedEventTicketTypeList = new object();
        private static CachedEventTicketTypesModel _CachedEventTicketTypeList;
        public CachedEventTicketTypesModel CachedEventTicketTypeList
        {
            get
            {

                if (_CachedEventTicketTypeList == null || _CachedEventTicketTypeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock(LockCachedEventTicketTypeList)
                    {
                        if (_CachedEventTicketTypeList == null || _CachedEventTicketTypeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);

                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedEventTicketTypeList = new CachedEventTicketTypesModel
                            {
                                EventTicketTypeList = eventService.GetAllEventTicketTypes(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                              
                        }
                    }
                }

                return _CachedEventTicketTypeList;
            }
            set
            {
                _CachedEventTicketTypeList = value;
            }
        }
        private static readonly Object LockCachedTicketPool = new object();
        private static CachedTicketPoolModel _CachedTicketPoolList;
        public CachedTicketPoolModel CachedTicketPoolList
        {
            get
            {
                if (_CachedTicketPoolList == null || _CachedTicketPoolList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock(LockCachedTicketPool)
                    {
                        if (_CachedTicketPoolList == null || _CachedTicketPoolList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);

                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedTicketPoolList = new CachedTicketPoolModel
                            {
                                TicketPoolList = eventService.GetAllTicketPools(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                              
                        }
                    }
                }

                return _CachedTicketPoolList;
            }
            set
            {
                _CachedTicketPoolList = value;
            }
        }
        private static readonly Object LockCachedProvinceList = new object();
        private static CachedProvinceStatesModel _CachedProvinceStateList;
        public CachedProvinceStatesModel CachedProvinceStateList //DB Cached
        {
            get
            {
                var cacheName = CacheNames.CachedProvincesStatesList.ToString();

                if (_CachedProvinceStateList == null)
                {
                    lock (LockCachedProvinceList)
                    {
                        if (_CachedProvinceStateList == null)
                        {
                            this.EnsureServiceContext();
                            var cacheStorage = SqlHelper.GetCacheStorage(cacheName);
                            if (cacheStorage.CacheData != null)
                            {
                                _CachedProvinceStateList =
                                    SerializeHelper.BinaryDeserializeObject<CachedProvinceStatesModel>(
                                        cacheStorage.CacheData);
                            }
                        }
                    }
                }


                if (_CachedProvinceStateList == null || IsDataExpired(_CachedProvinceStateList.RefreshDateTime))//.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedProvinceList)
                    {
                        if (_CachedProvinceStateList == null || IsDataExpired(_CachedProvinceStateList.RefreshDateTime))
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedProvinceStateList = new CachedProvinceStatesModel
                            {
                                ProvinceStateList = eventService.GetProvinceStateList(),
                                RefreshDateTime = DateTime.Now.AddMonths(1)
                                // city and province don't need frequent update
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                             
                            var data = SerializeHelper.BinarySerializeObject(_CachedProvinceStateList);
                            SqlHelper.SaveCacheData(cacheName, data);
                        }
                    }
                }                
                return _CachedProvinceStateList;
            }
            set
            {
                _CachedProvinceStateList = value;
            }
        }

        private static readonly Object LockCachedCityList = new object();
        private static CachedCityModel _CachedCityList;
        public CachedCityModel CachedCityList //DB Cached
        {
            get
            {
                var cacheName = CacheNames.CachedCityList.ToString();
                if (_CachedCityList == null)
                {
                    lock (LockCachedCityList)
                    {
                        if (_CachedCityList == null)
                        {
                            this.EnsureServiceContext();
                            var cacheStorage = SqlHelper.GetCacheStorage(cacheName);
                            if (cacheStorage.CacheData != null)
                            {
                                _CachedCityList =
                                    SerializeHelper.BinaryDeserializeObject<CachedCityModel>(cacheStorage.CacheData);
                            }
                        }
                    }
                }

                if (_CachedCityList == null || IsDataExpired(_CachedCityList.RefreshDateTime))
                {
                    lock (LockCachedCityList)
                    {
                        if (_CachedCityList == null || IsDataExpired(_CachedCityList.RefreshDateTime))
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedCityList = new CachedCityModel
                            {
                                CityList = eventService.GetCityList(),
                                RefreshDateTime = DateTime.Now.AddMonths(1)
                                // city and province don't need frequent update
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                             
                            var data = SerializeHelper.BinarySerializeObject(_CachedCityList);
                            SqlHelper.SaveCacheData(cacheName, data);
                        }
                    }
                }

                return _CachedCityList;
            }
            set
            {
                _CachedCityList = value;
            }
        }

        private static readonly Object LockCachedSponsorships = new object();
        private static CachedSponsorshipsModel _CachedSponsorshipList;
        public CachedSponsorshipsModel CachedSponsorshipList
        {
            get
            {
                if (_CachedSponsorshipList == null || _CachedSponsorshipList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedSponsorships)
                    {
                        if (_CachedSponsorshipList == null || _CachedSponsorshipList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var eventService = new EventController(this.service, this.DataContext);
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedSponsorshipList = new CachedSponsorshipsModel
                            {
                                Sponsorships = eventService.GetSponsorshipList(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                             
                        }
                    }
                }
                return _CachedSponsorshipList;
            }
            set
            {
                _CachedSponsorshipList = value;
            }
        }

        private static readonly Object LockCachedCoupons = new object();
        private static CachedCouponsModel _CachedCouponList;
        public CachedCouponsModel CachedCouponList
        {
            get
            {
                if (_CachedCouponList == null || _CachedCouponList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedCoupons)
                    {
                        //todo the coupon is not updating cache instantly. But the message says it will be posted within 24hrs 
                        if (_CachedCouponList == null || _CachedCouponList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var membershipService = new MembershipSurfaceController(this.service, this.DataContext);
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedCouponList = new CachedCouponsModel
                            {
                                CouponsList = membershipService.GetCoupons(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);
                             
                        }
                    }
                }
                return _CachedCouponList;
            }
            set
            {
                _CachedCouponList = value;
            }
        }

        public void LoadAccount()
        {
            var accountInfo = CachedAccountInfo;
        }

        public CachedAccountModel CachedAccountInfo
        {
            get
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                if (sessionContext == null)
                {
                    return null;
                }
                try
                {
                    if (sessionContext["AccountInfo"] == null || sessionContext["AccountInfo"].ToString() == string.Empty)
                    {
                        this.EnsureServiceContext();
                        var memberService = new MembershipSurfaceController(this.service, this.DataContext);
                        var memberStatus = memberService.GetMemberInfo();
                        if (memberStatus != null)
                        {

                            var currentAccounts = (from account in memberService.DataContext.AccountSet
                                where account.AccountId == memberStatus.AccountId
                                select account).ToList();

                            var currentAccount = new CachedAccountModel
                            {
                                Account = currentAccounts.Any() ? currentAccounts.First() : null
                            };

                            sessionContext["AccountInfo"] = currentAccounts.Any() 
                                ? new CachedAccountModel
                                {
                                    Account = currentAccounts.First()
                                } 
                                : null;
                        }
                        else
                        {
                            memberService.CustomSignout();
                        }
                    }
                }
                catch
                {
                    sessionContext["AccountInfo"] = null;
                }

                return sessionContext["AccountInfo"] as CachedAccountModel;
            }

            set
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                sessionContext["AccountInfo"] = value;
            }
        }

        public CachedUserEventListModel CachedUserEvent 
        {
            get
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                if (sessionContext == null){return null; }

                if (sessionContext["UserEvenList"] == null || sessionContext["UserEvenList"].ToString() == string.Empty)
                {
                    this.EnsureServiceContext();
                    var currentAccount = CachedAccountInfo;
                    var userEventList = this.DataContext.ecc_registrationSet.Where(i => i.ecc_account.Id == currentAccount.Account.Id).ToList();
                    var eventListModel = new CachedUserEventListModel();
                    eventListModel.UserEventList = new List<CachedUserEventModel>();
                    var eventService = new EventController(this.service, this.DataContext);
                    foreach (var userEvent in userEventList)
                    {
                        var crmEvent = eventService.GetUserEventByRegistration(userEvent);
                        eventListModel.UserEventList.Add(new CachedUserEventModel
                        {
                            EventDetail = crmEvent,
                            RegistrationDetail = userEvent
                        });
                    }
                    sessionContext["UserEvenList"] = eventListModel;
                }
                
                return sessionContext["UserEvenList"] as CachedUserEventListModel;
            }

            set
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                sessionContext["UserEvenList"] = value;
            }
        }

        public CachedUserContactListModel CachedUserContacts {
            get
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                if (sessionContext == null) { return null; }

                if (sessionContext["UserContacts"] == null || sessionContext["UserContacts"].ToString() == string.Empty)
                {
                    this.EnsureServiceContext();
                    var currentAccount = CachedAccountInfo;
                    var userContactList = DataContext.ContactSet.Where(i => i.ecc_Account.Id == currentAccount.Account.Id).ToList();
                    sessionContext["UserContacts"] = new CachedUserContactListModel { ContactList = userContactList };
                }

                return sessionContext["UserContacts"] as CachedUserContactListModel;
            }
            set
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                sessionContext["UserContacts"] = value;
            }
        }

        public CachedUserInvoicesModel CachedUserInvoices 
        {
            get
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                if (sessionContext == null){ return null;}
                try
                {
                    if (sessionContext["UserInvoiceList"] == null || sessionContext["UserInvoiceList"].ToString() == string.Empty)
                    {
                        this.EnsureServiceContext();
                        var currentAccount = CachedAccountInfo;
                        var userPaymentList = this.DataContext.ecc_paymentSet.Where(i => i.ecc_Account.Id == currentAccount.Account.Id).ToList();
                        var invoiceListModel = new CachedUserInvoicesModel();
                        foreach (var payment in userPaymentList)
                        {
                            var invoice = new InvoiceDetail {PaymentInvoice = payment, EventId= Guid.Empty, PaymentType = ""};
                            if (payment.ecc_paymenttype != null)
                            {
                                switch (payment.ecc_paymenttype.Value)
                                {
                                    case (int) ecc_paymentecc_paymenttype.EventRegistration:
                                        try{
                                            var registration =
                                                CachedUserEvent.UserEventList.FirstOrDefault(
                                                    i => i.RegistrationDetail.Id == payment.ecc_Registration.Id);
                                            invoice.PaymentType = registration.EventDetail.EventName;
                                            invoice.EventId = registration.EventDetail.EventId;

                                        }
                                        catch
                                        {
                                            invoice.PaymentType = "event registration";
                                        }
                                        break;
                                    case (int) ecc_paymentecc_paymenttype.DirectoryCategory:
                                        invoice.PaymentType = "Directory Category";
                                        break;
                                    case (int) ecc_paymentecc_paymenttype.MembershipSignup:
                                        invoice.PaymentType = "Membership Sign Up";
                                        break;
                                    case (int) ecc_paymentecc_paymenttype.MembershipRenewal:
                                        invoice.PaymentType = "Membership Renewal";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.BoardroomRental:
                                        invoice.PaymentType = "Boardroom Rental";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.CertificateofOrigin:
                                        invoice.PaymentType = "Certificate of Origin";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.CreditNote:
                                        invoice.PaymentType = "Credit Note";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.DiscountProgram:
                                        invoice.PaymentType = "Discount Program";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.ENewsAdvertising:
                                        invoice.PaymentType = "ENews Advertising";
                                        break;
                                    case (int)ecc_paymentecc_paymenttype.Sponsorships:
                                        invoice.PaymentType = "Sponsorships";
                                        break;
                                    default:
                                        invoice.PaymentType = String.Empty;
                                        break;
                                }
                            }
                            else
                            {
                                invoice.PaymentType = String.Empty;
                            }
                            invoiceListModel.UserInvoiceList.Add(invoice);
                        }

                        sessionContext["UserInvoiceList"] = invoiceListModel;
                    }
                }
                catch
                {
                    sessionContext["UserInvoiceList"] = null;
                }

                return sessionContext["UserInvoiceList"] as CachedUserInvoicesModel;
            }
            set
            {
                var sessionContext = System.Web.HttpContext.Current.Session;
                sessionContext["UserInvoiceList"] = value;
            }
        }
        
        public void ResetTicketsCache()
        {
            CachedEventTicketTypeList = null;
            var chachedTickets = CachedEventTicketTypeList;

            CachedTicketPoolList = null;
            var cachedTicketPoolList = CachedTicketPoolList;
        }

        public CachedEventsModel ResetEventCache()
        {

            CachedSponsorshipList = null;
            var cachedSponsorshipList = CachedSponsorshipList;

            var cacheName = CacheNames.CachedEventList.ToString();
            SqlHelper.ResetCache(cacheName);
            CachedEventList = null;
            var cachedEventList = CachedEventList;

            ResetTicketsCache();
            return cachedEventList;
        }

        public CachedBusinessDirectoryModel ResetBusinessDirectoryCache()
        {
            var cacheName = CacheNames.CachedBusinessDirectory.ToString();
            SqlHelper.ResetCache(cacheName);
            AccountBusinessType = null;
            CachedBusinessDirectory = null;
            var cachedBusinessDirectory = CachedBusinessDirectory;
            return cachedBusinessDirectory;
        }
        public void ResetCitiesAndProvincesStatesCache()
        {
            var cacheName = CacheNames.CachedProvincesStatesList.ToString();
            SqlHelper.ResetCache(cacheName);
            CachedProvinceStateList = null;
            var cachedProvinceStateList = CachedProvinceStateList;
           
            cacheName = CacheNames.CachedCityList.ToString();
            SqlHelper.ResetCache(cacheName);
            CachedCityList = null;
            var cachedCityList = CachedCityList;
        }


        private static readonly Object LockCachedBusinessTypeList = new object();
        private static CachedBusinessTypeListModel _CachedBusinessTypeList;
        public CachedBusinessTypeListModel CachedBusinessTypeList
        {
            get
            {
                if (_CachedBusinessTypeList == null || _CachedBusinessTypeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedBusinessTypeList)
                    {
                        if (_CachedBusinessTypeList == null || _CachedBusinessTypeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var businesstypeSet = this.DataContext.ecc_businesstypeSet;
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _CachedBusinessTypeList = new CachedBusinessTypeListModel
                            {
                                BusinessTypes =
                                    new List<GenericItem>(
                                        businesstypeSet.Select(i => new GenericItem { Text = i.ecc_title, Value = i.Id.ToString() })
                                            .ToList()
                                            .OrderBy(i => i.Text)),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);


                        }
                    }
                }
                return _CachedBusinessTypeList;
            }
            set
            {
                _CachedBusinessTypeList = value;
            }
        }

        private static readonly Object LockCachedAccountBusinessType = new object();
        private static CachedAccountBusinessType _AccountBusinessType;
        public CachedAccountBusinessType AccountBusinessType
        {
            get
            {
                try
                {
                    if (_AccountBusinessType == null || _AccountBusinessType.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                    {
                        lock (LockCachedAccountBusinessType)
                        {
                            if (_AccountBusinessType == null || _AccountBusinessType.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                            {
                                if (Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                                System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                                sw.Start();
                                this.EnsureServiceContext();
                                var relationships = this.DataContext.ecc_account_ecc_businesstypeSet.Where(i => i.accountid != null && i.ecc_businesstypeid != null)
                                    .Select(i => new AccountBusinessTypeRelationship { AccountId = Guid.Parse(i.accountid.ToString()), BusinessTypeId = Guid.Parse(i.ecc_businesstypeid.Value.ToString()) }).ToList();
                                _AccountBusinessType = new CachedAccountBusinessType { Relationships = relationships, RefreshDateTime = DateTime.Now };

                                sw.Stop();
                                if (Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);

                            }
                        }
                    }
                }
                catch
                {
                    _AccountBusinessType = null;
                }
                return _AccountBusinessType;
            }
            set
            {
                _AccountBusinessType = value;
            }
        }

        public class CachedAnualMemberShipFeeListModel
        {
            public List<AnualMemberShipFeeModel> AnualMemberShipFeeList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        private static readonly Object LockCachedAnualMemberShipFee = new object();
        private static CachedAnualMemberShipFeeListModel _AMSFeeList;
        public CachedAnualMemberShipFeeListModel CachedAnualMemberShipFeeListCurrentYear
        {
            get
            {
                if (_AMSFeeList == null || _AMSFeeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedAnualMemberShipFee)
                    {
                        if (_AMSFeeList == null || _AMSFeeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var currentYear = DateTime.Now.Year;
                            var anualMemberShipFeeSet = this.DataContext.ecc_membershipfeeSet.Where(i => i.ecc_Year == currentYear);

                            if(Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _AMSFeeList = new CachedAnualMemberShipFeeListModel
                            {
                                AnualMemberShipFeeList =
                                    anualMemberShipFeeSet
                                    .Select(i =>
                                            new AnualMemberShipFeeModel(OptionSetExtensions.GetOptionSetValueLabel(this.service, i, "ecc_numberofemployees", i.ecc_NumberofEmployees), i.ecc_Fee.Value))
                                    .ToList(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if (Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);

                        }
                    }
                }
                return _AMSFeeList;
            }

            set
            {
                _AMSFeeList = value;
            }

        }

        public class CachedMemberShipRenewFeeListModel
        {
            public List<AnualMemberShipFeeModel> AnualMemberShipFeeList { get; set; }
            public DateTime RefreshDateTime { get; set; }
        }

        private static readonly Object LockCachedMemberShipRenewFee= new object();
        private static CachedMemberShipRenewFeeListModel _RMSFeeList;
        public CachedMemberShipRenewFeeListModel CachedMemberShipRenewFeeListCurrentYear
        {
            get
            {
                if (_RMSFeeList == null || _RMSFeeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                {
                    lock (LockCachedMemberShipRenewFee)
                    {
                        if (_RMSFeeList == null || _RMSFeeList.RefreshDateTime.AddMinutes(CacheMinutes) < DateTime.Now)
                        {
                            this.EnsureServiceContext();
                            var currentYear = DateTime.Now.Year;
                            var anualMemberShipFeeSet = this.DataContext.ecc_membershipfeeSet.Where(i => i.ecc_Year == currentYear);

                            if (Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieving from CRM...", System.Reflection.MethodInfo.GetCurrentMethod().Name);
                            System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                            sw.Start();
                            _RMSFeeList = new CachedMemberShipRenewFeeListModel
                            {
                                AnualMemberShipFeeList =
                                    anualMemberShipFeeSet
                                    .Select(i =>
                                            new AnualMemberShipFeeModel(OptionSetExtensions.GetOptionSetValueLabel(this.service, i, "ecc_numberofemployees", i.ecc_NumberofEmployees), i.ecc_renewalfee.Value))
                                    .ToList(),
                                RefreshDateTime = DateTime.Now
                            };
                            sw.Stop();
                            if (Log.IsInfoEnabled) Log.InfoFormat("{0}()=> Retrieved CRM records (Duration={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, sw.ElapsedMilliseconds);

                        }
                    }
                }
                return _RMSFeeList;
            }

            set
            {
                _RMSFeeList = value;
            }

        }


        private static bool IsDataExpired(DateTime refreshDate)
        {
            var dataExpired = false;
            const int hourOfDay = 1; //represents hour of date: 1:00 AM
            const int cacheHours = 4; //represents hours of how long cache stays before considered expired.
            var dtDataExpiry = DateTime.Today.AddHours(hourOfDay);     //first request after time of day: reload all data
            if (refreshDate.AddHours(cacheHours) < dtDataExpiry)
            {
                dataExpired = true;
            }
            return dataExpired;
        }

    }

}
