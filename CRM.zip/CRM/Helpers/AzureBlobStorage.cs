﻿
namespace ECC.Web.Helpers
{
    using System.Configuration;
    using System.IO;

    using Microsoft.WindowsAzure;
    using Microsoft.WindowsAzure.Storage;
    using Microsoft.WindowsAzure.Storage.Blob;

    public class AzureBlobStorage
    {
        public CloudBlobContainer GetBlobContainer(CloudStorageAccount storageAccount, string containerName)
        {
            containerName = containerName.ToLower().Trim();
            var blobClient = storageAccount.CreateCloudBlobClient();
            var container = blobClient.GetContainerReference(containerName);
            container.CreateIfNotExists();
            container.SetPermissions(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
            return container;
        }

        public string UploadToBlobStorage(CloudBlobContainer container, string fileName, string filePath)
        {
            var blockBlob = container.GetBlockBlobReference(fileName);
            var blobRoot = ConfigurationManager.AppSettings["BlobStorageRoot"];
            var blobStorageUrl = string.Format("{0}/{1}/{2}", blobRoot, container.Name, fileName);
            using (var fileStream = System.IO.File.OpenRead(@filePath))
            {
                blockBlob.UploadFromStream(fileStream);
            }
            return blobStorageUrl;
        }

        public string UploadToBlobStorage(CloudBlobContainer container, string fileName, byte[] dataBytes)
        {
            var blockBlob = container.GetBlockBlobReference(fileName);
            var blobRoot = ConfigurationManager.AppSettings["BlobStorageRoot"];
            var blobStorageUrl = string.Format("{0}/{1}/{2}", blobRoot, container.Name, fileName);
            
            using (var stream = new MemoryStream(dataBytes, writable: true))
            {
                blockBlob.UploadFromStream(stream);
            }
            return blobStorageUrl;
        }

        public bool BlobExists(CloudBlobContainer container, string fileName)
        {
            bool exists;
            var blockBlob = container.GetBlockBlobReference(fileName);

            try
            {
                blockBlob.FetchAttributes();
                exists = true;
                // the container exists if no exception is thrown  
            }
            catch
            {
                // the container does not exist
                exists = false;
            }

            return exists;
        }

        public CloudBlockBlob GetBlob(CloudBlobContainer container, string fileName)
        {
            var blockBlob = container.GetBlockBlobReference(fileName);

            try
            {
                blockBlob.FetchAttributes();
                // the container exists if no exception is thrown  
            }
            catch
            {
                // the container does not exist
                blockBlob = null;
            }

            return blockBlob;
        }

        public bool CacheBlobExists(string fileName)
        {
            var exists = false;
            var containerName = ConfigurationManager.AppSettings["CacheContainerName"];
            var blobHelper = new AzureBlobStorage();
            var storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("BlobStorageConnectionString"));
            var container = blobHelper.GetBlobContainer(storageAccount, containerName);
            var filePath = System.Web.HttpContext.Current.Server.MapPath(string.Format("/{0}/{1}", containerName, fileName));
            exists = blobHelper.BlobExists(container, filePath);
            return exists;
        }

        public void CreateCacheBlob(string fileName, byte[] dataBytes) 
        {
            var containerName = ConfigurationManager.AppSettings["CacheContainerName"];
            var blobHelper = new AzureBlobStorage();
            var storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("BlobStorageConnectionString"));
            var container = blobHelper.GetBlobContainer(storageAccount, containerName);
            blobHelper.UploadToBlobStorage(container, fileName, dataBytes);
        }

        public void UpdateCacheBlob(CloudBlockBlob blockBlob, byte[] dataBytes)
        {
            //var containerName = ConfigurationManager.AppSettings["CacheContainerName"];
            //var blobHelper = new AzureBlobStorage();
            //var storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("BlobStorageConnectionString"));
            //var container = blobHelper.GetBlobContainer(storageAccount, containerName);
            //blobHelper.UploadToBlobStorage(container, fileName, dataBytes);
            using (var stream = new MemoryStream(dataBytes, writable: true))
            {
                blockBlob.UploadFromStream(stream);
            }
        }

        public CloudBlockBlob GetCacheBlob(string fileName) 
        {
            var containerName = ConfigurationManager.AppSettings["CacheContainerName"];
            var blobHelper = new AzureBlobStorage();
            var storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("BlobStorageConnectionString"));
            var container = blobHelper.GetBlobContainer(storageAccount, containerName);
            var blobBlock = blobHelper.GetBlob(container, fileName);
            return blobBlock;
        }

    }
}
