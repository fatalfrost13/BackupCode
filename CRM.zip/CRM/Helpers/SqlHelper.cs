﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ECC.Web.Helpers
{
    using System.Web.Helpers;

    using ECC.Web.DataContext;

    using Lucene.Net.Util.Cache;

    using Microsoft.Ajax.Utilities;

    public static class SqlHelper
    {
        public static int CommandTimeout = 300;

        public static void SaveCacheData(string cacheName, byte[] data)
        {
            using (var context = new eccEntities())
            {
                context.Database.CommandTimeout = CommandTimeout;

                var cacheRecords = context.CacheStorages.Where(i => i.Name == cacheName);
                if (cacheRecords.Any())
                {
                    var cacheRecord = cacheRecords.Take(1).SingleOrDefault();
                    if (cacheRecord != null)
                    {
                        cacheRecord.CacheData = data;
                        cacheRecord.RefreshDate = DateTime.Now;
                        context.SaveChanges();
                    }
                }
                else
                {
                    //create new record
                    var newRecord = new CacheStorage
                    {
                        Name = cacheName,
                        CacheData = data,
                        RefreshDate = DateTime.Now
                    };
                    context.CacheStorages.Add(newRecord);
                    context.SaveChanges();
                }
            }
        }

        public static CacheStorage GetCacheStorage(string cacheName)
        {
            using (var context = new eccEntities())
            {
                context.Database.CommandTimeout = CommandTimeout;

                var cacheRecords = context.CacheStorages.Where(i => i.Name == cacheName);
                if (cacheRecords.Any())
                {
                    var cacheRecord = cacheRecords.Take(1).SingleOrDefault();
                    return cacheRecord;
                }
                else
                {
                    //create new record
                    var newRecord = new CacheStorage { 
                        Name = cacheName,
                        CacheData = null,
                        RefreshDate = DateTime.Now
                    };
                    context.CacheStorages.Add(newRecord);
                    context.SaveChanges();
                    return newRecord;
                }
            }
        }

        public static void ResetCache(string cacheName) 
        {
            using (var context = new eccEntities())
            {
                context.Database.CommandTimeout = CommandTimeout;

                var cacheRecords = context.CacheStorages.Where(i => i.Name == cacheName);
                if (cacheRecords.Any())
                {
                    var cacheRecord = cacheRecords.Take(1).SingleOrDefault();
                    cacheRecord.CacheData = null;
                    cacheRecord.RefreshDate = DateTime.Now;
                    context.SaveChanges();
                }
            }
        }

        public static DateTime GetLastRefreshDate(string cacheName) 
        {
            using (var context = new eccEntities())
            {
                var lastRefreshDate = DateTime.MinValue;
                context.Database.CommandTimeout = CommandTimeout;

                var cacheRecords = context.CacheStorages.Where(i => i.Name == cacheName);
                if (cacheRecords.Any())
                {
                    var cacheRecord = cacheRecords.Take(1).SingleOrDefault();
                    lastRefreshDate = cacheRecord.RefreshDate != null ? (DateTime)cacheRecord.RefreshDate : DateTime.MinValue;
                }
                return lastRefreshDate;
            }
        }

    }
}
