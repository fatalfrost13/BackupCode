﻿namespace ECC.Web.Helpers
{
    using System.Collections.Generic;
    using System.Linq;

    using ECC.Web.Models;

    using Iomer.Umbraco.Extensions;

    using IomerBase.Models;
    using IomerBase.U7.DataDefinition;

    using umbraco.interfaces;
    using umbraco.NodeFactory;

    public static class CssHelper
    {
        public static string TileClass(this INode iNode, string baseClass = "")
        {
            var node = new Node(iNode.Id);
            var cssClass = baseClass != string.Empty ? baseClass : "item";
            var tileClass = node.GetNodeValue(DocumentFields.tileClass.ToString());
            var tileDimension = node.GetNodeValue(DocumentFields.tileDimension.ToString());

            if (tileDimension != string.Empty)
            {
                //get width class
                if (tileDimension.StartsWith("1x"))
                {
                    //don't need to add with style, defaults to 1 tile wide.
                }
                else if (tileDimension.StartsWith("2x"))
                {
                    cssClass += " w2";
                }
                else if (tileDimension.StartsWith("3x"))
                {
                    cssClass += " w3";
                }
                else if (tileDimension.StartsWith("4x"))
                {
                    cssClass += " w4";
                }

                //get height class
                if (tileDimension.EndsWith("x1"))
                {
                    //don't need to add with style, defaults to 1 tile high.
                }
                else if (tileDimension.EndsWith("x2"))
                {
                    cssClass += " h2";
                }
            }

            if (tileClass != string.Empty)
            {
                cssClass += " " + tileClass;
            }
            
            return cssClass;
        }

        public static string NumberToWord(int number)
        {
            string strNumber = string.Empty;
            switch (number)
            {
                case 1:
                    strNumber = "one";
                    break;
                case 2:
                    strNumber = "two";
                    break;
                case 3:
                    strNumber = "three";
                    break;
                case 4:
                    strNumber = "four";
                    break;
                case 5:
                    strNumber = "five";
                    break;
                case 6:
                    strNumber = "six";
                    break;
                case 7:
                    strNumber = "seven";
                    break;
                case 8:
                    strNumber = "eight";
                    break;
                case 9:
                    strNumber = "nine";
                    break;
                case 10:
                    strNumber = "ten";
                    break;
            }
            return strNumber;
        }

        public static List<GenericItemGroup> GenericItemGroups(this List<GenericItem> items, int numberOfColumns)
        {

            var divGroups = new List<GenericItemGroup>();
            var total = items.Count;
            var itemsPerColumn = total / numberOfColumns;
            var remainder = total % numberOfColumns;
            if (remainder > 0)
            {
                itemsPerColumn++;
            }

            var index = 1;
            var groupItems = new List<GenericItem>();
            foreach(var item in items)
            {
                var reset = false;

                groupItems.Add(item);

                if ((index+1) > itemsPerColumn)
                {
                    reset = true;

                    if (remainder > 0)
                    {
                        remainder--;
                        if (remainder == 0)
                        {
                            itemsPerColumn--;
                        }
                    }
                }
                
                if (reset)
                {
                    var genericItemGroup = new GenericItemGroup { GenericItems = groupItems};
                    divGroups.Add(genericItemGroup);
                    groupItems = new List<GenericItem>();
                    index = 1;
                }
                else
                {
                    index++;
                }
            }
            if (groupItems.Any())
            {
                //add the rest into the last remaining column
                var genericItemGroup = new GenericItemGroup { GenericItems = groupItems };
                divGroups.Add(genericItemGroup);
                //groupItems = new List<GenericItem>();
                //index = 0;
            }

            return divGroups;
        }
    }
}
