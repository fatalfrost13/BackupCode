﻿namespace ECC.Web.Helpers
{
    using System;
    using System.Net;

    using Microsoft.WindowsAzure.ServiceRuntime;

    // http://weblogs.thinktecture.com/cweyer/2011/01/poor-mans-approach-to-application-pool-warm-up-for-iis-in-a-windows-azure-web-role.html
    public static class WebSiteUtilities
    {
        public static void WarmUp(string endpointName)
        {
            try
            {
                var endpoint = RoleEnvironment.CurrentRoleInstance.InstanceEndpoints[endpointName];
                var address = string.Format(
                    "{0}://{1}:{2}",
                    endpoint.Protocol,
                    endpoint.IPEndpoint.Address,
                    endpoint.IPEndpoint.Port);
                var webClient = new WebClient();
                webClient.DownloadString(address);
            }
            catch (Exception)
            {
                // intentionally swallow all exceptions here.
            }
        }
    }

}
