﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ECC.Web.Data.Crm;
using IomerBase.Models;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace ECC.Web.Helpers
{
    public static class LookupHelper
    {
        public static List<GenericItem> GetMonths()
        {
            return new List<GenericItem> { 
                new GenericItem { Text = "January", Value = "01" }, 
                new GenericItem { Text = "February", Value = "02" },
                new GenericItem { Text = "March", Value = "03" },
                new GenericItem { Text = "April", Value = "04" },
                new GenericItem { Text = "May", Value = "05" },
                new GenericItem { Text = "June", Value = "06" },
                new GenericItem { Text = "July", Value = "07" },
                new GenericItem { Text = "August", Value = "08" },
                new GenericItem { Text = "September", Value = "09" },
                new GenericItem { Text = "October", Value = "10" },
                new GenericItem { Text = "November", Value = "11" },
                new GenericItem { Text = "December", Value = "12" },
            };
        
        }

        public static List<GenericItem> GetCreditCardYear()
        {
            var years = new List<GenericItem>();
            var currentYear = DateTime.Now.Year;
            for (var i = currentYear; i < currentYear + 10; i++)
            {
                years.Add(new GenericItem { Text = i.ToString(), Value = i.ToString() });
            }
            return years;
        }

        public static List<GenericItem> MembershipModel_ReasonsOfJoining()
        {
            return new List<GenericItem> { 
                new GenericItem { Text = "- -Select- -", Value = ""  }, 
                new GenericItem { Text = "Networking",
                    Value = ((int)Accountecc_ReasonforJoining.Networking).ToString()},
                new GenericItem { Text = "Promoting my business", 
                    Value = ((int)Accountecc_ReasonforJoining.Promotingmybusiness).ToString()},
                new GenericItem { Text = "Saving money through Edmonton Chamber member offerings and discounts", 
                    Value = ((int)Accountecc_ReasonforJoining.SavingmoneythroughEdmontonChambermemberofferingsanddiscounts).ToString() },
                new GenericItem { Text = "Referrals and sales opportunities", 
                    Value = ((int)Accountecc_ReasonforJoining.Referralsandsalesopportunities).ToString()},
                new GenericItem { Text = "To influence local government decisions", 
                    Value = ((int)Accountecc_ReasonforJoining.Toinfluencelocalgovernmentdecisions).ToString() },
                new GenericItem { Text = "To become part of developing a strong business community in Edmonton", 
                    Value = ((int)Accountecc_ReasonforJoining.TobecomepartofdevelopingastrongbusinesscommunityinEdmonton).ToString() },
                new GenericItem { Text = "Other", 
                    Value = ((int)Accountecc_ReasonforJoining.Other).ToString() }
            };
        }


        public static List<GenericItem> MembershipModel_BusinessDirectory()
        {
            return new List<GenericItem> { 
                new GenericItem { Text = "- -Select- -", Value = ""  }, 
                new GenericItem { Text = "Yes, list my company in the online Edmonton Chamber business directory.", Value =((int)Accountecc_listingtype.Visible).ToString() },
                new GenericItem { Text = "No, do not list my company in the online Edmonton Chamber business directory.", Value = ((int)Accountecc_listingtype.Hidden).ToString()},
                new GenericItem { Text = "List only my company name and phone number in the online Edmonton Chamber business directory.", Value = ((int)Accountecc_listingtype.Limited).ToString() }
            };
        }

        public static List<GenericItem> GetCouponTypes()
        {
            var couponTypes = new List<GenericItem>();
            couponTypes.Add(new GenericItem { Text = "Select Coupon Type...", Value = "" });
            foreach (var value in Enum.GetValues(typeof (ecc_couponecc_CouponType)))
            {
                if (value.ToString() == "PublicCoupon")
                {
                    couponTypes.Add(new GenericItem { Text = "Public Coupon", Value = ecc_couponecc_CouponType.PublicCoupon.ToString() });
                }
                else if (value.ToString() == "MembertoMemberCoupon")
                {
                    couponTypes.Add(new GenericItem { Text = "Member to Member Coupon", Value = ecc_couponecc_CouponType.MembertoMemberCoupon.ToString() });
                }
                else
                {
                    couponTypes.Add(new GenericItem { Text = value.ToString(), Value = value.ToString() });
                }
            }
            return couponTypes;
        }

        public static List<GenericItem> ContactTypes()
        {
            var contactTypes = new List<GenericItem>
            {
                new GenericItem {Text = "Other", Value = ((int)Contactecc_ContactType.Other).ToString()},
                new GenericItem {Text = "Billing", Value = ((int)Contactecc_ContactType.Billing).ToString()},
                new GenericItem {Text = "HR", Value = ((int)Contactecc_ContactType.HR).ToString()},
                new GenericItem {Text = "Sales", Value = ((int)Contactecc_ContactType.Sales).ToString()}
                
            };

            return contactTypes;
        }

        public static List<GenericItem> PaymentCardTypes()
        {
            return new List<GenericItem>
            {
                new GenericItem
                    {
                        Text = "Visa",
                        Value = ((int)ecc_paymentecc_cardtype.Visa).ToString()
                    },
                new GenericItem
                    {
                        Text = "MasterCard",
                        Value = ((int)ecc_paymentecc_cardtype.MasterCard).ToString()
                    }
            };
        }
    }

}