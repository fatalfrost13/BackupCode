﻿namespace ECC.Web.Helpers
{
    using ECC.Web.Models;

    using Iomer.Umbraco.Extensions;

    using IomerBase.Iomer.Umbraco.Extensions.Custom;
    using IomerBase.U7.DataDefinition;

    using umbraco.interfaces;
    using umbraco.NodeFactory;

    public static class ModelHelper
    {
        public static CommitteeMember GetCommitteeMember(this INode inode)
        {
            var node = new Node(inode.Id);
            //var mediaId = node.GetNodeValue(DocumentFields.memberLogo.ToString());
            //var memberLogoPath = mediaId != string.Empty ? NodeUtility.GetMediaPath(int.Parse(mediaId)) : string.Empty;
            var memberLogoPath = node.GetNodeMediaUrl(DocumentFields.memberLogo.ToString());

            var committeeMember = new CommitteeMember { 
                Name = node.GetNodeValue(DocumentFields.memberName.ToString()),
                Position = node.GetNodeValue(DocumentFields.memberPosition.ToString()),
                Logo = memberLogoPath,
                Description = node.GetNodeValue(DocumentFields.memberDescription.ToString()),
                UrlPicker = MultiUrlPicker.GetUrlPicker(node.Id, DocumentFields.urlPicker.ToString())
            };

            return committeeMember;
        }

        public static Person GetPerson(this INode inode)
        {
            var node = new Node(inode.Id);
            var personLogoPath = node.GetNodeMediaUrl(DocumentFields.personImage.ToString());

            var person = new Person
            {
                Name = node.GetNodeValue(DocumentFields.title.ToString()),
                Position = node.GetNodeValue(DocumentFields.personPosition.ToString()),
                Logo = personLogoPath,
                Description = node.GetNodeValue(DocumentFields.itemDescription.ToString()),
                UrlPicker = MultiUrlPicker.GetUrlPicker(node.Id,DocumentFields.urlPicker.ToString())
            };

            return person;
        }


        public static EventSpeaker GetSpeaker(this INode inode)
        {
            var node = new Node(inode.Id);
            //var mediaId = node.GetNodeValue(DocumentFields.speakerImage.ToString());
            //var speakerImage = mediaId != string.Empty ? NodeUtility.GetMediaPath(int.Parse(mediaId)) : string.Empty;
            var speakerImage = node.GetNodeMediaUrl(DocumentFields.speakerImage.ToString());

            var speaker = new EventSpeaker
            {
                SpeakerNodeId = node.Id,
                SpeakerName = node.GetNodeValue(DocumentFields.title.ToString()),
                SpeakerDescription = node.GetNodeValue(DocumentFields.itemDescription.ToString()),
                SpeakerImage = speakerImage
            };

            return speaker;
        }
    }
}
