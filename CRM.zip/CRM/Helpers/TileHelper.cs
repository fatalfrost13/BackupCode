﻿namespace ECC.Web.Helpers
{
    using ECC.Web.Models;

    using global::Iomer.Umbraco.Extensions;

    using Iomer.Umbraco.Extensions;
    using IomerBase.U7.DataDefinition;
    using umbraco.NodeFactory;

    public static class TileHelper
    {
        public static TileItem GetTile(this Node tileNode)
        {
            const string baseClass = "item";
            //var mediaId = tileNode.GetNodeValue(DocumentFields.tileImage.ToString());
            var tileClass = tileNode.TileClass(baseClass);
            //var tileImagePath = mediaId != string.Empty ? NodeUtility.GetMediaPath(int.Parse(mediaId)) : string.Empty;
            var tileImagePath = tileNode.GetNodeMediaUrl(DocumentFields.tileImage.ToString());
            var tileTitle = tileNode.GetNodeValue(DocumentFields.tileTitle.ToString());
            var tileContent = tileNode.GetNodeValue(DocumentFields.tileContent.ToString());
            var tileNodeUrl = tileNode.GetUrl();
            var tileLinkTarget = tileNode.GetTarget();
            var tileMacro = tileNode.GetNodeValue(DocumentFields.tileMacro.ToString());
            var tileButtonText = tileNode.GetNodeValue(DocumentFields.tileButtonText.ToString());

            if (tileTitle != string.Empty)
            {
                tileTitle = string.Format("<h2 class=\"tileTitle\">{0}</h2>", tileTitle);
            }
            if (tileContent != string.Empty || tileButtonText != string.Empty)
            {
                tileContent = string.Format("<div class=\"tileContent\">{0}</div>", tileContent);
            }

            var tile = new TileItem 
            { 
                Title = tileTitle,
                Content = tileContent,
                CssClass = tileClass,
                ImageUrl = tileImagePath,
                Url = tileNodeUrl,
                Target = tileLinkTarget,
                Macro = tileMacro,
                NodeId = tileNode.Id,
                ButtonText = tileButtonText
            };
            return tile;
        }
    }
}
