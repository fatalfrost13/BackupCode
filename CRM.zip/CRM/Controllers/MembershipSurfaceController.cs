﻿using System.Security.Authentication;
using System.Security.Principal;
using umbraco;
using umbraco.cms.businesslogic.media;
using umbraco.cms.presentation.create.controls;
using Umbraco.Core;

using Microsoft.Crm.Sdk.Messages;

namespace ECC.Web.SurfaceControllers
{
    using Applications.Framework.Web.Providers;

    using ECC.Web.Controllers;
    using ECC.Web.Data.Crm;
    using ECC.Web.Email;
    using ECC.Web.Extensions;
    using ECC.Web.Helpers;
    using ECC.Web.Models;

    using IomerBase.Models;
    using Iomer.Umbraco.Extensions;
    using IomerBase.U7.DataDefinition;
    using IomerBase.U7.Models;

    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;
    using Moneris.Data.Models;

    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;
    using System.Web.Security;

    using umbraco.NodeFactory;

    using Email = Iomer.Extensions.Email.EmailManager;
#if DEBUG
    using log4net;
#endif
    public class AccountAndWebMembership
    {
        public Account account { get; set; }
        public appl_webmembership webMembership { get; set; }
    }

    public class MembershipSurfaceController : CrmController
    {
#if DEBUG
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
#endif

        private const string GLCode_Membership = "Membership Revenue";
        private const string GLCode_ACofCFee = "AC of C Affiliation Revenue Fee";
        private const string GLCode_VISA = "VISA";
        private const string GLCode_MasterCard = "Mastercard";
        private CacheItemController cache;
        public MembershipSurfaceController()
        {
            cache = new CacheItemController(this.service, this.DataContext);
        }


        public MembershipSurfaceController(IOrganizationService organizationService)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = new EccSvcContext(service);
            cache = new CacheItemController(this.service, this.DataContext);
        }

        public MembershipSurfaceController(IOrganizationService organizationService, EccSvcContext context)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = context;
            cache = new CacheItemController(this.service, this.DataContext);
        }

        public ActionResult MembershipPost()
        {
            return RedirectToCurrentUmbracoPage();
        }

        #region Web Account
        [HttpGet]
        public bool IsUserLoggedIn()
        {
            return System.Web.HttpContext.Current.User.Identity.IsAuthenticated;
        }

        [HttpPost]
        [ActionName("MemberLogin")]
        public ActionResult MemberLoginPost(MemberLoginModel model)
        {
            System.Web.HttpContext.Current.Session.RemoveAll();
            if (!this.TempData.ContainsKey("UserValidated"))
            {
                TempData.Add("UserValidated", false);
            }
            if (!this.TempData.ContainsKey("Message"))
            {
                TempData.Add("Message", string.Empty);
            }

            if (ModelState.IsValid)
            {
                // Check existence of web membership and account for this email address
                var userName = model.Username ?? string.Empty;
                var password = model.Password ?? string.Empty;
                var membershipModel = DataContext.appl_webmembershipSet.SingleOrDefault(i => i.appl_name == userName && i.appl_password == password && i.statecode == appl_webmembershipState.Active && i.ecc_account != null);
                var accountModel = membershipModel == null ? null : DataContext.AccountSet.FirstOrDefault(i => i.Id == membershipModel.ecc_account.Id);

                if (membershipModel != null && accountModel != null)
                {
                    var approved = true;
                    var lockedout = false;
                    var active = true;

                    // Ensure web membership is valid
                    if (membershipModel.appl_isapproved == null || !Convert.ToBoolean(membershipModel.appl_isapproved))
                    {
                        approved = false;
                        this.TempData["UserValidated"] = false;
                        this.TempData["Message"] = "Your account has not yet been approved.<br />Please check your email and follow the instructions to verify your account.";
                    }
                    if (membershipModel.appl_islockedout != null && Convert.ToBoolean(membershipModel.appl_islockedout))
                    {
                        lockedout = true;
                        this.TempData["UserValidated"] = false;
                        this.TempData["Message"] = "Your account is currently locked out.<br /><span style=\"color:black\">Contact <a href=\"mailto:info@edmontonchamber.com\" target=_blank>info@edmontonchamber.com</a> for assistance.</span>";
                    }
                    if (accountModel.StatusCode.Value != (int)account_statuscode.Active)
                    {
                        // Ensure account status is valid
                        var status = "inactive";
                        if (accountModel.StatusCode.Value == (int)account_statuscode.Expired)
                            status = "expired";
                        else if (accountModel.StatusCode.Value == (int)account_statuscode.Cancelled)
                            status = "cancelled";

                        active = false;
                        this.TempData["UserValidated"] = false;
                        this.TempData["Message"] = "Your account is currently " +
                            status +
                            ".<br /><span style=\"color:black\">Contact <a href=\"mailto:info@edmontonchamber.com\" target=_blank>info@edmontonchamber.com</a> for assistance.</span>";
                    }

                    var accountAccessible = approved && !lockedout && active;

                    if (accountAccessible)
                    {
                        FormsAuthentication.SetAuthCookie(userName, model.RememberMe);

                        // Load account info into cookie
                        this.GetMemberInfo(userName, accountModel.Id, true);

                        // Load account info into session
                        var accountInfo = cache.CachedAccountInfo;

                        new CrmExtensionsController(this.service, this.DataContext).CheckRoles(userName, membershipModel.ecc_account.Id, active, "", true);
                        this.TempData["UserValidated"] = null;
                        this.TempData["Message"] = null;
                        this.TempData["AccountID"] = null;

                        var returnUrl = this.RedirectUrl();
                        return this.Redirect(returnUrl);
                    }
                }
                else
                {
                    this.TempData["UserValidated"] = false;
                    this.TempData["Message"] = "Invalid Login Credentials<br /><span style=\"color:black; font-size:12px\">Contact <a href=\"mailto:info@edmontonchamber.com\" target=_blank>info@edmontonchamber.com</a> for assistance.</span>";
                }

                if (!Convert.ToBoolean(this.TempData["UserValidated"]))
                {
                    //error message, add custom error to viewstate model and return the page.
                    ModelState.AddModelError("CustomError", new Exception(this.TempData["Message"].ToString()));
                    var pageUrl = Request.RawUrl;
                    return this.Redirect(pageUrl);
                }
            }

            return this.RedirectToCurrentUmbracoPage();
        }

        [HttpGet]
        [ActionName("MemberLogout")]
        public ActionResult MemberLogoutPost(MemberLoginModel model)
        {
            this.CustomSignout();
            //var membersNode = new Node(Int32.Parse(ConfigurationManager.AppSettings["membersNodeId"]));
            var defaultLogoutPage = "/logout/";
            return Redirect(defaultLogoutPage);
        }

        [HttpPost]
        [ActionName("ForgotPassword")]
        public ActionResult ForgotPassword(MemberLoginModel model)
        {
            if (!this.TempData.ContainsKey("Message"))
            {
                TempData["Message"] = "";
            }
            this.TempData["Message"] = string.Format("<span class=\"success\">Account information has been sent to <strong>{0}</strong></span>", model.Username);
            if (model.Username != string.Empty)
            {
                var emailStatus = SendForgotPasswordEmail(model, false);
                if (!emailStatus.EmailSent && emailStatus.ErrorMessage != string.Empty)
                {
                    var errorMessage = string.Format("<span class=\"failure\">{0}</span>", emailStatus.ErrorMessage);
                    //this.TempData["Message"] = errorMessage;
                    this.TempData["Message"] = null;

                    //error message, add custom error to viewstate model and return the page.
                    ModelState.AddModelError("CustomError", new Exception(errorMessage));
                    return CurrentUmbracoPage();
                }
            }
            return RedirectToCurrentUmbracoPage();
        }

        [HttpPost]
        [ActionName("ChangePassword")]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            string errMsg = "";
            if (!TempData.ContainsKey("Message"))
            {
                TempData.Add("Message", string.Empty);
            }
            if (ModelState.IsValid)
            {
                // ChangePassword will throw an exception rather
                // than return false in certain failure scenarios.
                bool changePasswordSucceeded;
                try
                {
                    MembershipUser currentUser = Membership.GetUser(User.Identity.Name, true /* userIsOnline */);
                    changePasswordSucceeded = currentUser.ChangePassword(model.OldPassword, model.NewPassword);
                }
                catch (Exception e)
                {
                    errMsg = e.Message;
                    ModelState.AddModelError("CustomError", new Exception(errMsg));
                    return CurrentUmbracoPage();
                }

                if (changePasswordSucceeded)
                {
                    TempData["Message"] = "Your password has been updated";
                    return Redirect("/member-profile");
                }
                errMsg = "The 'Current Password' you have entered is incorrect.";
                this.ModelState.AddModelError("CustomError", new Exception(errMsg));
                return this.CurrentUmbracoPage();
            }
            if (model.NewPassword.Length > 100 || model.NewPassword.Length < 6)
            {
                errMsg = "Password length must be greater than 6 and less than 100";
            }
            if (model.NewPassword != model.ConfirmPassword)
            {
                errMsg = "Confirm password does not match new password";
            }
            this.ModelState.AddModelError("CustomError", new Exception(errMsg));
            return this.CurrentUmbracoPage();
        }

        public appl_webmembership GetWebMembership(string email)
        {
            var webMembership = DataContext.appl_webmembershipSet.SingleOrDefault(i => i.appl_name == email && i.statecode == appl_webmembershipState.Active && i.appl_isapproved == true && i.ecc_account != null);
            return webMembership;
        }

        public string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
            var res = "";
            var rnd = new Random();
            while (0 < length--)
                res += valid[rnd.Next(valid.Length)];
            return res;
        }

        public VerifyAccountModel VerifyAccount(string webMembershipId)
        {
            var verifyAccount = new VerifyAccountModel
            {
                WebMembershipId = Guid.Empty,
                Message = string.Empty,
                AccountVerified = false
            };
            var memberId = Guid.Parse(webMembershipId);
            var member = DataContext.appl_webmembershipSet.SingleOrDefault(i => i.appl_webmembershipId == memberId && i.statecode == appl_webmembershipState.Active);
            if (member != null)
            {
                verifyAccount.WebMembershipId = memberId;
                verifyAccount.AccountVerified = true;
                if (member.appl_isapproved == null || !Convert.ToBoolean(member.appl_isapproved))
                {
                    member.appl_isapproved = true;
                    DataContext.UpdateObject(member);
                    DataContext.SaveChanges();
                    verifyAccount.Message = "Your account has been verified.";

                }
                else
                {
                    verifyAccount.Message = "Your account has already been verified";
                }
            }
            else
            {
                verifyAccount.AccountVerified = false;
                verifyAccount.Message = "Invalid Request";
            }
            return verifyAccount;
        }

        public ActionResult FilteredCities(string provinceId)
        {
            var cityList =
                cache.CachedCityList.CityList.Where(i => i.ProvinceId == new Guid(provinceId)).ToList();
            var result =
                new List<GenericItem>(
                    cityList.Select(i => new GenericItem { Text = i.Name, Value = i.CityId.ToString() }).ToList());
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public bool AccountExists(string email)
        {
            return GetWebMembership(email) != null;
        }

        public bool AccountRecordExists(string email)
        {
            return DataContext.AccountSet.FirstOrDefault(e => e.EMailAddress1 == email) != null;
        }

        public Account GetAccountByEmail(string email)
        {
            return DataContext.AccountSet.FirstOrDefault(e => e.EMailAddress1 == email);
        }

        #endregion

        #region Email Notification

        public Email.EmailStatus SendForgotPasswordEmail(MemberLoginModel model, bool admin = false)
        {
            // first get email parameters
            var currentNode = Node.GetCurrent();
            var notificationTemplateId = currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString())
                                         != string.Empty
                                             ? int.Parse(currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString()))
                                             : 0;

            var emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = string.Empty };

            if (notificationTemplateId > 0)
            {
                var notificationNode = new Node(notificationTemplateId);
                var emailSubject = notificationNode.GetNodeValue(DocumentFields.emailSubject.ToString());
                var emailTo = notificationNode.GetNodeValue(DocumentFields.emailAdmin.ToString());
                //var emailFrom = notificationNode.GetNodeValue(DocumentFields.emailFrom.ToString());
                var emailMessage = notificationNode.GetNodeValue(DocumentFields.emailMessage.ToString());
                var emailBcc = string.Empty;
                const string EmailTemplate = "/Email/StandardTemplate.html";

                if (!admin)
                {
                    //client email
                    emailTo = model.Username;
                }
                else
                {
                    emailBcc = notificationNode.GetNodeValue(DocumentFields.emailBcc.ToString());
                }

                var membershipModel = (from webMembership in DataContext.appl_webmembershipSet
                                       where webMembership.appl_name == emailTo && webMembership.statecode == appl_webmembershipState.Active
                                       select new { WebMembership = webMembership }).SingleOrDefault();

                //var membershipModel = cache.CachedUserInfo;

                if (membershipModel != null)
                {
                    if (emailTo != string.Empty)
                    {

                        var replacements = DictionaryReplacement.RecoverPassword(
                            this.service,
                            membershipModel.WebMembership);

                        emailStatus = Email.SendEmail(
                            membershipModel.WebMembership.ToEntityReference(),
                            emailSubject,
                            emailMessage,
                            EmailTemplate,
                            replacements,
                            null,
                            null,
                            emailBcc);
                    }
                }
                else
                {
                    emailStatus.EmailSent = false;
                    emailStatus.ErrorMessage = "Your account could not be found in the system";
                }
            }

            return emailStatus;
        }

        public void CalculatePayment(AccountModel model, int numberOfBusinessTypes)
        {
            // Base payment details
            model.Payment = new PaymentModel();
            model.Payment.NameOnCard = model.NameOnCard ?? string.Empty;
            model.Payment.Method = model.SelectedPaymentMethod ?? string.Empty;
            model.Payment.CreditCardNumber = model.CreditCardNumber ?? string.Empty;
            model.Payment.ExpiryDateMonth = model.ExpiryDateMonth ?? string.Empty;
            model.Payment.ExpiryDateYear = model.ExpiryDateYear ?? string.Empty;

            // Membership fee
            Decimal numEmployee = ((Decimal)model.NumOfPartTimeEmployees / 3 + (Decimal)model.NumOfFullTimeEmployees);
            Decimal annualMembershipInvestment = 0M;
            numEmployee = Math.Round(numEmployee);
            if (numEmployee < 1)
            {
                numEmployee = 1;
            }
            if (numEmployee <= 1000)
            {
                var annualFee = cache.CachedAnualMemberShipFeeListCurrentYear.AnualMemberShipFeeList.FirstOrDefault(i => (numEmployee <= i.Max && numEmployee >= i.Min)).Price;
                annualMembershipInvestment += annualFee;
            }
            else
            {
                var overFee = (numEmployee - 1000) * model.Over1000Fee;
                var annualFee = cache.CachedAnualMemberShipFeeListCurrentYear.AnualMemberShipFeeList.FirstOrDefault(i => i.Max > 999).Price;
                annualMembershipInvestment += annualFee + overFee;
            }

            // Total Fees
            var existingMember = IsUserMember();
            model.Payment.SubTotalAmount = annualMembershipInvestment +
                (existingMember ? 0 : model.EntranceFee) +
                model.AccFee +
                model.BusinessTypeFee * (numberOfBusinessTypes - 1);
            model.Payment.TotalTaxAmount = model.Payment.SubTotalAmount * model.Payment.GstRate;
            model.Payment.TotalAmount = model.Payment.SubTotalAmount + model.Payment.TotalTaxAmount;

            model.Payment.Details.Add(new PaymentDetailModel()
            {
                Description = "Membership Dues",
                Fee = annualMembershipInvestment,
                Quantity = "1",
                TaxAmount = annualMembershipInvestment * model.Payment.GstRate,
                GLCode = GetGLCode(GLCode_Membership)
            });

            if (!existingMember)
            {
                model.Payment.Details.Add(new PaymentDetailModel()
                {
                    Description = "Entrance Fee",
                    Fee = model.EntranceFee,
                    Quantity = "1",
                    TaxAmount = 0,
                    GLCode = GetGLCode(GLCode_Membership)
                });
            }

            model.Payment.Details.Add(new PaymentDetailModel()
            {
                Description = "Alberta Chamber of Commerce Affiliation Fee",
                Fee = model.AccFee,
                Quantity = "1",
                TaxAmount = 0,
                GLCode = GetGLCode(GLCode_ACofCFee)
            });

            if (numberOfBusinessTypes > 1)
            {
                model.Payment.Details.Add(new PaymentDetailModel()
                {
                    Description = (numberOfBusinessTypes - 1) + " additional business directory categories",
                    Fee = model.BusinessTypeFee,
                    Quantity = (numberOfBusinessTypes - 1).ToString(),
                    //TaxAmount = (businessTypeFee * (numberOfBusinessTypes-1)) * model.Payment.GstRate,
                    GLCode = GetGLCode(GLCode_Membership)
                });
            }
        }

        private bool IsUserMember()
        {
            if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated
                    && cache.CachedAccountInfo != null
                    && cache.CachedAccountInfo.Account != null)
            {
                var account = cache.CachedAccountInfo.Account;
                return (account.ecc_accounttype.Value == (int)Accountecc_accounttype.Member);
            }
            else { return false; }
        }

        public MonerisResponse AccountOnlinePayment(AccountModel model)
        {
            var transactionController = new MonerisController();
            var expiryDate = model.ExpiryDateYear.Trim().Substring(2) + model.ExpiryDateMonth.Trim();

            var payerName = model.Payment.NameOnCard.Replace(" ", "");
            var monerisReferenceId = string.Format("ECC_MemberReg_{0}{1}", payerName, DateTime.Now.Ticks);
            model.Payment.RefNo = monerisReferenceId;

            var fee = String.Format("{0:0.00}", model.Payment.TotalAmount);

            var cachedProvince = cache.CachedProvinceStateList.ProvinceStateList.ToList().FirstOrDefault(p => p.ProvinceId == model.ProvinceId);

            transactionController.SetUserInfo(
                model.GeneralContactFirstName,
                model.GeneralContactLastName,
                model.AccountName,
                model.Address1 + "/ " + model.Address2,
                model.City,
                model.Province,
                model.PostCode, cachedProvince.CountryName, model.Phone,
                model.Fax, model.Email);

            var recurringTransaction = new MonerisRecurringTransaction()
            {
                Frequency = RecurringFrequency.Month,
                StartNow = true,
                StartDate = DateTime.Now.AddMonths(12),
                RecurringCount = 99,
                Period = 12,
                RecurringAmount = Convert.ToDecimal(fee)
            };
            if (!model.AutoRenew)
            {
                recurringTransaction = null;
            }

            transactionController.SetNewTransaction(monerisReferenceId, fee, model.Payment.CreditCardNumber,
                model.Payment.NameOnCard, expiryDate, model.CcvNumber, "0", "0", "0", "0", "MemberRegistration", recurringTransaction);
            var response = transactionController.ProcessMonerisTransaction();

            model.Payment.MonerisReferenceNum = response.ReferenceNumber;

            return response;

        }

        public AccountModel GetAccountModel()
        {
#if DEBUG  

            System.Diagnostics.Stopwatch w = new System.Diagnostics.Stopwatch();

            w.Reset();
            w.Start();
#endif

            AccountModel accountModel;
            if (IsUserLoggedIn())
            {
                string email = System.Web.HttpContext.Current.User.Identity.Name;
                var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
                var account = crmExtensions.GetAccount(email);

                accountModel = new AccountModel
                {
                    Id = account.AccountId.Value,
                    AccountName = account.Name ?? "",
                    LegalName = account.ecc_legalname ?? "",
                    Address1 = account.Address1_Line1 ?? "",
                    Address2 = account.Address1_Line2 ?? "",
                    CityId = account.ecc_city != null ? account.ecc_city.Id : Guid.Empty,
                    Website = account.WebSiteURL ?? "",
                    Phone = account.Telephone1 ?? "",
                    Fax = account.Fax ?? "",
                    ReferralFormEmail = account.ecc_referralformemail,
                    Email = account.EMailAddress1,
                    PostCode = account.Address1_PostalCode ?? "",
                    CompanyLogoUrl = account.ecc_CompanyLogoURL ?? "",
                    YouTube = account.ecc_youtube ?? "",
                    GooglePlus = account.ecc_googleplus ?? "",
                    FaceBook = account.ecc_Facebook ?? "",
                    LinkedIn = account.ecc_LinkedIn ?? "",
                    Twitter = account.ecc_Twitter ?? "",
                    EccRepresentative = account.ecc_representative ?? "",
                    NumOfFullTimeEmployees =
                        account.ecc_NumberOfFullTimeEmployees == null
                            ? 0
                            : (int)account.ecc_NumberOfFullTimeEmployees,
                    NumOfPartTimeEmployees =
                        account.ecc_NumberOfPartTimeEmployees == null
                            ? 0
                            : (int)account.ecc_NumberOfPartTimeEmployees,

                    ProvinceId = account.ecc_provincestate != null ? account.ecc_provincestate.Id : Guid.Empty,
                    ReasonForJoining = account.ecc_ReasonforJoining != null ? account.ecc_ReasonforJoining.Value.ToString() : "",
                    BusinessDirectory = account.ecc_listingtype != null ? account.ecc_listingtype.Value.ToString() : "",
                    AutoRenew = account.ecc_autorenewal != null ? account.ecc_autorenewal.Value : false
                };
#if DEBUG
                w.Stop();
                Log.DebugFormat("{0}()=> Load accountModel (Elapsed Time={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, w.ElapsedMilliseconds);
                w.Reset();
                w.Start();
#endif
                if (accountModel.CityId != Guid.Empty)
                {
                    accountModel.City =
                        cache.CachedCityList.CityList
                            .FirstOrDefault(c => c.CityId == accountModel.CityId).Name;
                }

                if (accountModel.ProvinceId != Guid.Empty)
                {
                    accountModel.Province =
                        cache.CachedProvinceStateList.ProvinceStateList
                            .FirstOrDefault(p => p.ProvinceId == accountModel.ProvinceId).Name;
                }

#if DEBUG
                w.Stop();
                Log.DebugFormat("{0}()=> Load Cities and Provinces (Elapsed Time={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, w.ElapsedMilliseconds);
                w.Reset();
                w.Start();
#endif

                var businessTypeList = new List<GenericItem>();
                var existingBusinessTypeRelation = DataContext.ecc_account_ecc_businesstypeSet.Where(a => a.accountid == accountModel.Id).ToList();
                foreach (var relation in existingBusinessTypeRelation)
                {
                    var businessType = DataContext.ecc_businesstypeSet.SingleOrDefault(bt => bt.ecc_businesstypeId == relation.ecc_businesstypeid);
                    var businessTypeTitle = businessType.ecc_title;
                    if (businessType.ecc_businesstypeId != null)
                    {
                        var businessTypeId = businessType.ecc_businesstypeId.Value;
                        businessTypeList.Add(new GenericItem { Text = businessTypeTitle, Value = businessTypeId.ToString() });
                    }
                }
                accountModel.BusinessTypeList = businessTypeList;

#if DEBUG
                w.Stop();
                Log.DebugFormat("{0}()=> Load usinessTypes (Elapsed Time={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, w.ElapsedMilliseconds);
                w.Reset();
                w.Start();
#endif

            }
            else
            {
                accountModel = new AccountModel();
            }

#if DEBUG
            w.Stop();
            Log.DebugFormat("{0}()=> Till final time (Elapsed Time={1})", System.Reflection.MethodInfo.GetCurrentMethod().Name, w.ElapsedMilliseconds);
#endif

            var configurationSet = DataContext.ecc_configurationSet.FirstOrDefault();
            accountModel.EntranceFee = configurationSet.ecc_EntranceFee.Value;//One-Time Application Fee
            accountModel.AccFee = configurationSet.ecc_ACCFee.Value;//Alberta Chamber of Commerce Fee
            accountModel.BusinessTypeFee = configurationSet.ecc_businesstypefee.Value;
            accountModel.Over1000Fee = configurationSet.ecc_Over1000employeesfee.Value;

            //var anualMemberShipFeeList = cache.CachedAnualMemberShipFeeListCurrentYear;

            //accountModel.AnualMembershipFee = 0;// financeCurrentYear.ecc_Fee.Value;//Annual Membership Investment        

            return accountModel;
        }

        [HttpPost]
        [ActionName("UpdateOrAddContact")]
        public ActionResult UpdateOrAddContact(AccountContact model)
        {

            var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
            var account = crmExtensions.GetAccountById(model.AccountId);

            var accountContactList = (
                    from c in this.DataContext.ContactSet
                    join a in this.DataContext.AccountSet on c.ecc_Account.Id equals a.AccountId.Value
                    where
                        c.StateCode == ContactState.Active
                    where
                        a.AccountId.Value == model.AccountId
                        && a.StateCode == AccountState.Active
                    orderby c.LastName
                    select c
                )
                .ToList();

            var contact = model.Id == Guid.Empty ? null : accountContactList.FirstOrDefault(i => i.Id == model.Id);
            if (contact == null)
            {
                contact = new Contact()
                {
                    ecc_Account = account.ToEntityReference()
                };
                //accountContactList.Add(contact);
                DataContext.AddObject(contact);
                //account.contac
            }

            contact.FirstName = model.FirstName;
            contact.LastName = model.LastName;
            contact.ecc_ContactType = new OptionSetValue(Convert.ToInt32(model.ContactType));
            contact.EMailAddress1 = model.Email;
            contact.JobTitle = model.JobTitle;
            contact.Telephone1 = model.Phone;
            contact.ecc_MainContact = model.MainContact;

            if (!DataContext.IsAttached(account))
            {
                DataContext.Attach(account);
            }
            DataContext.UpdateObject(contact);
            DataContext.UpdateObject(account);
            DataContext.SaveChanges();

            //var cachedContact = cache.CachedContacts.ContactList.FirstOrDefault(i => i.Id == model.Id);
            //if (cachedContact != null)
            //    cache.CachedContacts.ContactList.Remove(cachedContact);

            //cache.CachedContacts.ContactList.Add(contact);

            System.Web.HttpContext.Current.Session["UserContacts"] = null;
            System.Web.HttpContext.Current.Session["status"] = "succ";
            return CurrentUmbracoPage();
        }

        [HttpPost]
        [ActionName("DeleteContact")]
        public bool DeleteContact(string id)
        {
            var contactToDelete = DataContext.ContactSet.FirstOrDefault(i => i.Id == new Guid(id));

            DataContext.DeleteObject(contactToDelete);
            DataContext.SaveChanges();
            //var cachedContactToDelete = cache.CachedContacts.ContactList.FirstOrDefault(i => i.Id == new Guid(id));
            //if (contactToDelete!=null)
            //    cache.CachedContacts.ContactList.Remove(cachedContactToDelete);
            System.Web.HttpContext.Current.Session["UserContacts"] = null;
            return true;
        }

        [HttpPost]
        [ActionName("UpdateProfile")]
        public ActionResult UpdateProfile(AccountModel model)
        {

            string currentUrl = this.Request.UrlReferrer.AbsolutePath;
            if (ModelState.IsValid)
            {
                try
                {
                    SaveOrCreateAccount(model);
                    System.Web.HttpContext.Current.Session["status"] = "succ";
                    //return Redirect(currentUrl + "?status=succ");
                }
                catch (Exception e)
                {
                    return Redirect(currentUrl + "?status=error&message=" + e.Message);
                }

            }

            return CurrentUmbracoPage();
        }

        public AccountAndWebMembership SaveOrCreateAccount(AccountModel model)
        {


            //create businessTypes here
            var provId = model.ProvinceId;
            var cityId = model.CityId;
            model.City = cache.CachedCityList.CityList.First(c => c.CityId == cityId).Name;
            model.Province = cache.CachedProvinceStateList.ProvinceStateList.First(c => c.ProvinceId == provId).Name;


            var website = "";
            if (!string.IsNullOrEmpty(model.Website))
            {
                if (!model.Website.StartsWith("http://") && !model.Website.StartsWith("https://"))
                    website = string.Format("http://{0}", model.Website);
                else
                    website = model.Website;
            }



            var businessTypeIdSList = new List<Nullable<Guid>>();
            var businessTypeIdStringList = model.SelectedBusinessTypeIds.Split(';').Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();
            foreach (var id in businessTypeIdStringList)
            {
                if (!string.IsNullOrEmpty(id))
                {
                    businessTypeIdSList.Add(new Guid(id));
                }
            }

            var businessTypeRelation =
                DataContext.ecc_businesstypeSet.ToList()
                    .Where(i => businessTypeIdSList.Contains(i.ecc_businesstypeId))
                    .ToList();

            var changes = string.Empty;
            Account account;
            var accountExists = this.AccountRecordExists(model.Email);
            if (!accountExists)
            {

                account = new Account()
                {
                    Name = model.AccountName,
                    ecc_legalname = model.LegalName,
                    Address1_Line1 = model.Address1,
                    Address1_Line2 = model.Address2,

                    ecc_city = new EntityReference(geo_city.EntityLogicalName, cityId),
                    WebSiteURL = website,
                    Telephone1 = model.Phone,
                    Fax = model.Fax,
                    ecc_referralformemail = model.ReferralFormEmail,
                    EMailAddress1 = model.Email,
                    Address1_PostalCode = model.PostCode,
                    ecc_Facebook = model.FaceBook,
                    ecc_googleplus = model.GooglePlus,
                    ecc_youtube = model.YouTube,
                    ecc_LinkedIn = model.LinkedIn,
                    ecc_Twitter = model.Twitter,
                    ecc_NumberOfFullTimeEmployees = model.NumOfFullTimeEmployees,
                    ecc_NumberOfPartTimeEmployees = model.NumOfPartTimeEmployees,

                    ecc_ReasonforJoining = new OptionSetValue(Convert.ToInt32(model.ReasonForJoining)),
                    ecc_listingtype = new OptionSetValue(Convert.ToInt32(model.BusinessDirectory)),
                    ecc_accounttype =
                        model.PayByCreditCard
                            ? new OptionSetValue((int)Accountecc_accounttype.Member)
                            : new OptionSetValue((int)Accountecc_accounttype.Prospect),
                    ecc_isgroupinsurance = false,
                    StatusCode = new OptionSetValue((int)account_statuscode.Active),
                    ecc_autorenewal = model.PayByCreditCard && model.AutoRenew,
                    ecc_provincestate = new EntityReference(geo_province.EntityLogicalName, provId),
                    ecc_ConsenttoCorrespondence = true,
                    ecc_account_ecc_businesstype = businessTypeRelation,
                    ecc_representative = model.EccRepresentative

                };
                model.Id = account.Id;
                DataContext.AddObject(account);

            }
            else
            {
                var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
                if (model.Id == Guid.Empty)
                {
                    account = GetAccountByEmail(model.Email);

                    if (account.StateCode == AccountState.Inactive)
                    {
                        var setStateRequest = new SetStateRequest()
                        {
                            EntityMoniker = account.ToEntityReference(),
                            State = new OptionSetValue((int)AccountState.Active),
                            Status = new OptionSetValue((int)account_statuscode.Active)
                        };

                        var result = (SetStateResponse)this.service.Execute(setStateRequest);
                        this.DataContext.ClearChanges();
                        account = this.GetAccountByEmail(model.Email);
                    }

                    model.Id = account.AccountId.Value;
                }
                else
                {
                    account = crmExtensions.GetAccountById(model.Id);
                }

                if (account.ecc_NumberOfFullTimeEmployees != null && account.ecc_NumberOfFullTimeEmployees.Value != model.NumOfFullTimeEmployees)
                    changes += string.Format("Number of full time employees changed from {0} to {1}", account.ecc_NumberOfFullTimeEmployees.Value, model.NumOfFullTimeEmployees);

                if (account.ecc_NumberOfPartTimeEmployees != null && account.ecc_NumberOfPartTimeEmployees.Value != model.NumOfPartTimeEmployees)
                    changes += string.Format("Number of part time employees changed from {0} to {1}", account.ecc_NumberOfPartTimeEmployees.Value, model.NumOfPartTimeEmployees);

                //if (account.ecc_NumberOfPartTimeEmployees != null && account.ecc_NumberOfPartTimeEmployees.Value != model.NumOfPartTimeEmployees) // why doing it twice 
                //    changes += string.Format("Number of part time employees changed from {0} to {1}", account.ecc_NumberOfPartTimeEmployees.Value, model.NumOfPartTimeEmployees);

                account.Name = model.AccountName;
                account.ecc_legalname = model.LegalName;
                account.Address1_Line1 = model.Address1;
                account.Address1_Line2 = model.Address2;
                account.ecc_city = new EntityReference(geo_city.EntityLogicalName, cityId);
                account.WebSiteURL = website;
                account.Telephone1 = model.Phone;
                account.Fax = model.Fax;
                account.ecc_referralformemail = model.ReferralFormEmail;
                account.EMailAddress1 = model.Email;
                account.Address1_PostalCode = model.PostCode;
                account.ecc_Facebook = model.FaceBook;
                account.ecc_youtube = model.YouTube;
                account.ecc_googleplus = model.GooglePlus;
                account.ecc_LinkedIn = model.LinkedIn;
                account.ecc_Twitter = model.Twitter;

                account.ecc_NumberOfFullTimeEmployees = model.NumOfFullTimeEmployees;
                account.ecc_NumberOfPartTimeEmployees = model.NumOfPartTimeEmployees;
                account.ecc_ReasonforJoining = new OptionSetValue(Convert.ToInt32(model.ReasonForJoining));
                account.ecc_listingtype = new OptionSetValue(Convert.ToInt32(model.BusinessDirectory));
                account.StatusCode = new OptionSetValue((int)account_statuscode.Active);
                account.ecc_provincestate = new EntityReference(geo_province.EntityLogicalName, provId);
                account.ecc_ConsenttoCorrespondence = true;
                if (!String.IsNullOrEmpty(model.CreditCardNumber))
                {
                    account.ecc_accounttype =
                        model.PayByCreditCard
                            ? new OptionSetValue((int)Accountecc_accounttype.Member)
                            : new OptionSetValue((int)Accountecc_accounttype.Prospect);
                    account.ecc_isgroupinsurance = false;
                    account.StatusCode = new OptionSetValue((int)account_statuscode.Active);
                    account.ecc_autorenewal = model.PayByCreditCard && model.AutoRenew;
                    account.ecc_representative = model.EccRepresentative;
                }

                var existingBusinessTypeRelation =
                    DataContext.ecc_account_ecc_businesstypeSet.Where(a => a.accountid == model.Id).ToList();

                foreach (var relation in existingBusinessTypeRelation)
                {
                    var businessType = DataContext.ecc_businesstypeSet.Where(
                            bt => bt.ecc_businesstypeId == relation.ecc_businesstypeid).SingleOrDefault();
                    crmExtensions.DeAssociateManyToManyEntityRecords(account, businessType, relation.LogicalName);
                }
                cache.AccountBusinessType.Relationships.RemoveAll(i => i.AccountId == account.AccountId);

                foreach (var relation in businessTypeRelation)
                {
                    crmExtensions.AssociateManyToManyEntityRecords(account, relation, "ecc_account_ecc_businesstype");
                    cache.AccountBusinessType.Relationships.Add(new AccountBusinessTypeRelationship()
                    {
                        AccountId = account.AccountId.Value,
                        BusinessTypeId = relation.ecc_businesstypeId.Value
                    });
                }

                if (existingBusinessTypeRelation != null && businessTypeRelation != null && existingBusinessTypeRelation.Count != businessTypeRelation.Count)
                    changes += string.Format("Number of business listings changed from {0} to {1}", existingBusinessTypeRelation.Count, existingBusinessTypeRelation.Count);
                if (!DataContext.IsAttached(account))
                {
                    DataContext.Attach(account);
                }
                DataContext.UpdateObject(account);
            }

            DataContext.SaveChanges();

            var accountContactList = (
                    from c in this.DataContext.ContactSet
                    join a in this.DataContext.AccountSet on c.ecc_account_contact_Account.Id equals a.AccountId.Value
                    where
                        c.StateCode == ContactState.Active
                    where
                        a.AccountId.Value == account.AccountId.Value
                        && a.StateCode == AccountState.Active
                    orderby c.LastName
                    select c
                )
                .ToList();

            //Create/Add General Contact
            if (!string.IsNullOrEmpty(model.GeneralContactEmail))
            {
                var GeneralContact =
                    accountContactList.FirstOrDefault(
                        i => i.ecc_ContactType.Value == (int)Contactecc_ContactType.Other);
                if (GeneralContact == null)
                {
                    GeneralContact = new Contact();
                    accountContactList.Add(GeneralContact);
                    DataContext.AddObject(GeneralContact);
                }
                GeneralContact.FirstName = model.GeneralContactFirstName;
                GeneralContact.LastName = model.GeneralContactLastName;
                GeneralContact.EMailAddress1 = model.GeneralContactEmail;
                GeneralContact.JobTitle = model.GeneralContactPosition;
                GeneralContact.Telephone1 = model.GeneralContactPhone;
                GeneralContact.ecc_MainContact = model.GeneralContactIsMain;
                GeneralContact.ecc_ContactType = new OptionSetValue((int)Contactecc_ContactType.Other);
                DataContext.UpdateObject(GeneralContact);
            }

            // Create/Add Billing Contact
            if (!string.IsNullOrEmpty(model.BillingContactEmail))
            {
                var BillingContact =
                    accountContactList.FirstOrDefault(
                        i => i.ecc_ContactType.Value == (int)Contactecc_ContactType.Billing);
                if (BillingContact == null)
                {
                    BillingContact = new Contact();
                    accountContactList.Add(BillingContact);
                    DataContext.AddObject(BillingContact);
                }
                BillingContact.FirstName = model.BillingContactFirstName;
                BillingContact.LastName = model.BillingContactLastName;
                BillingContact.EMailAddress1 = model.BillingContactEmail;
                BillingContact.JobTitle = model.BillingContactPosition;
                BillingContact.Telephone1 = model.BillingContactPhone;
                BillingContact.ecc_MainContact = model.BillingContactIsMain;
                BillingContact.ecc_ContactType = new OptionSetValue((int)Contactecc_ContactType.Billing);
                DataContext.UpdateObject(BillingContact);
            }


            //Create/Add HR Contact
            if (!string.IsNullOrEmpty(model.HRContactEmail))
            {
                var HRContact =
                    accountContactList.FirstOrDefault(
                        i => i.ecc_ContactType.Value == (int)Contactecc_ContactType.HR);
                if (HRContact == null)
                {
                    HRContact = new Contact();
                    accountContactList.Add(HRContact);
                    DataContext.AddObject(HRContact);
                }
                HRContact.FirstName = model.HRContactFirstName;
                HRContact.LastName = model.HRContactLastName;
                HRContact.EMailAddress1 = model.HRContactEmail;
                HRContact.JobTitle = model.HRContactPosition;
                HRContact.Telephone1 = model.HRContactPhone;
                HRContact.ecc_MainContact = model.HRContactIsMain;
                HRContact.ecc_ContactType = new OptionSetValue((int)Contactecc_ContactType.HR);
                DataContext.UpdateObject(HRContact);
            }


            //Create/Add Sales Contact
            if (!string.IsNullOrEmpty(model.SalesContactEmail))
            {
                var SalesContact =
                    accountContactList.FirstOrDefault(
                        i => i.ecc_ContactType.Value == (int)Contactecc_ContactType.Sales);
                if (SalesContact == null)
                {
                    SalesContact = new Contact();
                    accountContactList.Add(SalesContact);
                    DataContext.AddObject(SalesContact);
                }
                SalesContact.FirstName = model.SalesContactFirstName;
                SalesContact.LastName = model.SalesContactLastName;
                SalesContact.EMailAddress1 = model.SalesContactEmail;
                SalesContact.JobTitle = model.SalesContactPosition;
                SalesContact.Telephone1 = model.SalesContactPhone;
                SalesContact.ecc_MainContact = model.SalesContactIsMain;
                SalesContact.ecc_ContactType = new OptionSetValue((int)Contactecc_ContactType.Sales);
                DataContext.UpdateObject(SalesContact);
            }
            account.ecc_account_contact_Account = !accountContactList.Any() ? null : accountContactList;

            if (!DataContext.IsAttached(account))
            {
                DataContext.Attach(account);
            }

            //Update password
            var webMembership = DataContext.appl_webmembershipSet.FirstOrDefault(wm => wm.EmailAddress == model.Email);
            if (!IsUserLoggedIn())
            {
                if (webMembership != null && model.Password == model.ConfirmPassword)
                {
                    webMembership.appl_password = model.Password;
                    webMembership.appl_isapproved = true;
                }
                DataContext.UpdateObject(webMembership);
            }

            var mediaService = Services.MediaService;
            foreach (string upload in Request.Files)
            {
                if (Request.Files[upload].ContentLength == 0) continue;
                HttpPostedFileBase mediaFile = Request.Files[upload];
                var parentMediaNode = uQuery.GetMediaByName("Member Logos").FirstOrDefault();
                var newMediaImg = mediaService.CreateMedia(account.Name + " Logo", parentMediaNode.Id, "Image");
                newMediaImg.SetValue("umbracoFile", mediaFile);
                mediaService.Save(newMediaImg);

                account.ecc_CompanyLogoURL = newMediaImg.GetValue("umbracoFile").ToString();
            }
            DataContext.UpdateObject(account);
            DataContext.SaveChanges();
            this.UpdateAccountCache(model);

            System.Web.HttpContext.Current.Session.RemoveAll();//remove all sessions to clear cache.
            System.Web.HttpContext.Current.Session.Clear();
            return new AccountAndWebMembership { account = account, webMembership = webMembership };
        }

        [HttpPost]
        [ActionName("CreateAccount")]
        public ActionResult CreateAccount(AccountModel model)
        {

            var currentUrl = this.Request.UrlReferrer.AbsolutePath;

            if (!this.TempData.ContainsKey("UserValidated"))
            {
                TempData.Add("UserValidated", false);
            }
            if (!this.TempData.ContainsKey("Message"))
            {
                TempData.Add("Message", string.Empty);
            }


            if (ModelState.IsValid)
            {

                var businessTypeIdStringList = model.SelectedBusinessTypeIds.Split(';').Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();

                CalculatePayment(model, businessTypeIdStringList.Count());
                int cardtypeId = 0;
                if (model.PayByCreditCard)
                {
                    var result = AccountOnlinePayment(model);
                    switch (result.ResponseStatus)
                    {
                        case PaymentStatus.Approved:
                            break;
                        case PaymentStatus.Declined:
                            return this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "declined", result.ResponseMessage));
                        //return Redirect(currentUrl + "?status=declined");
                        case PaymentStatus.Incomplete:
                            return this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "incomplete", result.ResponseMessage));
                        //return Redirect(currentUrl + "?status=incomplete");
                        case PaymentStatus.Error:
                            return this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "error", result.ResponseMessage));
                            //return Redirect(currentUrl + "?status=error");
                    }
                    cardtypeId = Convert.ToInt32(model.SelectedPaymentMethod);
                }

                var accountAndWebMembership = SaveOrCreateAccount(model);
                var account = accountAndWebMembership.account;
                var webMembership = accountAndWebMembership.webMembership;

                model.Id = account.Id;
                //create payment
                var pmt = new ecc_payment();
                pmt.ecc_IsGI = false;
                pmt.ecc_gst = new Money(model.Payment.TotalTaxAmount);
                pmt.ecc_amount = new Money(model.Payment.SubTotalAmount);
                pmt.ecc_Account = account.ToEntityReference();
                pmt.ecc_paymenttype = new OptionSetValue((int)ecc_paymentecc_paymenttype.MembershipSignup);
                pmt.ecc_cardtype = cardtypeId == 0 ? null : new OptionSetValue(cardtypeId);
                pmt.ecc_description = "Membership signup";

                if (model.PayByCreditCard)
                {
                    pmt.ecc_FormofPayment = new OptionSetValue((int)ecc_paymentecc_FormofPayment.CreditCard);
                    pmt.ecc_moneristransactionnumber = model.Payment.MonerisReferenceNum;
                    pmt.statuscode = new OptionSetValue((int)ecc_payment_statuscode.Paid);
                    pmt.ecc_cardtype = new OptionSetValue(Convert.ToInt32(model.Payment.Method));
                }
                else
                {
                    pmt.ecc_FormofPayment = new OptionSetValue((int)ecc_paymentecc_FormofPayment.Cheque);
                    pmt.statuscode = new OptionSetValue((int)ecc_payment_statuscode.Open);
                }
                DataContext.AddObject(pmt);
                if (!DataContext.IsAttached(pmt))
                {
                    DataContext.Attach(pmt);
                }
                DataContext.SaveChanges();
                foreach (var pd in model.Payment.Details)
                {
                    var pdr = new ecc_paymentdetail()
                    {
                        ecc_name = pd.Description,
                        ecc_unitamount = new Money(pd.Fee),
                        ecc_quantity = int.Parse(pd.Quantity),
                        ecc_GST = new Money(pd.TaxAmount),
                        ecc_payment = new EntityReference(ecc_payment.EntityLogicalName, pmt.ecc_paymentId.Value),
                        ecc_glcode = pd.GLCode != string.Empty ? new EntityReference(ecc_glcode.EntityLogicalName, Guid.Parse(pd.GLCode)) : null
                    };
                    DataContext.AddObject(pdr);
                }
                DataContext.SaveChanges();

                var returnUrl = Request.QueryString["returnurl"];
                if (!string.IsNullOrEmpty(returnUrl))
                {
                    return this.Redirect(returnUrl);
                }

                this.TempData["UserValidated"] = true;
                this.TempData["Message"] =
                    "Your Account has been created. Please check your email to complete the process.";

                SendCreateMembershipEmail(model, pmt.ecc_paymentId.Value, webMembership);
                SendCreateMembershipEmail(model, pmt.ecc_paymentId.Value, webMembership, true);
                //SendNewMemberEmail(model, webMembership);

                if (!Convert.ToBoolean(this.TempData["UserValidated"]))
                {
                    //error message, add custom error to viewstate model and return the page.
                    ModelState.AddModelError("CustomError", new Exception(this.TempData["Message"].ToString()));
                    return CurrentUmbracoPage();
                }
            }
            else
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors);
                return Redirect(currentUrl + "?status=err&refnumber=" + model.Payment.RefNo + "&emailaddr=" + model.GeneralContactEmail);
            }

            if (model.PayByCreditCard)
            {
                return Redirect(currentUrl + "?status=succ&refnumber=" + model.Payment.RefNo + "&emailaddr=" + model.GeneralContactEmail);
            }
            return Redirect(currentUrl + "?status=bycheck&emailaddr=" + model.GeneralContactEmail);
        }

        [HttpPost]
        [ActionName("EmailExists")]
        public ActionResult EmailExists(MemberLoginModel model)
        {
            bool accountExists = this.AccountExists(model.Username);
            return Json(accountExists, JsonRequestBehavior.AllowGet);
        }

        public MemberInfo GetMemberInfo(string email, Guid? accountId, bool reset = false)
        {
            var memberInfo = this.ReadMemberInfoFromCookie();
            if (accountId != null && (memberInfo.Email == string.Empty || reset))
            {
                var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
                var account = crmExtensions.GetAccountById(accountId.Value);
                var accountName = account != null ? account.Name : string.Empty;

                var status = crmExtensions.GetMembershipStatus(accountId.Value);

                string memberInfoString = string.Format("{0}λ{1}λ{2}λ{3}", accountName, status, accountId, email);

                var httpCookie = System.Web.HttpContext.Current.Response.Cookies["MemberInfo"];
                if (httpCookie != null)
                {
                    httpCookie.Value = memberInfoString;
                }
                else
                {
                    var cookieMemberStatus = new HttpCookie("MemberInfo") { Value = memberInfoString };
                    System.Web.HttpContext.Current.Response.Cookies.Add(cookieMemberStatus);
                }


                //memberInfoString = string.Format("{0},{1},{2},{3}", accountName, status, accountId, account.EMailAddress1);
                //httpCookie.Value = memberInfoString;

                memberInfo.Status = status;
                memberInfo.AccountName = accountName;
                memberInfo.AccountId = accountId == null ? Guid.Empty : accountId.Value;
                memberInfo.Email = email;
            }

            return memberInfo;
        }

        public MemberInfo GetMemberInfo()
        {
            var memberInfo = this.ReadMemberInfoFromCookie();
            if (memberInfo.Email == string.Empty)
            {
                var email = System.Web.HttpContext.Current.User.Identity.Name;

                if (email != "")
                {
                    var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
                    var account = crmExtensions.GetAccount(email);
                    var accountName = account != null ? account.Name : string.Empty;
                    var accountId = account != null ? account.AccountId : Guid.Empty;

                    string memberInfoString = string.Format("{0}λ{1}λ{2}λ{3}", accountName, string.Empty, accountId, email);

                    var httpCookie = System.Web.HttpContext.Current.Response.Cookies["MemberInfo"];
                    if (httpCookie != null)
                    {
                        httpCookie.Value = memberInfoString;
                    }
                    else
                    {
                        var cookieMemberStatus = new HttpCookie("MemberInfo") { Value = memberInfoString };
                        System.Web.HttpContext.Current.Response.Cookies.Add(cookieMemberStatus);
                    }

                    var status = crmExtensions.GetMembershipStatus(accountId.Value);

                    memberInfoString = string.Format("{0},{1},{2},{3}", accountName, status, accountId, email);
                    httpCookie.Value = memberInfoString;

                    memberInfo.Status = status;
                    memberInfo.AccountName = accountName;
                    memberInfo.AccountId = accountId ?? Guid.Empty;
                    memberInfo.Email = email;
                }
            }

            return memberInfo;
        }

        //public MemberInfo GetMemberInfo(string email = "", bool reset = false)
        //{
        //    var memberInfo = this.ReadMemberInfo();
        //    if (memberInfo.Email == string.Empty || reset)
        //    {
        //        if (email == "")
        //        {
        //            email = System.Web.HttpContext.Current.User.Identity.Name;
        //        }
        //        if (email != "")
        //        {
        //            var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
        //            var account = crmExtensions.GetAccount(email);
        //            var accountName = account != null ? account.Name : string.Empty;
        //            var accountId = account != null ? account.AccountId : Guid.Empty;

        //            string memberInfoString = string.Format("{0}λ{1}λ{2}λ{3}", accountName, string.Empty, accountId, email);

        //            var httpCookie = System.Web.HttpContext.Current.Response.Cookies["MemberInfo"];
        //            if (httpCookie != null)
        //            {
        //                httpCookie.Value = memberInfoString;
        //            }
        //            else
        //            {
        //                var cookieMemberStatus = new HttpCookie("MemberInfo") { Value = memberInfoString };
        //                System.Web.HttpContext.Current.Response.Cookies.Add(cookieMemberStatus);
        //            }

        //            var status = crmExtensions.GetMembershipStatus(email);

        //            memberInfoString = string.Format("{0},{1},{2},{3}", accountName, status, accountId, email);
        //            httpCookie.Value = memberInfoString;

        //            memberInfo.Status = status;
        //            memberInfo.AccountName = accountName;
        //            memberInfo.AccountId = accountId ?? Guid.Empty;
        //            memberInfo.Email = email;
        //        }
        //    }

        //    return memberInfo;
        //}

        public MemberInfo ReadMemberInfoFromCookie()
        {
            var memberStatus = new MemberInfo { AccountName = string.Empty, Status = string.Empty, AccountId = Guid.Empty, Email = string.Empty };

            if (System.Web.HttpContext.Current.Request.Cookies["MemberInfo"] != null
                && !string.IsNullOrEmpty(System.Web.HttpContext.Current.Request.Cookies["MemberInfo"].Value))
            {
                var displayStatus = System.Web.HttpContext.Current.Request.Cookies["MemberInfo"].Value;

                var memStatus = displayStatus.Split('λ').ToList();
                if (memStatus.Count >= 1)
                {
                    memberStatus.AccountName = memStatus[0] ?? "";
                }
                if (memStatus.Count >= 2)
                {
                    memberStatus.Status = memStatus[1] ?? "";
                }
                if (memStatus.Count >= 3)
                {
                    memberStatus.AccountId = memStatus[2] != null ? Guid.Parse(memStatus[2]) : Guid.Empty;
                }
                if (memStatus.Count >= 4)
                {
                    memberStatus.Email = memStatus[3] ?? "";
                }
            }
            return memberStatus;
        }

        public string RedirectUrl()
        {
            var returnRawUrl = Request.RawUrl;
            var returnUrl = string.Empty;
            if (Request.QueryString["returnurl"] != null && Request.QueryString["returnurl"] != string.Empty)
            {
                returnUrl = Request.QueryString["returnurl"];
            }
            else if (Url.IsLocalUrl(returnRawUrl) && returnRawUrl.Length > 1 && returnRawUrl.StartsWith("/")
                && !returnRawUrl.StartsWith("//") && !returnRawUrl.StartsWith("/\\"))
            {
                returnUrl = returnRawUrl;
            }

            if (returnUrl.StartsWith("/umbraco/"))
            {
                returnUrl = string.Empty;
            }

            return returnUrl;
        }

        public void CustomSignout()
        {
            var httpCookie = System.Web.HttpContext.Current.Response.Cookies["MemberInfo"];
            if (httpCookie != null)
            {
                httpCookie.Value = null;
                var expiredCookie = new HttpCookie(httpCookie.Name) { Expires = DateTime.Now.AddMinutes(-1) };
                System.Web.HttpContext.Current.Response.Cookies.Add(expiredCookie);
            }
            //System.Web.HttpContext.Current.Session.Remove("UserInfo");
            System.Web.HttpContext.Current.Session.RemoveAll();

            FormsAuthentication.SignOut();
            System.Web.HttpContext.Current.User =
                new GenericPrincipal(new GenericIdentity(string.Empty), null);
        }

        private string GetGLCode(string codeName)
        {
            var code = this.DataContext.ecc_glcodeSet.SingleOrDefault(c => c.ecc_name == codeName);
            if (code != null)
            { return code.Id.ToString(); }
            else { return string.Empty; }
        }

        [HttpPost]
        public ActionResult SendContactEmail(ContactEmailModel emailModel)
        {
            var captchaResponse = Request["g-Recaptcha-Response"];
            bool IsCaptchaValid = ValidateCaptcha(captchaResponse);

            var emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = string.Empty };
            if (IsCaptchaValid)
            {
                var account = (new CacheItemController()).CachedBusinessDirectory.AccountList.SingleOrDefault(i => i.Id == emailModel.AccountId);
                try
                {
                    var emailSubject = emailModel.Subject;
                    var emailMessage = "From: " + emailModel.YourName + "<br /><br />";
                    if (!string.IsNullOrEmpty(emailModel.YourEmail))
                    {
                        emailMessage += string.Format("Email: {0}<br />", emailModel.YourEmail);
                    }
                    if (!string.IsNullOrEmpty(emailModel.PhoneNumber))
                    {
                        emailMessage += string.Format("Phone Number: {0}<br />", emailModel.PhoneNumber);
                    }

                    emailMessage += "<br />" + emailModel.Message;
                    //TODO: set emailTO
                    emailStatus = Email.SendEmail(
                        new EntityReference(Account.EntityLogicalName, emailModel.AccountId),
                        emailSubject,
                        emailMessage,
                        null,
                        null,
                        null,
                        emailTo: account.ContactEmail,
                        emailType: Emailecc_emailtype.MembertoMember);
                }
                catch (Exception ex)
                {
                    emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = ex.ToString() };
                }
            }
            else
            {
                emailStatus.ErrorMessage = "Invalid Captcha";
            }
            return Json(emailStatus);
        }

        private bool ValidateCaptcha(string captchaResponse)
        {
            var client = new System.Net.WebClient();

            string PrivateKey = ConfigurationManager.AppSettings["RecaptchaSecretKey"];

            var GoogleReply = client.DownloadString(string.Format("https://www.google.com/recaptcha/api/siteverify?secret={0}&response={1}", PrivateKey, captchaResponse));

            var validationResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<ReCaptchaValidation>(GoogleReply);

            return validationResponse.Success;
        }

        #endregion

        #region Status Codes

        public Email.EmailStatus SendCreateMembershipEmail(AccountModel account, Guid paymentId, appl_webmembership webMembershipModel = null, bool admin = false, int overrideTemplateId = 0)
        {
            var userEmail = account.Email;
            var currentNode = Node.GetCurrent();
            var notificationTemplateId = currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString()) != string.Empty
            ? int.Parse(currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString())) : 0;
            if (notificationTemplateId == 0)
            {
                notificationTemplateId = int.Parse(ConfigurationManager.AppSettings["accountCreateTemplateId"]);
            }
            if (overrideTemplateId > 0)
            {
                notificationTemplateId = overrideTemplateId;
            }

            var emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = string.Empty };
            if (notificationTemplateId > 0)
            {
                var notificationNode = new Node(notificationTemplateId);
                var emailSubject = notificationNode.GetNodeValue(DocumentFields.emailSubject.ToString());
                var emailTo = notificationNode.GetNodeValue(DocumentFields.emailAdmin.ToString());
                //var emailFrom = notificationNode.GetNodeValue(DocumentFields.emailFrom.ToString());
                var emailMessage = notificationNode.GetNodeValue(DocumentFields.emailMessage.ToString());
                var emailBcc = string.Empty;
                const string EmailTemplate = "/Email/StandardTemplate.html";

                if (!admin)
                {
                    //client email
                    emailTo = account.GeneralContactEmail;
                }
                else
                {
                    emailBcc = notificationNode.GetNodeValue(DocumentFields.emailBcc.ToString());
                }

                if (webMembershipModel == null)
                {
                    webMembershipModel = (from webMembership in DataContext.appl_webmembershipSet
                                          join contact in DataContext.ContactSet on webMembership.EmailAddress equals contact.EMailAddress1
                                          where webMembership.appl_name == userEmail //&& webMembership.statecode == appl_webmembershipState.Active
                                          select webMembership).SingleOrDefault();
                }

                if (webMembershipModel != null)
                {
                    if (emailTo != string.Empty)
                    {
                        var replacements = DictionaryReplacement.MembershipRegistration(
                            this.service,
                            account);

                        // Add invoice to email contents
                        var invoiceData = GetInvoiceModel(paymentId);
                        var invoiceText = RenderInvoice(invoiceData);
                        if (!account.PayByCreditCard)
                        {
                            emailMessage
                                += "<br/> <span style='font-size: 14pt;'>If your invoice is not displayed properly, you can view it online <a href=\"" + Request.Url.Host + "/umbraco/surface/MembershipSurface/DisplayInvoice?paymentId=" + paymentId + "\">Click Here</a>  </span><br/>"
                                + invoiceText;

                        }
                        else {
                            emailMessage
                                += "<br/> <span style='font-size: 14pt;'>If your invoice is not displayed properly, you can view it online <a href=\"" + Request.Url.Host + "/member-profile/my-invoices/display-invoice?invoiceId=" + paymentId + "\">by logging into to your Portal</a> </span> <br/>"
                                + invoiceText;
                        }

                        emailStatus = Email.SendEmail(
                            new EntityReference(Account.EntityLogicalName, account.Id),
                            emailSubject,
                            emailMessage,
                            EmailTemplate,
                            replacements,
                            new EntityReference(Account.EntityLogicalName, account.Id),
                            null,
                            emailBcc);
                    }
                }
                else
                {
                    emailStatus.EmailSent = false;
                    emailStatus.ErrorMessage = "Your account could not be found in the system";
                }
            }
            return emailStatus;
        }

        //public Email.EmailStatus SendNewMemberEmail(AccountModel account, appl_webmembership webMembershipModel = null, bool admin = false, int overrideTemplateId = 0)
        //{
        //    var userEmail = account.Email;
        //    var currentNode = Node.GetCurrent();
        //    var notificationTemplateId = currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString()) != string.Empty
        //    ? int.Parse(currentNode.GetNodeValue(DocumentFields.notificationTemplate.ToString())) : 0;
        //    if (notificationTemplateId == 0)
        //    {
        //        notificationTemplateId = int.Parse(ConfigurationManager.AppSettings["newMemberTemplateId"]);
        //    }
        //    if (overrideTemplateId > 0)
        //    {
        //        notificationTemplateId = overrideTemplateId;
        //    }

        //    var emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = string.Empty };
        //    if (notificationTemplateId > 0)
        //    {
        //        var notificationNode = new Node(notificationTemplateId);
        //        var emailSubject = notificationNode.GetNodeValue(DocumentFields.emailSubject.ToString());
        //        var emailTo = notificationNode.GetNodeValue(DocumentFields.emailAdmin.ToString());
        //        //var emailFrom = notificationNode.GetNodeValue(DocumentFields.emailFrom.ToString());
        //        var emailMessage = notificationNode.GetNodeValue(DocumentFields.emailMessage.ToString());
        //        var emailBcc = string.Empty;
        //        const string EmailTemplate = "/Email/StandardTemplate.html";

        //        if (!admin)
        //        {
        //            //client email
        //            emailTo = account.GeneralContactEmail;
        //        }
        //        else
        //        {
        //            emailBcc = notificationNode.GetNodeValue(DocumentFields.emailBcc.ToString());
        //        }

        //        if (webMembershipModel == null)
        //        {
        //            webMembershipModel = (from webMembership in DataContext.appl_webmembershipSet
        //                                  join contact in DataContext.ContactSet on webMembership.EmailAddress equals contact.EMailAddress1
        //                                  where webMembership.appl_name == userEmail //&& webMembership.statecode == appl_webmembershipState.Active
        //                                  select webMembership).SingleOrDefault();
        //        }

        //        if (webMembershipModel != null)
        //        {
        //            if (emailTo != string.Empty)
        //            {
        //                var replacements = DictionaryReplacement.AccountCreate(
        //                    this.service,
        //                    account);

        //                // Add invoice to email contents
        //                var invoiceData = GetInvoiceModel(paymentId);
        //                var invoiceText = RenderInvoice(invoiceData);
        //                if (!account.PayByCreditCard)
        //                {
        //                    emailMessage
        //                        += "<br/> <span style='font-size: 14pt;'>If your invoice is not displayed properly, you can view it online <a href=\"" + Request.Url.Host + "/umbraco/surface/MembershipSurface/DisplayInvoice?paymentId=" + paymentId + "\">Click Here</a>  </span><br/>"
        //                        + invoiceText;

        //                }
        //                else
        //                {
        //                    emailMessage
        //                        += "<br/> <span style='font-size: 14pt;'>If your invoice is not displayed properly, you can view it online <a href=\"" + Request.Url.Host + "/member-profile/my-invoices/display-invoice?invoiceId=" + paymentId + "\">by login to your Portal</a> </span> <br/>"
        //                        + invoiceText;
        //                }

        //                emailStatus = Email.SendEmail(
        //                    new EntityReference(Account.EntityLogicalName, account.Id),
        //                    emailSubject,
        //                    emailMessage,
        //                    EmailTemplate,
        //                    replacements,
        //                    new EntityReference(Account.EntityLogicalName, account.Id),
        //                    null,
        //                    emailBcc);
        //            }
        //        }
        //        else
        //        {
        //            emailStatus.EmailSent = false;
        //            emailStatus.ErrorMessage = "Your account could not be found in the system";
        //        }
        //    }
        //    return emailStatus;
        //}

        #endregion

        #region Invoice

        [HttpGet]
        public ViewResult DisplayInvoice(Guid paymentId)
        {
            var model = GetInvoiceModel(paymentId);
            return View("Invoice", model);
        }

        public InvoiceReportModel GetInvoiceModel(Guid paymentId)
        {
            var paymentInfo = DataContext.ecc_paymentSet.SingleOrDefault(p => p.ecc_paymentId == paymentId);
            if (paymentInfo == null) return null;

            var accountInfo = DataContext.AccountSet.SingleOrDefault(a => a.AccountId == paymentInfo.ecc_Account.Id);
            Contact contactInfo = null;
            if (paymentInfo.ecc_contact != null)
            {
                contactInfo = DataContext.ContactSet.SingleOrDefault(a => a.ContactId == paymentInfo.ecc_contact.Id);
            }
            ecc_registration registrationInfo = null;
            if (paymentInfo.ecc_Registration != null)
            {
                registrationInfo = DataContext.ecc_registrationSet.SingleOrDefault(a => a.ecc_registrationId == paymentInfo.ecc_Registration.Id);
            }
            var details = DataContext.ecc_paymentdetailSet.Where(p => p.ecc_payment.Id == paymentId).ToList();
            var detailList = new List<InvoiceItemModel>();
            if (details.Count() > 0)
            {
                detailList = details.Select(p => new InvoiceItemModel()
                {
                    Name = p.ecc_name,
                    Amount = p.ecc_Amount.Value,
                    Rate = p.ecc_unitamount.Value,
                    Quantity = p.ecc_quantity != null ? p.ecc_quantity.Value : 0
                }).ToList();
            }

            var model = new InvoiceReportModel()
            {
                AccountID = accountInfo.AccountId.Value,
                AccountName = accountInfo.Name,
                Address = accountInfo.Address1_Line1,
                City = accountInfo.ecc_city.Name,
                Province = accountInfo.ecc_provincestate.Name,
                PostalCode = accountInfo.Address1_PostalCode.ToUpper(),
                GST = paymentInfo.ecc_gst.Value,
                DueDate = paymentInfo.ecc_duedate != null ? paymentInfo.ecc_duedate.Value : paymentInfo.CreatedOn.Value.AddDays(30),
                //InvoiceDate = DateTime.Now,
                InvoiceDate = paymentInfo.CreatedOn.Value,
                InvoiceItems = detailList,
                InvoiceNumber = paymentInfo.ecc_number,
                MemberID = accountInfo.AccountNumber,
                Title = "Invoice",
                Total = paymentInfo.ecc_amount.Value + paymentInfo.ecc_gst.Value,
                AmountPaid = paymentInfo.statuscode.Value == (int)ecc_payment_statuscode.Paid ? paymentInfo.ecc_amount.Value + paymentInfo.ecc_gst.Value : 0,
                BalanceDue = paymentInfo.statuscode.Value == (int)ecc_payment_statuscode.Paid ? 0 : paymentInfo.ecc_amount.Value + paymentInfo.ecc_gst.Value
            };

            if (model.Total < 0)
            {
                model.Title = "Credit Note";
            }

            if (registrationInfo != null)
            {
                model.AccountName = registrationInfo.ecc_firstname + " " + registrationInfo.ecc_lastname;
                model.ContactName = registrationInfo.ecc_firstname + " " + registrationInfo.ecc_lastname;
                model.Address = registrationInfo.ecc_address1;
                model.City = registrationInfo.ecc_city.Name;
                model.Province = registrationInfo.ecc_province.Name;
                if (registrationInfo.ecc_postalcode != null)
                {
                    model.PostalCode = registrationInfo.ecc_postalcode.ToUpper();
                }
                else
                {
                    model.PostalCode = "";
                }
            }
            else if (contactInfo != null)
            {
                model.ContactName = contactInfo.FullName;
                model.Address = contactInfo.Address1_Line1;
                model.City = contactInfo.ecc_City.Name;
                model.Province = contactInfo.ecc_ProvinceState.Name;
                if (contactInfo.Address1_PostalCode != null)
                {
                    model.PostalCode = contactInfo.Address1_PostalCode.ToUpper();
                }
                else
                {
                    model.PostalCode = "";
                }
            }

            return model;
        }

        public string RenderInvoice(InvoiceReportModel model)
        {
            var stringResult = string.Empty;

            // Apply model to view and render
            using (var sw = new StringWriter())
            {
                var ctx = new HttpContextWrapper(System.Web.HttpContext.Current);
                var routeData = RouteTable.Routes.GetRouteData(this.UmbracoContext.HttpContext);
                var ctrlContext = new ControllerContext(new RequestContext(ctx, routeData), new EventController());
                var viewResult = ViewEngines.Engines.FindPartialView(ctrlContext, "Invoice");
                var viewContext = new ViewContext(ctrlContext, viewResult.View, new ViewDataDictionary(model), new TempDataDictionary(), sw);
                viewResult.View.Render(viewContext, sw);
                stringResult = sw.GetStringBuilder().ToString();
            }

            return stringResult;
        }
        #endregion

        #region Status Codes
        private static string ErrorCodeToString(MembershipCreateStatus createStatus)
        {
            // See http://go.microsoft.com/fwlink/?LinkID=177550 for
            // a full list of status codes.
            switch (createStatus)
            {
                case MembershipCreateStatus.DuplicateUserName:
                    return "User name already exists. Please enter a different user name.";

                case MembershipCreateStatus.DuplicateEmail:
                    return "A user name for that e-mail address already exists. Please enter a different e-mail address.";

                case MembershipCreateStatus.InvalidPassword:
                    return "The password provided is invalid. Please enter a valid password value.";

                case MembershipCreateStatus.InvalidEmail:
                    return "The e-mail address provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidAnswer:
                    return "The password retrieval answer provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidQuestion:
                    return "The password retrieval question provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.InvalidUserName:
                    return "The user name provided is invalid. Please check the value and try again.";

                case MembershipCreateStatus.ProviderError:
                    return "The authentication provider returned an error. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                case MembershipCreateStatus.UserRejected:
                    return "The user creation request has been canceled. Please verify your entry and try again. If the problem persists, please contact your system administrator.";

                default:
                    return "An unknown error occurred. Please verify your entry and try again. If the problem persists, please contact your system administrator.";
            }
        }

        #endregion

        #region Coupons

        public List<AccountModel> GetCachedAccounts()
        {
            return cache.CachedBusinessDirectory.AccountList.ToList();
        }

        public List<CouponModel> GetCachedCoupons()
        {
            if (cache.CachedCouponList != null)
            {
                return cache.CachedCouponList.CouponsList.ToList();
            }
            return null;
        }

        public List<CouponModel> GetCoupons()
        {
            var crmCoupons = DataContext.ecc_couponSet;
            List<CouponModel> coupons = new List<CouponModel>();
            var cachedAccounts = GetCachedAccounts();

            foreach (var coupon in crmCoupons)
            {
                if (coupon != null)
                {
                    var couponType = "";
                    if (coupon.ecc_CouponType != null && coupon.ecc_CouponType.Value != null)
                    {
                        couponType = ((ecc_couponecc_CouponType)coupon.ecc_CouponType.Value).ToString();
                    }
                    decimal price = 0;
                    if (coupon.ecc_Price != null)
                    {
                        price = coupon.ecc_Price.Value;
                    }
                    var acct = coupon.ecc_Account != null
                        ? cachedAccounts.SingleOrDefault(a => a.Id == coupon.ecc_Account.Id)
                        : null;
                    if (acct != null)
                    {
                        coupons.Add(new CouponModel
                        {
                            CouponId = coupon.ecc_couponId,
                            AccountId = coupon.ecc_Account != null ? coupon.ecc_Account.Id : Guid.Empty,
                            LogoUrl = acct.CompanyLogoUrl,
                            ContactEmail = coupon.ecc_EmailContact,
                            ContactPhone = coupon.ecc_ContactPhone,
                            ReferenceCode = coupon.ecc_ReferenceCode,
                            Description = coupon.ecc_Description,
                            DisplayName = coupon.ecc_DisplayName,
                            ExpiryDate = coupon.ecc_ExpiryDate,
                            UrlLink = coupon.ecc_URLLink,
                            Name = coupon.ecc_name,
                            Price = price,
                            Title = coupon.ecc_Title,
                            CouponType = couponType
                        });
                    }
                }
            }
            return coupons;
        }

        [HttpPost]
        public ActionResult SubmitNewCoupon(CouponModel model, string couponId)
        {
            if (!ModelState.IsValid)
            {
                return CurrentUmbracoPage();
            }

            //Check if user is logged in
            if (IsUserLoggedIn())
            {
                string email = System.Web.HttpContext.Current.User.Identity.Name;
                var crmExtensions = new CrmExtensionsController(this.service, this.DataContext);
                var account = crmExtensions.GetAccount(email);
                var accountReference = new EntityReference
                {
                    Id = account.AccountId ?? account.Id,
                    Name = account.Name
                };

                var crmCoupon = new ecc_coupon
                {
                    ecc_Account = accountReference,
                    ecc_ContactPhone = model.ContactPhone,
                    ecc_Description = model.Description,
                    ecc_DisplayName = model.DisplayName,
                    ecc_ExpiryDate = model.ExpiryDate,
                    ecc_Title = model.Title,
                    ecc_Price = new Money(model.Price),
                    ecc_URLLink = model.UrlLink,
                    ecc_EmailContact = model.ContactEmail,
                    ecc_ReferenceCode = model.ReferenceCode
                };

                if (model.CouponType != "")
                {
                    crmCoupon.ecc_CouponType =
                        new OptionSetValue((int)Enum.Parse(typeof(ecc_couponecc_CouponType), model.CouponType));
                }

                DataContext.AddObject(crmCoupon);
                DataContext.SaveChanges();
                if (!DataContext.IsAttached(crmCoupon))
                {
                    DataContext.Attach(crmCoupon);
                }

            }
            else
            {
                throw new AuthenticationException("user not logged in");
            }
            var currentNode = Node.GetCurrent();
            return Redirect(currentNode.Url + "?status=succ");
        }

        #endregion

        #region CacheUpdate

        public void UpdateAccountCache(AccountModel updatedAccount)
        {
            var cachedAccount = cache.CachedBusinessDirectory.AccountList.SingleOrDefault(i => i.Id == updatedAccount.Id);
            if (cachedAccount != null)
            {
                //update account
                cache.CachedBusinessDirectory.AccountList.Remove(cachedAccount);
                cache.CachedBusinessDirectory.AccountList.Add(updatedAccount);
                //cachedAccount = updatedAccount;
            }
            else
            {
                //create account
                cache.CachedBusinessDirectory.AccountList.Add(updatedAccount);
            }

            //save cache in SQL
            var data = SerializeHelper.BinarySerializeObject(cache.CachedBusinessDirectory);
            SqlHelper.SaveCacheData(CacheNames.CachedBusinessDirectory.ToString(), data);
        }

        #endregion
    }
}
