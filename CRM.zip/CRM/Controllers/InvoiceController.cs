﻿using Moneris.Data.Models;
using ECC.Web.Controllers;
using ECC.Web.Data.Crm;
//using ECC.Web.Email;
using System.IO;
using ECC.Web.Models;
using Microsoft.Xrm.Sdk;
using System;
using System.Web;
using System.Configuration;
using System.Linq;
using System.Drawing;
using System.Drawing.Imaging;
using System.Threading;
using System.Web.Mvc;
using System.Web.Routing;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using ECC.Web.Helpers;
using System.Collections.Generic;
using Microsoft.Crm.Sdk.Messages;
using ECC.Web.ApiControllers;
using MVCCrm.CrmCore;
using Umbraco.Core.Logging;
using log4net;
using PdfSharp.Pdf;
using PdfSharp.Drawing;
using umbraco;

namespace ECC.Web.SurfaceControllers
{
    using ECC.Web.Data.Crm;
    using ECC.Web.Extensions;

    using Email = Iomer.Extensions.Email.EmailManager;
    public class InvoiceController : CrmController
    {
        private CacheItemController cache;

        public InvoiceController()
        {
            cache=new CacheItemController(this.service, this.DataContext);
        }

        public MonerisResponse OnlinePayment(PaymentModel model, CacheItemController.CachedAccountModel currentUser, string invoiceNumber)
        {
            var transactionController = new MonerisController();
            var expiryDate = model.ExpiryDateYear.Trim().Substring(2) + model.ExpiryDateMonth.Trim();

            var payerName = model.NameOnCard.Replace(" ", "");
            var monerisReferenceId = string.Format("ECC_Invoice{0}_{1}{2}", invoiceNumber, payerName, DateTime.Now.Ticks);
            model.RefNo = monerisReferenceId;

            var fee = String.Format("{0:0.00}", model.TotalAmount);

            //var currentUser = cache.CachedAccountInfo;
            if (String.IsNullOrEmpty(currentUser.Account.ecc_legalname))//user is not a company
            {
                var firstName = "missingData";
                var lastName = "missingData";
                if (!string.IsNullOrEmpty(currentUser.Account.ecc_firstname))
                    firstName = currentUser.Account.ecc_firstname;
                if(!string.IsNullOrEmpty(currentUser.Account.ecc_lastname)) 
                    lastName = currentUser.Account.ecc_lastname;

                transactionController.SetUserInfo(
                    firstName,
                    lastName,
                    currentUser.Account.Name,
                    currentUser.Account.Address1_Line1 + "/ " + currentUser.Account.Address1_Line2,
                    currentUser.Account.ecc_city.Name,
                    currentUser.Account.ecc_provincestate.Name,
                    currentUser.Account.Address1_PostalCode, currentUser.Account.Address1_Country, currentUser.Account.Telephone1,
                    currentUser.Account.Fax,currentUser.Account.EMailAddress1);

            }
            else
            {

                var contactList = cache.CachedUserContacts.ContactList;
                    //CachedContacts.ContactList.Where(
                    //    c => c.ecc_Account.Id == currentUser.Account.Id
                    //    && c.ecc_MainContact.Value);

                var paymentContact = contactList.FirstOrDefault(bc => bc.ecc_ContactType.Equals(new OptionSetValue((int)Contactecc_ContactType.Billing))) ??
                                     contactList.First();
                transactionController.SetUserInfo(
                    paymentContact.FirstName,
                    paymentContact.LastName,
                    currentUser.Account.Name,
                    currentUser.Account.Address1_Line1 + "/ " + currentUser.Account.Address1_Line2,
                    currentUser.Account.ecc_city.Name,
                    currentUser.Account.ecc_provincestate.Name,
                    currentUser.Account.Address1_PostalCode, currentUser.Account.Address1_Country, paymentContact.Telephone1,
                    currentUser.Account.Fax, paymentContact.EMailAddress1);
            }

            transactionController.SetNewTransaction(monerisReferenceId, fee, model.CreditCardNumber,
                model.NameOnCard, expiryDate, model.SecurityCode, "0", "0", "0", "0", "MemberRegistration", null);
            var response = transactionController.ProcessMonerisTransaction();

            model.MonerisReferenceNum = response.ReferenceNumber;

            return response;

        }


        [HttpPost]
        public ActionResult PayToInvoice(PaymentModel model)
        {

            var currentUrl = this.Request.UrlReferrer.AbsolutePath;
            
            
            if (ModelState.IsValid)
            {
                var currentPayment = DataContext.ecc_paymentSet.SingleOrDefault(p => p.ecc_paymentId == model.ProductId);//(i => i.paym == model.ProductId);
                var cachedPayment  = cache.CachedUserInvoices.UserInvoiceList.FirstOrDefault(i => i.PaymentInvoice.Id == model.ProductId);
                if (currentPayment != null &&
                    !Equals(currentPayment.statuscode, new OptionSetValue((int) ecc_payment_statuscode.Paid)))
                {
                    var currentUser = cache.CachedAccountInfo;
                    var result = OnlinePayment(model, currentUser, currentPayment.ecc_number);
                    switch (result.ResponseStatus)
                    {
                        case PaymentStatus.Approved:
                            currentPayment.ecc_FormofPayment =
                                new OptionSetValue((int) ecc_paymentecc_FormofPayment.CreditCard);
                            currentPayment.statuscode = new OptionSetValue((int) ecc_payment_statuscode.Paid);
                            currentPayment.ecc_moneristransactionnumber = result.ReferenceNumber;
                            DataContext.UpdateObject(currentPayment);
                            DataContext.SaveChanges();
                            cachedPayment.PaymentInvoice.statuscode =
                                new OptionSetValue((int) ecc_payment_statuscode.Paid); //update cached invoice status

                            return
                                Redirect(currentUrl + "?status=succ&refnumber=" + model.RefNo);
                        case PaymentStatus.Declined:
                            return
                                this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "declined",
                                    result.ResponseMessage));
                        //return Redirect(currentUrl + "?status=declined");
                        case PaymentStatus.Incomplete:
                            return
                                this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "incomplete",
                                    result.ResponseMessage));
                        //return Redirect(currentUrl + "?status=incomplete");
                        case PaymentStatus.Error:
                            return
                                this.Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "error",
                                    result.ResponseMessage));
                        //return Redirect(currentUrl + "?status=error");
                    }
                }
                else if (Equals(currentPayment.statuscode, new OptionSetValue((int)ecc_payment_statuscode.Paid)))
                {
                    return
                        Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "paid", "invoice already paid"));
                }

                return
                    Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "notfound", "invoice not found"));
            }

            //validation error?
            var errors = ModelState.Values.SelectMany(v => v.Errors);
            return Redirect(string.Format("{0}?status={1}&message={2}", currentUrl, "error", errors.First().ToString()));

        }



        private List<Account> GetAccountsDueIn(int days, bool isTesting) {
            var endDay = DateTime.Now.Date.AddDays(days).ToMontainDateTime();
            var membershipModel = (from acc in DataContext.AccountSet//.CreateQuery<Account>()
                                   where
                                   acc.StateCode == AccountState.Active
                                   && acc.StatusCode.Value == (int)account_statuscode.Active
                                   && (acc.ecc_isgroupinsurance==null || acc.ecc_isgroupinsurance.Value == false)
                                   && (acc.ecc_ispap==null || acc.ecc_ispap.Value==false)
                                   && acc.ecc_membershipenddate != null
                                   && acc.ecc_membershipenddate.Value >= endDay
                                   && acc.ecc_membershipenddate.Value <endDay.AddDays(1)
                                   select acc).ToList();
            if (isTesting)
            {
                membershipModel = membershipModel.Where(a => a.Name.Contains("iomertest")).ToList();
            }

            return membershipModel;
        }

        private ecc_payment GenerateRenwalInvoice(Account account) {
            var newInvoice = new PaymentModel();

            var configurationSet = DataContext.ecc_configurationSet.FirstOrDefault();
            var AccFee = configurationSet.ecc_ACCFee.Value;
            var BusinessTypeFee = configurationSet.ecc_businesstypefee.Value;
            
            var existingBusinessTypeRelation = DataContext.ecc_account_ecc_businesstypeSet.Where(a => a.accountid == account.Id).ToList();
            var BusinessTypeAdditionalCount = existingBusinessTypeRelation == null ? 0 : existingBusinessTypeRelation.Count() - 1;
            if (BusinessTypeAdditionalCount < 0) BusinessTypeAdditionalCount = 0;

            var numEmployee = (account.ecc_NumberOfFullTimeEmployees ?? 0M) + ((account.ecc_NumberOfPartTimeEmployees ?? 0) / 3);
            var annualMembershipInvestment = 0M;
            numEmployee = Math.Round(numEmployee);
            if (numEmployee <1)
            {
                numEmployee = 1;
            }
            if (numEmployee <= 1000)
            {               
                var annualFee = cache.CachedMemberShipRenewFeeListCurrentYear.AnualMemberShipFeeList.FirstOrDefault(i => (numEmployee <= i.Max && numEmployee >= i.Min)).Price;
                annualMembershipInvestment += annualFee;
            }
            else
            {
                var overFee = (numEmployee - 1000) * configurationSet.ecc_Over1000employeesfee.Value;
                var annualFee = cache.CachedMemberShipRenewFeeListCurrentYear.AnualMemberShipFeeList.FirstOrDefault(i => i.Max > 999).Price;
                annualMembershipInvestment += annualFee + overFee;
            }

            // Total Fees
            newInvoice.SubTotalAmount = annualMembershipInvestment +
                AccFee +
                BusinessTypeFee * BusinessTypeAdditionalCount;

            //newInvoice.TotalTaxAmount = newInvoice.SubTotalAmount * newInvoice.GstRate;
            //newInvoice.TotalAmount = newInvoice.SubTotalAmount + newInvoice.TotalTaxAmount;

            //var isGstExempt = account.ecc_isgstexempt ?? false;

            string GLCode_Membership = "Membership Revenue";
            newInvoice.Details.Add(new PaymentDetailModel()
            {
                Description = "Membership Renewal Fee",
                Fee = annualMembershipInvestment,
                Quantity = "1",
                //TaxAmount = isGstExempt ? 0m : annualMembershipInvestment * newInvoice.GstRate,
                GLCode = GetGLCode(GLCode_Membership)
            });

            string GLCode_ACofCFee = "AC of C Affiliation Revenue Fee";
            newInvoice.Details.Add(new PaymentDetailModel()
            {
                Description = "Alberta Chamber of Commerce Affiliation Fee",
                Fee = AccFee,
                Quantity = "1",
                //TaxAmount = 0,
                GLCode = GetGLCode(GLCode_ACofCFee)
            });

            if (BusinessTypeAdditionalCount > 0)
            {
                newInvoice.Details.Add(
                    new PaymentDetailModel()
                    {
                        Description = BusinessTypeAdditionalCount + " additional business directory categories",
                        Fee = BusinessTypeFee,
                        Quantity = BusinessTypeAdditionalCount.ToString(),
                        GLCode = GetGLCode(GLCode_Membership)
                    }
                );
            }

            //create crm payment(invoice) record
            var crmInvoice = new ecc_payment();

            crmInvoice.ecc_IsGI = false;
            crmInvoice.ecc_Account = account.ToEntityReference();
            crmInvoice.ecc_paymenttype = new OptionSetValue((int)ecc_paymentecc_paymenttype.MembershipRenewal);
            crmInvoice.ecc_cardtype = null;
            crmInvoice.ecc_description = "Membership Renewal Fee";
            crmInvoice.ecc_duedate = account.ecc_membershipenddate;

            DataContext.AddObject(crmInvoice);
            if (!DataContext.IsAttached(crmInvoice))
            {
                DataContext.Attach(crmInvoice);
            }
            DataContext.SaveChanges();

            //create and save invoice details
            foreach (var pd in newInvoice.Details)
            {
                var pdr = new ecc_paymentdetail()
                {
                    ecc_name = pd.Description,
                    ecc_unitamount = new Money(pd.Fee),
                    ecc_quantity = int.Parse(pd.Quantity),
                    //ecc_GST = new Money(isGstExempt?0 : pd.TaxAmount),
                    ecc_payment = new EntityReference(ecc_payment.EntityLogicalName, crmInvoice.ecc_paymentId.Value),
                    ecc_glcode = pd.GLCode != string.Empty ? new EntityReference(ecc_glcode.EntityLogicalName, Guid.Parse(pd.GLCode)) : null
                };
                DataContext.AddObject(pdr);
            }
            DataContext.SaveChanges();

            return crmInvoice;
        }


        private string GetGLCode(string codeName)
        {
            var code = this.DataContext.ecc_glcodeSet.SingleOrDefault(c => c.ecc_name == codeName);
            if (code != null)
            { return code.Id.ToString(); }
            else { return string.Empty; }
        }

        public System.Drawing.Image byteArrayToImage(byte[] byteArrayIn)
        {
            MemoryStream ms = new MemoryStream(byteArrayIn);
            System.Drawing.Image returnImage = System.Drawing.Image.FromStream(ms);
            return returnImage;
        }

        private SendEmailResponse SendMemberRenewReminderEmail(Account account, string emailTempName, ecc_payment invoice) {
            var contact = DataContext.SystemUserSet.SingleOrDefault(c => c.DomainName == ConfigurationManager.AppSettings["AccountEmailSender"]);

            var EmailTemplate = (from emailTemp in DataContext.TemplateSet
                                 where emailTemp.Title == emailTempName
                                 select new { EmailTemp = emailTemp }).SingleOrDefault();
            var domainName = System.Web.HttpContext.Current.Request.Url.Host;//Request.Url.Host;
            var XmlBody = EmailTemplate.EmailTemp.PresentationXml;
            var EmailBody = XElement.Parse(XmlBody).Element("text").Value
                            .Replace("&lt;companyName&gt;", account.Name)
                            .Replace("&lt;invoiceLink&gt;",
                                (invoice == null ? "" : "<a href='http://" + domainName + "/invoicePublicView/?invoiceId=" + invoice.Id + "'>your invoice</a>"))
                            .Replace("&lt;invoiceDueDate&gt;", account.ecc_membershipenddate.Value.ToString("yyyy/MM/dd"));
            var EmailSubject = XElement.Parse(EmailTemplate.EmailTemp.SubjectPresentationXml);
            var email_FromObj = new ActivityParty { PartyId = contact.ToEntityReference() };
            //email_FromObj.AddressUsed = "membership@EdmontonChamberCommerce.onmicrosoft.com";


            var billingContacts = DataContext.ContactSet.Where(
                c => c.StateCode == ContactState.Active &&
                c.AccountId.Id == account.Id &&
                c.ecc_ContactType != null &&
                c.ecc_ContactType.Value == (int)Contactecc_ContactType.Billing).ToList();

            var nonBillingMainContacts = DataContext.ContactSet.Where(
                c => c.StateCode == ContactState.Active &&
                c.AccountId != null &&
                c.AccountId.Id == account.Id &&
                c.ecc_MainContact != null &&
                c.ecc_MainContact.Value == true &&
                c.EMailAddress1 != null &&
                c.ecc_ContactType.Value != (int)Contactecc_ContactType.Billing).ToList();

            var ToTarget = new List<ActivityParty>();
            if (billingContacts != null && billingContacts.Count > 0)
            {
                foreach (var ct in billingContacts)
                {
                    ToTarget.Add(new ActivityParty { PartyId = ct.ToEntityReference() });
                }

            }

            if (nonBillingMainContacts != null && nonBillingMainContacts.Count > 0)
            {
                foreach (var ct in nonBillingMainContacts)
                {
                    ToTarget.Add(new ActivityParty { PartyId = ct.ToEntityReference() });
                }
            }

            if (ToTarget.Count == 0)
            {
                ToTarget.Add(new ActivityParty { PartyId = account.ToEntityReference() });
            }

            var emailInstance = new ECC.Web.Data.Crm.Email
            {
                From = new[] { email_FromObj },
                To = ToTarget,
                Cc = null,
                Subject = EmailSubject.Element("text").Value,
                Description = EmailBody,

            };
            var createRequest = new Microsoft.Xrm.Sdk.Messages.CreateRequest { Target = emailInstance };
            var createResponse = (Microsoft.Xrm.Sdk.Messages.CreateResponse)this.service.Execute(createRequest);
            Guid emailId = createResponse.id;
            if (emailId.Equals(Guid.Empty))
                throw new Exception("no email generated");

            DataContext.SaveChanges();


            SendEmailRequest emailReq = new SendEmailRequest
            {
                EmailId = emailId,
                TrackingToken = "",
                IssueSend = true
            };

            SendEmailResponse emailResp = (SendEmailResponse)service.Execute(emailReq);
            return emailResp;
        }

        private SendEmailResponse SendMemberRenewInvoiceEmail(Account account, ecc_payment invoice, string emailTempName) {
            /**********************PDF section******************************************/

            var domainName = System.Web.HttpContext.Current.Request.Url.Host;
            var imgInvoiceGenerator = new WebsiteThumbnailGenerator();
            var invoiceImage = AsyncHelpers.RunSync(() => imgInvoiceGenerator.GetThumbnailAsync(domainName + "/invoicePublicView/?invoiceId=" + invoice.Id, ImageFormat.Png,
                1000, 1200, 1000, 1200));
         
            byte[] PdfBytes = null;
            using (MemoryStream msImg = new MemoryStream(invoiceImage))
            {
                var image = Image.FromStream(msImg);

                var doc = new PdfDocument();
                var page = new PdfPage();
                page.Width = 720;
                page.Height = 850;
                doc.Pages.Add(page);
                XGraphics gfx = XGraphics.FromPdfPage(page);
                var ximg = XImage.FromGdiPlusImage(image);
                gfx.DrawImage(
                    ximg,
                    25,
                    50
                );
                using (MemoryStream stream = new MemoryStream())
                {
                    doc.Save(stream, true); //save via stream so I do not have to save this file locally and can then dispose of it, thus freeing things up
                    PdfBytes = stream.ToArray(); //save the byte array of the stream to the object's byte[] property. Mandrill attachments need to be byte arrays and THIS is what we will be attaching
                }
                //doc.Save("C:\\temp\\test.pdf");
                doc.Close();
            }

            /*********************Email section*************************/

            var contact = DataContext.SystemUserSet.SingleOrDefault(c => c.DomainName == ConfigurationManager.AppSettings["AccountEmailSender"]);

            var EmailTemplate = (from emailTemp in DataContext.TemplateSet
                                 where emailTemp.Title == emailTempName
                                 select new { EmailTemp = emailTemp }).SingleOrDefault();

            var XmlBody = EmailTemplate.EmailTemp.PresentationXml;
            var EmailBody = XElement.Parse(XmlBody).Element("text").Value
                            .Replace("&lt;companyName&gt;", account.Name)
                            .Replace("&lt;invoiceLink&gt;", "<a href='http://" + domainName + "/invoicePublicView/?invoiceId=" + invoice.Id + "'>your invoice</a>")
                            .Replace("&lt;invoiceDueDate&gt;", account.ecc_membershipenddate.Value.ToString("yyyy/MM/dd"));
            var EmailSubject = XElement.Parse(EmailTemplate.EmailTemp.SubjectPresentationXml);
            var email_FromObj = new ActivityParty { PartyId = contact.ToEntityReference() };
            
            var billingContacts= DataContext.ContactSet.Where(
                c => c.StateCode == ContactState.Active && 
                c.AccountId.Id == account.Id && 
                c.ecc_ContactType != null && 
                c.ecc_ContactType.Value == (int)Contactecc_ContactType.Billing).ToList();

            var nonBillingMainContacts= DataContext.ContactSet.Where(
                c => c.StateCode == ContactState.Active && 
                c.AccountId != null && 
                c.AccountId.Id == account.Id && 
                c.ecc_MainContact != null && 
                c.ecc_MainContact.Value == true && 
                c.EMailAddress1 != null &&
                c.ecc_ContactType.Value != (int)Contactecc_ContactType.Billing).ToList();

            var ToTarget = new List<ActivityParty>();
            if (billingContacts != null && billingContacts.Count>0)
            {
                foreach (var ct in billingContacts)
                {
                    ToTarget.Add(new ActivityParty { PartyId = ct.ToEntityReference() });
                }
                
            }

            if (nonBillingMainContacts != null && nonBillingMainContacts.Count > 0)
            {
                foreach (var ct in nonBillingMainContacts)
                {
                    ToTarget.Add(new ActivityParty { PartyId = ct.ToEntityReference() });
                }
            }

            if (ToTarget.Count == 0) {
                ToTarget.Add(new ActivityParty { PartyId = account.ToEntityReference() });
            }

            //var emailReceiverReferences = memberContact == null ? account.ToEntityReference() : memberContact.ToEntityReference();
            var emailInstance = new ECC.Web.Data.Crm.Email
            {
                From = new[] { email_FromObj },
                To = ToTarget,
                Cc = null,
                Subject = EmailSubject.Element("text").Value,
                Description = EmailBody,

            };
            var createRequest = new Microsoft.Xrm.Sdk.Messages.CreateRequest { Target = emailInstance };
            var createResponse = (Microsoft.Xrm.Sdk.Messages.CreateResponse)this.service.Execute(createRequest);
            Guid emailId = createResponse.id;
            if (emailId.Equals(Guid.Empty))
                throw new Exception("no email generated");

            var attachment = new ActivityMimeAttachment
            {
                ActivityId = new EntityReference(ECC.Web.Data.Crm.Email.EntityLogicalName, emailId),
                FileName = "invoice.pdf",
                MimeType = "application/pdf",
                AttachmentNumber = 1,
                Body = Convert.ToBase64String(PdfBytes)
            };

            DataContext.AddObject(attachment);
            DataContext.SaveChanges();


            SendEmailRequest emailReq = new SendEmailRequest
            {
                EmailId = emailId,
                TrackingToken = "",
                IssueSend = true
            };

            SendEmailResponse emailResp = (SendEmailResponse)service.Execute(emailReq);
            return emailResp;
        }

        private string invoicingEmailErrorLog(Account account, string errorMessage)
        {
            return $"Account: {account.Name}<br> {errorMessage}<br><br>";
        }

        private void SendReportToAdming(string logMsg)
        {
            try
            {
                var contact = DataContext.SystemUserSet.SingleOrDefault(c => c.DomainName == ConfigurationManager.AppSettings["AccountEmailSender"]);

                var emailInstance = new ECC.Web.Data.Crm.Email
                {
                    From = new[] { new ActivityParty { PartyId = contact.ToEntityReference() } },
                    To = new[] { new ActivityParty { PartyId = contact.ToEntityReference() } },
                    //To = new[] { new ActivityParty { PartyId = account.ToEntityReference() } },
                    Cc = null,
                    Subject = "Daily Invoicing Summary",
                    Description = logMsg,
                };
                var createRequest = new Microsoft.Xrm.Sdk.Messages.CreateRequest { Target = emailInstance };
                var createResponse = (Microsoft.Xrm.Sdk.Messages.CreateResponse)this.service.Execute(createRequest);
                Guid emailId = createResponse.id;
                if (emailId.Equals(Guid.Empty))
                    throw new Exception("no email generated");

                DataContext.SaveChanges();
                 
                SendEmailRequest emailReq = new SendEmailRequest
                {
                    EmailId = emailId,
                    TrackingToken = "",
                    IssueSend = true
                };

                SendEmailResponse emailResp = (SendEmailResponse)service.Execute(emailReq);

                
            }
            catch (Exception ex) {
                LogHelper.Info(typeof(InvoiceController), logMsg);//save invoice report to log as info
                LogHelper.Error(typeof(SendEmailResponse), ex.Message, ex);//save email error exception to log
            }
        }
        public void StartMembershipCheckScheduledTask(bool isTesting)
        {
            ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            Log.InfoFormat("AutoStartMembershipCheckScheduledTask()");

            var logdata = "";
            //due in 60 days //send preReminder
            logdata += SendEmailsByDayPeriod(60, "Membership Renew Note (+60 prior)", false, false, isTesting);

            //due in 30 days //send invoice
            logdata += SendEmailsByDayPeriod(30, "Membership Renew Note (+30 prior)", true, true, isTesting);

            //due in 15 days //send Reminder
            logdata += SendEmailsByDayPeriod(15, "Membership Renew Note (+15 prior)", true, true, isTesting);

            //expired 30 days //send Reminder and invoice
            logdata += SendEmailsByDayPeriod(-30, "Membership Renew Note (-30 past)", true, true, isTesting);

            //expired 60 days //send Reminder
            logdata += SendEmailsByDayPeriod(-60, "Membership Renew Note (-60 past)", true, false, isTesting);

            //expired 90 days //send Reminder
            logdata += SendEmailsByDayPeriod(-90, "Membership Renew Note (-90 past)", true, false, isTesting);

            //expired 120 days //send Reminder
            logdata += SendEmailsByDayPeriod(-120, "Membership Renew Note (-120 past)", true, false, isTesting);

            SendReportToAdming(logdata);
        }

        [HttpPost]
        public ActionResult TestingMembershipCheckScheduledTask()
        {
            ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
            var homeNode = new umbraco.NodeFactory.Node(1068);
            var lastRunTime = homeNode.GetProperty<DateTime>("scheduledTaskLastRunDate");
            var currentDayTime = DateTime.Now.ToMontainDateTime();


            //run testing account
            StartMembershipCheckScheduledTask(true);
            homeNode.SetProperty("scheduledTaskLastRunDate", currentDayTime);
            homeNode.Publish(true);


            var currentUrl = this.Request.UrlReferrer.AbsolutePath;
            return Redirect(string.Format("{0}?alldone=true", currentUrl));
        }

        ///currently not being used
        [HttpPost]
        public ActionResult ManueStartMembershipCheckScheduledTask()
        {
            var currentUrl = this.Request.UrlReferrer.AbsolutePath;
            StartMembershipCheckScheduledTask(false);
            return Redirect(string.Format("{0}?alldone=true", currentUrl));
        }

        private string SendEmailsByDayPeriod(int dayPeriod, string emailTemplateName, bool checkInvoice, bool attachInvoice, bool isTesting)
        {
            var logMsg = "";
            var totalCount = 0;
            var successCount = 0;
            var faildCount = 0;
            try
            {
                List <Account> accounts = GetAccountsDueIn(dayPeriod, isTesting);
                totalCount = accounts.Count;
                var startDate = DateTime.Now.AddDays(-30).ToMontainDateTime();
                var endDate = DateTime.Now.AddDays(+120).ToMontainDateTime();
                foreach (var acc in accounts)
                {
                    try
                    {
                        if (acc.ecc_cancellationdate != null) {                            
                            if (startDate < acc.ecc_cancellationdate.Value && acc.ecc_cancellationdate.Value < endDate)
                                break;
                        }
                        var invoice = checkInvoice?
                            DataContext.ecc_paymentSet.
                            OrderByDescending(i => i.CreatedOn).FirstOrDefault(
                                i => i.ecc_paymenttype == new OptionSetValue((int)ecc_paymentecc_paymenttype.MembershipRenewal) &&
                                i.ecc_Account.Id == acc.Id &&
                                i.statuscode == new OptionSetValue((int)ecc_payment_statuscode.Open)                                
                            ) : null;

                        //required by client. After +30 day, if invoice is null, do not send notification or generate invoice. 
                        if (dayPeriod < 29 && invoice == null) {
                            break;
                        }

                        if (attachInvoice)
                        {
                            if (invoice == null)
                            {
                                //invoice = GenerateRenwalInvoice(acc);// pztest client required to stop invoicing; resume in October 2016
                                throw new Exception("Invoice null reference"); //pztest remove in October 2016
                            }
                            SendMemberRenewInvoiceEmail(acc, invoice, emailTemplateName);
                        }
                        else
                        {
                            SendMemberRenewReminderEmail(acc, emailTemplateName, invoice);
                        }
                        successCount++;
                    }
                    catch (Exception ex)
                    {
                        ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
                        Log.InfoFormat("ScheduledTaskLog: Err: "+ex.StackTrace);
                        logMsg += invoicingEmailErrorLog(acc, ex.Message);
                        faildCount++;
                    }
                }
            }
            catch (Exception ex)
            { logMsg += $"<br>{ex.Message}<br>"; }

            var checkDate = DateTime.Now.AddDays(dayPeriod).ToMontainDateTime().ToString("dd-MMM-yyyy");
            if (dayPeriod > 0)
            {
                return $@"<b>{dayPeriod} Days Before ({checkDate})</b><br>
                      Successful: {successCount} <br>
                      Failed: {faildCount} <br>
                      Failure Details:
                      {logMsg}<br><br>";
            }
            else {
                return $@"<b>{-dayPeriod} Days After ({checkDate})</b><br>
                      Successful: {successCount} <br>
                      Failed: {faildCount} <br>
                      Failure Details:
                      {logMsg}<br><br>";

            }
        }
    }



    // Define other methods and classes here
    public class WebsiteThumbnailGenerator
    {
        private const int TimeoutInSeconds = 45;

        public async Task<byte[]> GetThumbnailAsync(string url, ImageFormat format, int browserWidth = 1024, int browserHeight = 768, int thumbnailWidth = 1024, int thumbnailHeight = 768)
        {
            var pngStreams = await this.GetThumbnailsAsync(url, format, browserWidth, browserHeight, thumbnailWidth, thumbnailHeight);

            // Look for the largest byte array - that's the image we'll use
            var q = (from bitmap in pngStreams
                     where bitmap.Length == pngStreams.Select(b => b.Length).Max()
                     select bitmap).FirstOrDefault();

            return q;
        }

        public async Task<List<byte[]>> GetThumbnailsAsync(string url, ImageFormat format, int browserWidth, int browserHeight, int thumbnailWidth, int thumbnailHeight)
        {
            Dictionary<string, System.Drawing.Image> thumbnails = null;
            await System.Threading.Tasks.Task.Run(() =>
            {
                var staThread = new Thread(() => this.GetThumbnails(url, browserWidth, browserHeight, thumbnailWidth, thumbnailHeight, TimeoutInSeconds, out thumbnails));
                staThread.SetApartmentState(ApartmentState.STA);
                staThread.Start();
                staThread.Join();
            });

            var pngStreams = new List<byte[]>(thumbnails.Count());

            foreach (var pair in thumbnails)
            {
                using (var ms = new MemoryStream())
                {
                    pair.Value.Save(ms, format);
                    pngStreams.Add(ms.ToArray());
                }
            }

            return pngStreams;
        }


        protected void GetThumbnails(string url, int browserWidth, int browserHeight, int thumbnailWidth, int thumbnailHeight, int timeoutSeconds, out Dictionary<string, System.Drawing.Image> thumbnails)
        {
            var results = new Dictionary<string, System.Drawing.Image>();

            using (var browser = new WebBrowser
            {
                ScriptErrorsSuppressed = true,
                Width = browserWidth,
                Height = browserHeight,
            })
            {
                long[] outstandingCalls = { 0 };

                browser.Navigating += (sender, args) => Interlocked.Increment(ref outstandingCalls[0]);

                browser.DocumentCompleted += (sender, args) =>
                {
                    while (browser != null && (browser.IsBusy && (browser.ReadyState != WebBrowserReadyState.Complete && browser.ReadyState != WebBrowserReadyState.Interactive)))
                    {
                        Application.DoEvents();
                    }

                    Interlocked.Decrement(ref outstandingCalls[0]);

                    using (var bmp = new Bitmap(browserWidth, browserHeight))
                    {

                        // Seems like you need to call DrawToBitmap several times to be sure it renders... (eg, in the case of google.ca)
                        for (var i = 0; i < 6; i++)
                        {
                            browser.DrawToBitmap(bmp, new System.Drawing.Rectangle(0, 0, browserWidth, browserHeight));
                        }

                        results.Add(args.Url.ToString(), bmp.GetThumbnailImage(thumbnailWidth, thumbnailHeight, null, IntPtr.Zero));
                    }
                };

                browser.Navigate(url);

                var startTime = DateTime.Now;


                while (Interlocked.Read(ref outstandingCalls[0]) > 0)
                {

                    Application.DoEvents();

                    if (DateTime.Now - startTime > new TimeSpan(0, 0, timeoutSeconds))
                    {
                        System.Diagnostics.Trace.WriteLine("Timeout generating thumbnail " + timeoutSeconds, "Error");
                        browser.Stop();
                        break;
                    }
                }
            }

            thumbnails = results;
        }
    }
}