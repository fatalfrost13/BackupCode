﻿using Moneris.Data.Models;

using ECC.Web.Controllers;
using ECC.Web.Data.Crm;
using ECC.Web.Email;
using ECC.Web.Extensions;
using ECC.Web.Models;

using Iomer.Umbraco.Extensions;
using IomerBase.U7.DataDefinition;

using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk;
  
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using System.Web.Security;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Web;
using System.Web.Routing;
using System.Windows.Forms;

using Umbraco.Core.Services;
using Umbraco.Web.Mvc;
using umbraco.NodeFactory;
using umbraco;

namespace ECC.Web.SurfaceControllers
{
    using Helpers;
    using Email = Iomer.Extensions.Email.EmailManager;

    public class EventController : CrmController
    {
        string monerisReferenceId = string.Empty;

        private CacheItemController cache;
        #region Constructors
        public EventController()
        {
            cache=new CacheItemController(this.service, this.DataContext);
        }

        public EventController(IOrganizationService organizationService)
        {
            this.service = (OrganizationServiceProxy)organizationService;
            this.DataContext = new EccSvcContext(service);
            cache=new CacheItemController(this.service, this.DataContext);
        }

        public EventController(IOrganizationService organizationService, EccSvcContext context)
        {
            this.service = (OrganizationServiceProxy)organizationService;
            this.DataContext = context;
            cache=new CacheItemController(this.service, this.DataContext);
        }
        #endregion

        #region Event Listing

        //Used for Cache
        public List<EventModel> GetAllActiveEvents()
        {
            var eventList = DataContext.ecc_eventSet.Where(e => e.statecode == (int)ecc_eventState.Active && e.ecc_showonwebsite != null && e.ecc_showonwebsite.Value).ToList();
            var eventModelList = eventList.Select(e => GetEventModel(e)).ToList();
            return eventModelList.Where(i => !i.Hidden).OrderBy(i => i.StartDate).ToList();
        }

        public EventModel GetUserEventByRegistration(ecc_registration registration)
        {
            var crmEvent = DataContext.ecc_eventSet.FirstOrDefault(e => e.Id == registration.ecc_Event.Id);
            var eventModelObj = GetEventModel(crmEvent);
            return eventModelObj;
        }

        /// <summary>
        /// The get event list.
        /// List of event shown on the Event Listing View.
        /// </summary>
        /// <returns>
        /// The <see cref="List"/>.
        /// </returns>
        public List<EventModel> GetEventList(bool isBackOffice = false)
        {
            var isMember = false;
            List<EventModel> eventModelList;
            if (!isBackOffice)
            {
                if (cache.CachedAccountInfo != null &&
                    cache.CachedAccountInfo.Account != null &&
                    cache.CachedAccountInfo.Account.ecc_accounttype != null)
                {
                    isMember =
                        cache.CachedAccountInfo.Account.ecc_accounttype.Equals(
                            new OptionSetValue((int) Accountecc_accounttype.Member));
                }
                //if (isMember)
                //{
                    eventModelList = cache.CachedEventList.EventList;
                //}
                //else
                //{
                //    eventModelList =
                //        cache.CachedEventList.EventList.Where(i => i.Public || i.UserIsMember).ToList();
                //}
            }
            else
            {
                eventModelList = cache.CachedEventList.EventList;
            }
            return eventModelList.OrderBy(i => i.StartDate).ToList();
        }

        /// <summary>
        /// The get upcoming event list.
        /// List of upcoming events shown on the Event Listing View.
        /// </summary>
        /// <returns>
        /// The <see cref="List"/>.
        /// </returns>
        public List<EventModel> GetUpcomingEventsList(bool preview = false)
        {
            var isMember = false;
            if (cache.CachedAccountInfo != null && cache.CachedAccountInfo.Account != null && cache.CachedAccountInfo.Account.ecc_accounttype != null)
            {
                isMember = cache.CachedAccountInfo.Account.ecc_accounttype.Equals(new OptionSetValue((int)Accountecc_accounttype.Member));
            }
            List<EventModel> eventModelList;
            //if (isMember)
            //{
                eventModelList = cache.CachedEventList.EventList;
            //}
            //else
            //{
            //    eventModelList = cache.CachedEventList.EventList.Where(i => i.Public || i.UserIsMember).ToList();
            //}

            var upcomingEventModelList = new List<EventModel>();
            
            foreach (var eventModel in eventModelList)
            {
                if ((eventModel.StartDate != null && DateTime.Now <= eventModel.StartDate) || (eventModel.EndDate != null && DateTime.Now <= eventModel.EndDate))
                {
                    var upcomingEvent = new EventModel
                    {
                        EventId = eventModel.EventId,
                        StartDate = eventModel.StartDate,
                        EndDate = eventModel.EndDate,
                        EventName = eventModel.EventName,
                        VisibleOnWebsite = eventModel.VisibleOnWebsite,
                        SortOrder = eventModel.SortOrder
                    };
                    upcomingEventModelList.Add(upcomingEvent);
                }
            }

            List<EventModel> resultList = new List<EventModel>();

            //Pick first four events that have a value in sort order. Then by start date.
            var sortOrderEvents = upcomingEventModelList.Where(e => e.SortOrder != null).ToList();
            if (sortOrderEvents != null)
            {
                var sortOrderEventsCount = sortOrderEvents.Count();
                if (sortOrderEventsCount < 4)
                {
                    resultList = sortOrderEvents.OrderBy(i => i.SortOrder).ThenBy(i => i.StartDate).Take(sortOrderEventsCount).ToList();
                    var numElementsRemoved = upcomingEventModelList.RemoveAll(i => i.SortOrder != null);
                    resultList.AddRange(upcomingEventModelList.OrderBy(i => i.StartDate).Take(4 - sortOrderEventsCount).ToList());
                }
                else
                {
                    resultList = sortOrderEvents.OrderBy(i => i.SortOrder).Take(4).ToList();
                }
            }
            else { 
                resultList = upcomingEventModelList.OrderBy(i => i.StartDate).Take(4).ToList(); 
            }

            //var premierEvent = upcomingEventModelList.Where(e => e.EventName == "Premier's State of the Province Address").FirstOrDefault();
            //if (premierEvent != null)
            //{
            //    resultList.Add(premierEvent);
            //    resultList.AddRange(upcomingEventModelList.OrderBy(i => i.StartDate).Take(3).ToList());
            //}
            //else { resultList = upcomingEventModelList.OrderBy(i => i.StartDate).Take(4).ToList(); }

            return resultList;
        }
        
        public List<EventModel> GetFeaturedEvents(Node currentNode)
        {
            var eventList = new List<EventModel>();
            var featuredEvents = currentNode.GetNodeValue(DocumentFields.featuredEvents.ToString());
            string[] featuredEventIds = featuredEvents.Split(',');
            if (featuredEventIds.Any() && featuredEvents != string.Empty)
            {
                var featuredNodes = featuredEventIds.Select(i => new Node(Int32.Parse(i)));
                foreach (var featureNode in featuredNodes)
                {
                    var eventId = featureNode.GetNodeGuid(DocumentFields.crmEventReference.ToString());
                    if (eventId != Guid.Empty)
                    {
                        var eventItem = new EventModel
                        {
                            EventId = eventId,
                            EventNodeId = featureNode.Id,
                            EventUrl = GetEventUrl(eventId.ToString()),
                            EventName = featureNode.GetTitle(),
                            ShortDescription = featureNode.GetNodeValue(DocumentFields.itemDescription.ToString())
                        };
                        eventList.Add(eventItem);
                    }
                }
            }
            return eventList;
        }

        /// <summary>
        /// The get event detail.
        /// </summary>
        /// <param name="eventDetails">
        /// The event details.
        /// </param>
        /// <returns>
        /// The <see cref="EventModel"/>.
        /// </returns>
        //This will transfer ecc_event to EventModel, save to cache. No Umbraco Content saved 
        public EventModel GetEventModel(ecc_event eventDetails)
        {
            var eventNode = this.GetEventNode(eventDetails.ecc_eventId.ToString(), eventDetails.ecc_number, eventDetails.ecc_Public ?? false);
            
            DateTime? localStartDate = eventDetails.ecc_StartDate != null
                ? eventDetails.ecc_StartDate.Value.ConvertFromCrmDateTime(this.service)
                : (DateTime?) null;
            DateTime? localEndDate = eventDetails.ecc_EndDate != null
                ? eventDetails.ecc_EndDate.Value.ConvertFromCrmDateTime(this.service)
                : (DateTime?) null;

            var eventId = eventDetails.ecc_eventId ?? Guid.Empty;

            var eventItem = new EventModel
            {
                EventId = eventId,
                EventNodeId = eventNode != null ? eventNode.Id : 0,
                Hidden = eventNode == null || eventNode.NodeHidden(),
                EventUrl = GetEventUrl(eventDetails.ecc_eventId.ToString()),
                EventName = eventDetails.ecc_number,
                Address1 = eventDetails.ecc_Address1,
                Address2 = eventDetails.ecc_Address2,
                City = eventDetails.ecc_City != null ? eventDetails.ecc_City.Name : "",
                ProvinceState = eventDetails.ecc_ProvinceState != null ? eventDetails.ecc_ProvinceState.Name : "",
                PostalCode = eventDetails.ecc_postalcode,
                Country = eventDetails.ecc_Country != null ? eventDetails.ecc_Country.Name : "",
                ShortDescription = eventDetails.ecc_Description,
                StartDate = localStartDate,
                EndDate = localEndDate,
                BackGroundImageUrl =
                    eventNode != null ? eventNode.GetNodeMediaUrl(DocumentTypes.backGroundImage.ToString()) : "",
                EventType =
                    eventDetails.ecc_EventType != null
                        ? ((ecc_eventecc_EventType) eventDetails.ecc_EventType.Value).ToString()
                        : string.Empty,

                Public = eventDetails.ecc_Public ?? false,
                VisibleOnWebsite = eventDetails.ecc_showonwebsite ?? true,
                Ticketmaster = eventDetails.ecc_ticketmaster ?? false,
                SortOrder = eventDetails.ecc_sortorder,
                Speakers = this.GetSpeakers(eventId),
                //Attendees = this.GetAttendees(eventId, -1),
                Attendees = this.GetAttendeesList(eventId),
                Sponsors = cache.CachedSponsorshipList.Sponsorships.Where(i => i.EventId == eventDetails.ecc_eventId).ToList()
            };
            return eventItem;
        }
        #endregion

        #region Event Details
        /// <summary>
        /// The get event detail.
        /// </summary>
        /// <param name="productId">
        /// The product id.
        /// </param>
        /// <returns>
        /// The <see cref="EventModel"/>.
        /// </returns>
        //Get EventDetail model from cache, then add Umbradco NodeId and Cancellation police to Model
        public EventModel GetEventDetail(Guid productId)
        {
            //var eventDetails = DataContext.rxa_rxaproductSet.SingleOrDefault(p => p.rxa_rxaproductId.Value == productId);
            //var eventItem = this.GetEventDetailModel(eventDetails);
            var eventItem = cache.CachedEventList.EventList.SingleOrDefault(i => i.EventId == productId);

            if (eventItem != null)
            {
                if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
                {

                    var eventNode = this.GetEventNode(productId.ToString(), eventItem.EventName, eventItem.Public);
                        //uQuery.GetNodesByType(DocumentTypes.eccEvent.ToString())
                        //    .SingleOrDefault(
                        //        i => i.GetNodeValue(DocumentFields.crmEventReference.ToString()) == productId.ToString());

                    if (eventNode != null)
                    {
                        eventItem.EventNodeId = eventNode.Id;
                    }

                    //var activeStatusId = service.GetOptionSetValueByLabel(rxa_membership.EntityLogicalName, "rxa_status", "Active");

                    //var memberships =
                    //    cache.CachedMembershipList.MembershipList.Where(
                    //        m => m.rxa_Status.Value == activeStatusId).ToList();
                    //var crmExtentions = new CrmExtensionsController(this.service, this.DataContext);
                    if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated 
                        && cache.CachedAccountInfo != null
                        && cache.CachedAccountInfo.Account != null)
                    {
                        var account = cache.CachedAccountInfo.Account;
                        eventItem.UserIsMember = (account.ecc_accounttype.Value == (int)Accountecc_accounttype.Member);
                    }
                }
                else
                {
                    eventItem.UserIsMember = false;
                }
            }
            eventItem.Speakers = this.GetSpeakers(productId);
            return eventItem;
        }

        //For new event registration. Combined data ecc_event and Umbraco event node. Will be saved to CRM for user registration record 
        public EventModel GetEventDetailModel(ecc_event eventDetails)
        {
            var userIsMember = false;
            if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
            {
                var account = cache.CachedAccountInfo.Account;
                userIsMember = (account.ecc_accounttype.Value == (int)Accountecc_accounttype.Member);
            }

            var eventNode = GetEventNode(eventDetails.ecc_eventId.ToString(), eventDetails.ecc_number, eventDetails.ecc_Public ?? false); //uQuery.GetNodesByType(DocumentTypes.eccEvent.ToString()).SingleOrDefault(i => i.GetNodeValue(DocumentFields.crmEventReference.ToString()) == eventDetails.ecc_eventId.ToString());
            var eventNodeId = 0;
            if (eventNode != null)
            {
                eventNodeId = eventNode.Id;
            }
            DateTime? localStartDate = eventDetails.ecc_StartDate != null ? eventDetails.ecc_StartDate.Value.ConvertFromCrmDateTime(this.service) : (DateTime?)null;
            DateTime? localEndDate = eventDetails.ecc_EndDate != null ? eventDetails.ecc_EndDate.Value.ConvertFromCrmDateTime(this.service) : (DateTime?)null;

            var eventItem = new EventModel
            {
                EventId = eventDetails.ecc_eventId != null ? eventDetails.ecc_eventId.Value : Guid.Empty,
                EventNodeId = eventNodeId,
                EventUrl = eventDetails.ecc_eventId != null ? GetEventUrl(eventDetails.ecc_eventId.Value.ToString()) : "",
                EventName = eventDetails.ecc_number,
                Address1 = eventDetails.ecc_Address1,
                Address2 = eventDetails.ecc_Address2,
                ShortDescription = eventDetails.ecc_Description,
                StartDate = localStartDate,
                BackGroundImageUrl =  eventNode != null? eventNode.GetNodeMediaUrl(DocumentTypes.backGroundImage.ToString()): "",
                EndDate = localEndDate,
                Public = eventDetails.ecc_Public != null && eventDetails.ecc_Public.Value,
                //EventStatus = this.GetEventStatus(eventDetails)
                UserIsMember = userIsMember,
                VisibleOnWebsite = eventDetails.ecc_showonwebsite ?? true,
                Ticketmaster = eventDetails.ecc_ticketmaster ?? false
            };

            return eventItem;
        }

        private Node GetEventNode(string productId, string eventName = "", bool isPublic = false)
        {
            //var eventNode = uQuery.GetNodesByType(DocumentTypes.rxaEvent.ToString()).SingleOrDefault(i => i.GetNodeValue(DocumentFields.crmEventReference.ToString()) == productId);
            var eventNode = uQuery.GetNodesByType(DocumentTypes.eccEvent.ToString()).Where(i => i.GetNodeValue(DocumentFields.crmEventReference.ToString()) == productId).Take(1).SingleOrDefault();
            if (eventNode == null)
            {
                //create an event node in umbraco
                if (eventName != string.Empty)// && isPublic)
                {
                    //prevent duplicate nodes with the same event name from being created
                    //CRM should not have events with the same name
                    var findEventNode = uQuery.GetNodesByType(DocumentTypes.eccEvent.ToString()).SingleOrDefault(i => i.Name == eventName);

                    var contentService = new ContentService();
                    if (findEventNode == null)
                    {
                        var eventsContainer = uQuery.GetNodesByType(DocumentTypes.eventsContainer.ToString()).SingleOrDefault();
                        var unpublishedDoc = contentService.GetChildrenByName(eventsContainer.Id, eventName).Where(i => i.Name == eventName).SingleOrDefault();
                        if (unpublishedDoc != null)
                        {
                            //event node with the same name exists but is unpublished.
                            unpublishedDoc.SetValue(DocumentFields.crmEventReference.ToString(), productId);
                            contentService.Publish(unpublishedDoc);
                            eventNode = new Node(unpublishedDoc.Id);
                        }
                        else
                        {
                            //event does not exist. create a new one.
                            var newEvent = contentService.CreateContent(eventName, eventsContainer.Id, DocumentTypes.eccEvent.ToString());
                            newEvent.SetValue(DocumentFields.pageTitle.ToString(), eventName);
                            newEvent.SetValue(DocumentFields.crmEventReference.ToString(), productId);
                            contentService.Publish(newEvent);
                            eventNode = new Node(newEvent.Id);
                        }
                    }
                    else
                    {
                        var updateEvent = contentService.GetById(findEventNode.Id);
                        //updateEvent.SetValue(DocumentFields.pageTitle.ToString(), eventName);
                        updateEvent.SetValue(DocumentFields.crmEventReference.ToString(), productId);
                        contentService.Publish(updateEvent);
                        eventNode = new Node(updateEvent.Id);
                    }

                }
            }
            
            return eventNode;
        }

        private string GetEventUrl(string productId)
        {
            var eventContainer = uQuery.GetNodesByType(DocumentTypes.eventsContainer.ToString()).Take(1).SingleOrDefault();
            var eventDetailsPageId = eventContainer.GetNodeValue(DocumentFields.defaultDetailPage.ToString());
            var eventDetailsPage = string.Empty;
            if (!string.IsNullOrEmpty(eventDetailsPageId))
            {
                var eventDetailNode = new Node(int.Parse(eventDetailsPageId));
                eventDetailsPage = eventDetailNode.GetUrl();
            }
            var eventUrl = string.Format("{0}?eventId={1}", eventDetailsPage, productId);
            return eventUrl;
        }

        private string GetEventStatus(ecc_event eventDetails)
        {
            string eventStatus = string.Empty;
            return eventStatus;
        }

        #endregion

        #region Event Registration

        /// <summary>
        /// The get account.
        /// Account of Cached user.
        /// </summary>
        /// <returns>
        /// The <see cref="List"/>.
        /// </returns>
        public Account GetLoggedInAccount()
        {
            bool userLoggedIn = System.Web.HttpContext.Current.User.Identity.IsAuthenticated;
            if (cache.CachedAccountInfo != null)//it means user session still valid but user is not logged in.
            {
                if (!userLoggedIn)
                {
                    System.Web.HttpContext.Current.Session.RemoveAll();
                    return null;
                }
                return cache.CachedAccountInfo.Account;
            }
            return null;
        }

        private Account CreateAccountFromEvent(RegistrationModel model)
        {
            
            Account newAccount = new Account
            {
                Name = model.RegistrationContact.FirstName + " " + model.RegistrationContact.LastName,
                ecc_firstname = model.RegistrationContact.FirstName,
                ecc_lastname = model.RegistrationContact.LastName,
                ecc_legalname = model.RegistrationContact.CompanyName ?? "", //if legalname empty, user is individual
                Address1_Line1 = model.RegistrationContact.AddressLine1,
                Address1_Line2 = model.RegistrationContact.AddressLine2,
                ecc_city = new EntityReference(geo_city.EntityLogicalName, model.RegistrationContact.CityGuid),
                Telephone1 = model.RegistrationContact.Phone,
                EMailAddress1 = model.RegistrationContact.Email,
                Address1_PostalCode = model.RegistrationContact.PostalCode,

                ecc_accounttype = new OptionSetValue((int)Accountecc_accounttype.Prospect),
                ecc_isgroupinsurance = false,
                StatusCode = new OptionSetValue((int)account_statuscode.Active),
                ecc_autorenewal = false,
                ecc_provincestate = new EntityReference(geo_province.EntityLogicalName, model.RegistrationContact.ProvinceGuid),
                ecc_ConsenttoCorrespondence = true
            };

            DataContext.AddObject(newAccount);
            DataContext.SaveChanges();
            if (!DataContext.IsAttached(newAccount))
            {
                DataContext.Attach(newAccount);
            }

            return newAccount;
        }

 
        public List<EventTicketTypeModel> GetAllEventTicketTypes()
        {
            var test = DataContext.ecc_eventtickettypeSet.ToList();
            var eventTicketTypeList = DataContext.ecc_eventtickettypeSet.Where(i => i.ecc_Event!=null && i.ecc_ExpiryDate !=null && i.ecc_ExpiryDate>=DateTime.Now.Date).ToList();
            var eventTicketTypeModelList = eventTicketTypeList.Select(e => GetEventTicketTypeModel(e)).ToList();
            

            return eventTicketTypeModelList.OrderBy(i => i.ExpiryDate).ToList();
        }

        public List<TicketPoolModel> GetAllTicketPools()
        {
            var ticketPoolList = DataContext.ecc_ticketpoolSet.ToList();
            return ticketPoolList.Select(e => GetTicketPoolModel(e)).ToList();
        }

        /// <summary>
        /// The get event ticket type list.
        /// List of event ticket type shown on the Event Registration View.
        /// </summary>
        /// <returns>
        /// The <see cref="List"/>.
        /// </returns>
        public List<EventTicketTypeModel> GetEventTicketTypeList(bool member, Guid eventId)
        {
            var eventTicketTypeModelList =
                cache.CachedEventTicketTypeList.EventTicketTypeList.Where(i => i.Member == member).Where(i => i.Event == eventId).ToList();

            return eventTicketTypeModelList.OrderBy(i => i.Price.Value).ToList();
        }

        /// <summary>
        /// This will transfer ecc_eventtickettype to EventTicketTypeModel, save to cache. No Umbraco Content saved 
        /// </summary>
        /// <param name="eventTicketTypeDetails">
        /// The event ticket type details.
        /// </param>
        /// <returns>
        /// The <see cref="EventTicketTypeModel"/>.
        /// </returns>
        /// 
        public List<TicketPoolModel> GetEventTicketPools(Guid eventId)
        {
            var eventTicketTypeModelList =
                cache.CachedEventTicketTypeList.EventTicketTypeList.Where(i => i.Event == eventId).ToList();

            var ticketPoolIds = eventTicketTypeModelList.Select(o => o.TicketPool).Distinct().ToList();
            var ticketPools =
                cache.CachedTicketPoolList.TicketPoolList.Where(
                    i => ticketPoolIds.Contains(i.TicketPoolId)).ToList();

            return ticketPools;
        }
        public EventTicketTypeModel GetEventTicketTypeModel(ecc_eventtickettype eventTicketTypeDetails)
        {
            DateTime? expiryDate = eventTicketTypeDetails.ecc_ExpiryDate != null ? eventTicketTypeDetails.ecc_ExpiryDate.Value.ConvertFromCrmDateTime(this.service) : (DateTime?)null;

            if (eventTicketTypeDetails.ecc_ticketpool != null)
            {
                var ticketpool = cache.CachedTicketPoolList.TicketPoolList.FirstOrDefault(i => i.TicketPoolId == eventTicketTypeDetails.ecc_ticketpool.Id);
                if (ticketpool != null)
                {
                    var eventItem0 = new EventTicketTypeModel
                    {
                        EventTicketTypeId = eventTicketTypeDetails.ecc_eventtickettypeId ?? Guid.Empty,
                        UnitsAvailableAfterCutoff = ticketpool.UnitsAvailableAfterCutoff,
                        Event = eventTicketTypeDetails.ecc_Event.Id,
                        ExpiryDate = expiryDate ?? DateTime.Now,
                        MaxNumberOfTicketTypes = ticketpool.MaxNumberOfTicketTypes,
                        Member = eventTicketTypeDetails.ecc_Member ?? true,
                        Name = eventTicketTypeDetails.ecc_name,
                        Price = eventTicketTypeDetails.ecc_Price,
                        TicketsPerUnit = eventTicketTypeDetails.ecc_TicketsperUnit ?? 1,
                        UnitsAvailable = ticketpool.UnitsAvailable,
                        NumberPurchased = 0,
                        TicketPool = eventTicketTypeDetails.ecc_ticketpool != null ? eventTicketTypeDetails.ecc_ticketpool.Id : Guid.Empty
                    };

                    return eventItem0;
                }
            }

            var finalCutOffNum = eventTicketTypeDetails.ecc_UnitsAvailable - (eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes - eventTicketTypeDetails.ecc_Cutoff);
            if (eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes < eventTicketTypeDetails.ecc_Cutoff)
            {
                finalCutOffNum = eventTicketTypeDetails.ecc_UnitsAvailable;
                // throw (new Exception("invalid ticket max number/cutoff number"));
            }

            var eventItem = new EventTicketTypeModel
            {
                EventTicketTypeId = eventTicketTypeDetails.ecc_eventtickettypeId ?? Guid.Empty,
                UnitsAvailableAfterCutoff = finalCutOffNum > 0 ? finalCutOffNum : 0,
                Event = eventTicketTypeDetails.ecc_Event.Id,
                ExpiryDate = expiryDate ?? DateTime.Now,
                MaxNumberOfTicketTypes = eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes,
                Member = eventTicketTypeDetails.ecc_Member ?? true,
                Name = eventTicketTypeDetails.ecc_name,
                Price = eventTicketTypeDetails.ecc_Price,
                TicketsPerUnit = eventTicketTypeDetails.ecc_TicketsperUnit ?? 1,
                UnitsAvailable = eventTicketTypeDetails.ecc_UnitsAvailable ?? 0,
                NumberPurchased = 0,
            };

            return eventItem;
        }

        //public EventTicketTypeModel GetEventTicketTypeModel(ecc_eventtickettype eventTicketTypeDetails)
        //{
        //    DateTime? expiryDate = eventTicketTypeDetails.ecc_ExpiryDate != null ? eventTicketTypeDetails.ecc_ExpiryDate.Value.ConvertFromCrmDateTime(this.service) : (DateTime?)null;

        //    if (eventTicketTypeDetails.ecc_ticketpool != null)
        //    {
        //        var ticketpool = cache.CachedTicketPoolList.TicketPoolList.FirstOrDefault(i => i.TicketPoolId == eventTicketTypeDetails.ecc_ticketpool.Id);
                
        //        var eventItem = new EventTicketTypeModel
        //        {
        //            EventTicketTypeId = eventTicketTypeDetails.ecc_eventtickettypeId ?? Guid.Empty,
        //            UnitsAvailableAfterCutoff = ticketpool.UnitsAvailableAfterCutoff,
        //            Event = eventTicketTypeDetails.ecc_Event.Id,
        //            ExpiryDate = expiryDate ?? DateTime.Now,
        //            MaxNumberOfTicketTypes = ticketpool.MaxNumberOfTicketTypes,
        //            Member = eventTicketTypeDetails.ecc_Member ?? true,
        //            Name = eventTicketTypeDetails.ecc_name,
        //            Price = eventTicketTypeDetails.ecc_Price,
        //            TicketsPerUnit = eventTicketTypeDetails.ecc_TicketsperUnit ?? 1,
        //            UnitsAvailable = ticketpool.UnitsAvailable,
        //            NumberPurchased = 0,
        //            TicketPool = eventTicketTypeDetails.ecc_ticketpool != null ? eventTicketTypeDetails.ecc_ticketpool.Id : Guid.Empty
        //        };

        //        return eventItem;
        //    }
        //    else
        //    {
        //        //TODO: test and uncomment to check for null units available
        //        //if (eventTicketTypeDetails.ecc_UnitsAvailable == null)
        //        //{
        //        //    eventTicketTypeDetails.ecc_UnitsAvailable = 0;
        //        //}
        //        var finalCutOffNum = eventTicketTypeDetails.ecc_UnitsAvailable - (eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes - eventTicketTypeDetails.ecc_Cutoff);
        //        if (eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes < eventTicketTypeDetails.ecc_Cutoff)
        //        {
        //            finalCutOffNum = eventTicketTypeDetails.ecc_UnitsAvailable;
        //            // throw (new Exception("invalid ticket max number/cutoff number"));
        //        }

        //        var eventItem = new EventTicketTypeModel
        //        {
        //            EventTicketTypeId = eventTicketTypeDetails.ecc_eventtickettypeId ?? Guid.Empty,
        //            UnitsAvailableAfterCutoff = finalCutOffNum > 0 ? finalCutOffNum : 0,
        //            Event = eventTicketTypeDetails.ecc_Event.Id,
        //            ExpiryDate = expiryDate ?? DateTime.Now,
        //            MaxNumberOfTicketTypes = eventTicketTypeDetails.ecc_MaximumNumberofTicketTypes,
        //            Member = eventTicketTypeDetails.ecc_Member ?? true,
        //            Name = eventTicketTypeDetails.ecc_name,
        //            Price = eventTicketTypeDetails.ecc_Price,
        //            TicketsPerUnit = eventTicketTypeDetails.ecc_TicketsperUnit ?? 1,
        //            UnitsAvailable = eventTicketTypeDetails.ecc_UnitsAvailable ?? 0,
        //            NumberPurchased = 0,
        //        };

        //        return eventItem;
        //    }
        //}

        /// <summary>
        /// This will transfer ecc_ticketpool to TicketPoolModel, save to cache. No Umbraco Content saved 
        /// </summary>
        /// <param name="ticketPoolDetails">
        /// The ticket pool details.
        /// </param>
        /// <returns>
        /// The <see cref="TicketPoolModel"/>.
        /// </returns>
        public TicketPoolModel GetTicketPoolModel(ecc_ticketpool ticketPoolDetails)
        {
            if (ticketPoolDetails.ecc_unitsavailable == null)
            {
                ticketPoolDetails.ecc_unitsavailable = 0;
            }

            var finalCutOffNum = ticketPoolDetails.ecc_cutoff - (ticketPoolDetails.ecc_maximumnumberoftickettypes - ticketPoolDetails.ecc_unitsavailable);
            if (ticketPoolDetails.ecc_maximumnumberoftickettypes < ticketPoolDetails.ecc_cutoff)
            {
                finalCutOffNum = ticketPoolDetails.ecc_unitsavailable;
                // throw (new Exception("invalid ticket max number/cutoff number"));
            }
            var ticketPool = new TicketPoolModel
            {
                TicketPoolId = ticketPoolDetails.ecc_ticketpoolId ?? Guid.Empty,
                UnitsAvailableAfterCutoff = finalCutOffNum > 0 ? finalCutOffNum : 0,
                MaxNumberOfTicketTypes = ticketPoolDetails.ecc_maximumnumberoftickettypes,
                UnitsAvailable = ticketPoolDetails.ecc_unitsavailable ?? 0
            };

            return ticketPool;
        }

        [HttpPost]
        public ActionResult UserAccountRegistration(RegistrationModel model, string accountEmail)
        {
            var returnUrl = "";
            var currNode = Node.GetCurrent();
            var account = GetLoggedInAccount();
            if (account == null) //not logged in
            {
                account = DataContext.AccountSet.SingleOrDefault(i => i.EMailAddress1 == accountEmail);
                if (account != null)// account exist
                {
                    if (account.StateCode == AccountState.Active &&
                        account.ecc_accounttype.Value == (int)Accountecc_accounttype.Member)
                    {   // active user not logged in
                        //return error "cannot Update Password"
                        returnUrl = string.Format("{0}?status={1}&step=2", currNode.Url, "cannotUpdatePassword");
                        return Redirect(returnUrl);
                    }
                }
            }

            if (model.Password == model.ConfirmPassword)
            {
                var webMembership =
                    DataContext.appl_webmembershipSet.FirstOrDefault(i => i.EmailAddress == accountEmail);
                if (webMembership != null)
                {
                    webMembership.appl_password = model.ConfirmPassword;
                    webMembership.appl_isapproved = true;
                    DataContext.UpdateObject(webMembership);
                    DataContext.SaveChanges();
                }

                cache.CachedBusinessDirectory.AccountList.Add(
                    new AccountModel
                    {
                        Email = webMembership.EmailAddress,
                        Password = webMembership.appl_password
                    });
            }

            TempData["UserValidated"] = true;
            TempData["Message"] =
                "Your Account has been created.";

            returnUrl = string.Format("{0}?status=passwordCreate&step=2&eventId={1}&paymentId", currNode.Url, model.EventGuid);

            return Redirect(returnUrl);
        }

        [HttpPost]
        public ActionResult SubmitEventRegistration(RegistrationModel model, string eventId)
        {
            var returnUrl = "";
            var currNode = Node.GetCurrent();

            var account = GetLoggedInAccount();
            if (account == null) //not logged in
            {
                account = DataContext.AccountSet.SingleOrDefault(i => i.EMailAddress1 == model.RegistrationContact.Email);
                if (account != null)// account exists
                {
                    if (account.StateCode == AccountState.Active &&
                        account.ecc_accounttype.Value == (int)Accountecc_accounttype.Member)
                    {   // active user not logged in
                        //return error "must login"
                        returnUrl = string.Format("{0}?status={1}&step=2&eventId={2}", currNode.Url, "mustLogin", eventId);
                        return Redirect(returnUrl);
                    }
                }
            }

            var refnum = ProcessRegistration(model, eventId, ref account);

            System.Web.HttpContext.Current.Session["Account"] = account;
            System.Web.HttpContext.Current.Session["UserEvenList"] = null;
            //var response = this.TempData["serverResp"].ToString();
            var transStatus = this.TempData["transStatus"].ToString(); 
            
            returnUrl = string.Format("{0}?status={1}&step=2&eventId={2}&paymentId={3}", currNode.Url, transStatus, eventId, refnum);

            return Redirect(returnUrl);
        }

        /// <summary>
        /// Calculates the fee owing from the tickets purchased and discount applied. 
        /// </summary>
        /// <param name="model"></param>
        /// <returns>string representing fee as currency</returns>
        private string CalculatePaymentFee(RegistrationModel model, PaymentSection paymentSection, bool isGstExempt)
        {
            decimal priceBeforeGst = 0;
            ecc_eventtickettype eventtickettype;
            Money price = new Money(0);
            if (model.MemberTicketTypes != null)
            {
                foreach (var membertickets in model.MemberTicketTypes)
                {
                    var ticketType =
                        cache.CachedEventTicketTypeList.EventTicketTypeList.SingleOrDefault(a => a.EventTicketTypeId == membertickets.EventTicketTypeId);

                    if (ticketType != null)
                    {
                        price = ticketType.Price;
                        priceBeforeGst = priceBeforeGst + (membertickets.NumberPurchased * price.Value);
                        var paymentItem = new PaymentItem();
                        paymentItem.ItemCost = price.Value;
                        paymentItem.TotalCost = membertickets.NumberPurchased * price.Value;
                        paymentItem.ItemName = ticketType.Name;
                        paymentItem.ItemTax = isGstExempt? 0 : price.Value * model.Payment.GstRate;
                        paymentItem.IsMember = true;
                        paymentItem.NumberPurchased = membertickets.NumberPurchased;
                        paymentSection.PaymentItems.Add(paymentItem);
                    }
                }
            }
            if (model.NoneMemberTicketTypes != null)
            {
                foreach (var nonmembertickets in model.NoneMemberTicketTypes)
                {
                    var ticketType =
                        cache.CachedEventTicketTypeList.EventTicketTypeList.SingleOrDefault(a => a.EventTicketTypeId == nonmembertickets.EventTicketTypeId);

                    if (ticketType != null)
                    {
                        price = ticketType.Price;
                        priceBeforeGst = priceBeforeGst + (nonmembertickets.NumberPurchased * price.Value);
                        var paymentItem = new PaymentItem();
                        paymentItem.ItemCost = price.Value;
                        paymentItem.ItemName = ticketType.Name;
                        paymentItem.ItemTax = isGstExempt ? 0 : price.Value * model.Payment.GstRate;
                        paymentItem.IsMember = false;
                        paymentItem.NumberPurchased = nonmembertickets.NumberPurchased;
                        paymentSection.PaymentItems.Add(paymentItem);
                    }
                }
            }

            // subtract discount if discount is associated with event or discount is not associated with any event.
            var discount = DataContext.ecc_discountSet.SingleOrDefault(
                                    m => m.ecc_Code == model.Discount && (m.ecc_Events == null || m.ecc_Events.Id == model.EventGuid));
            
            if (discount != null )
            {
                if (discount.ecc_NumberofUses == null)
                {
                    discount.ecc_NumberofUses = 0;
                }
                // ajax call proved discount valid, don't do number check anymore?
                model.Payment.TotalDiscountAmount = Convert.ToDecimal(discount.ecc_Amount);
                // This addition is being done in the PostPaymentCreate plugin
                //discount.ecc_NumberofUses = discount.ecc_NumberofUses + 1;
                //DataContext.UpdateObject(discount);
                //DataContext.SaveChanges();
            }

            priceBeforeGst = priceBeforeGst - model.Payment.TotalDiscountAmount;
            if (priceBeforeGst < 0)
            {
                priceBeforeGst = 0M;
            }

            model.Payment.SubTotalAmount = Convert.ToDecimal(priceBeforeGst);

            var gst = isGstExempt ? 0 : priceBeforeGst * model.Payment.GstRate;
            var priceAfterGst = priceBeforeGst + gst;

            model.Payment.TotalTaxAmount = Convert.ToDecimal(gst);
            model.Payment.TotalAmount = Convert.ToDecimal(priceAfterGst);

            model.Payment.Fee = model.Payment.TotalAmount;
            var fee = String.Format("{0:0.00}", model.Payment.Fee);
            return fee;
        }

        private string ProcessRegistration(RegistrationModel model, string productId, ref Account account)
        {
            System.Web.HttpContext.Current.Session["PaymentInfo"] = model.Payment;
            var transactionController = new MonerisController();
            var eventEntity =
                cache.CachedEventList.EventList.SingleOrDefault(a => a.EventId.ToString() == productId);
            var eventName = string.Empty;
            if (eventEntity != null)
            {
                eventName = eventEntity.EventName;
            }

            var expiryDate = model.Payment.ExpiryDateYear.Trim().Substring(2) + model.Payment.ExpiryDateMonth.Trim();

            monerisReferenceId = string.Format("ECC_EventReg_{0}{1}", model.RegistrationContact.FirstName.Replace(" ", "") + model.RegistrationContact.LastName.Replace(" ", ""), DateTime.Now.Ticks);
            model.Payment.RefNo = monerisReferenceId;

            var paymentSection = new PaymentSection();
            paymentSection.SectionName = "Event registration for " + eventName;
            paymentSection.PaymentItems = new List<PaymentItem>();

            bool isGstExempt = account.ecc_isgstexempt ?? false;
            var fee = CalculatePaymentFee(model, paymentSection, isGstExempt);
            
            if (model.DifferentBillingAddress)
            {
                var billingCity = cache.CachedCityList.CityList.SingleOrDefault(i => i.CityId == model.BillingAddress.CityGuid);
                    
                var billingProvince = cache.CachedProvinceStateList.ProvinceStateList.SingleOrDefault(i => i.ProvinceId == model.BillingAddress.ProvinceGuid);                    

                if (billingCity != null && billingProvince != null)
                {
                    transactionController.SetUserInfo(
                        model.RegistrationContact.FirstName, 
                        model.RegistrationContact.LastName,
                        model.RegistrationContact.CompanyName,
                        model.BillingAddress.AddressLine1 + "  " + model.BillingAddress.AddressLine2, 
                        billingCity.Name,
                        billingProvince.Name,
                        model.BillingAddress.PostalCode,
                        billingProvince.CountryName, 
                        model.RegistrationContact.Phone,
                        string.Empty, model.RegistrationContact.Email);
                }
            }
            else
            {
                var city = cache.CachedCityList.CityList.SingleOrDefault(i => i.CityId == model.RegistrationContact.CityGuid);
                var province = cache.CachedProvinceStateList.ProvinceStateList.SingleOrDefault(i => i.ProvinceId == model.RegistrationContact.ProvinceGuid);                    

                transactionController.SetUserInfo(
                    model.RegistrationContact.FirstName, 
                    model.RegistrationContact.LastName,
                    model.RegistrationContact.FirstName + " " + model.RegistrationContact.LastName + " " + model.RegistrationContact.CompanyName,
                    model.RegistrationContact.AddressLine1 + "  " + model.RegistrationContact.AddressLine2,
                    city.Name,
                    province.Name,
                    model.RegistrationContact.PostalCode, 
                    "Canada",
                    model.RegistrationContact.Phone,
                    string.Empty,
                    model.RegistrationContact.Email);
            }
            transactionController.SetNewTransaction(monerisReferenceId, fee, model.Payment.CreditCardNumber,
                model.Payment.NameOnCard, expiryDate, model.Payment.SecurityCode, "0", "0", "0", "0", eventName);
            MonerisResponse response;
            string respMsg = string.Empty;
            var result = string.Empty;
            
            if (fee != "0.00")//todo what about free event with limited ticket number? 
            {

                response = transactionController.ProcessMonerisTransaction();
                respMsg = "RespCode:" + response.ResponseCode + "; " + response.ResponseMessage;
                var transStatus = "";
                switch (response.ResponseStatus)
                {
                    case PaymentStatus.Approved:
                        result = "approved; " + respMsg;
                        transStatus = "approved";
                        break;
                    case PaymentStatus.Declined:
                        result = "declined; " + respMsg;
                        transStatus = "declined";
                        break;
                    case PaymentStatus.Incomplete:
                        result = "incomplete; " + respMsg;
                        transStatus = "incomplete";
                        break;
                    case PaymentStatus.Error:
                        result = "error; " + respMsg;
                        transStatus = "error";
                        break;
                }
                this.TempData["transStatus"] = transStatus;
                this.TempData["serverResp"] += result;

                if (response.ResponseStatus == PaymentStatus.Approved)
                {
                    if (account == null) //not logged in
                    {
                        account = CreateAccountFromEvent(model);
                    }

                    Guid registrationGuid = CreateEventRegistration(model, account.ToEntityReference());

                    // Step 2 create invoice
                    var pmt = CreatePayment(response, model, account, eventName, registrationGuid);

                    model.Payment.LastFourDigits = model.Payment.CreditCardNumber.Substring(12);

                    //Step 3 Create event ticket type registrations
                    try
                    {
                        CreateEventTicketTypeRegistrations(model, registrationGuid);
                    }
                    catch (Exception ex)
                    {
                        writeSessionPaymentInfo(model, paymentSection, response, "ticketGeneratingError");
                        return response.ReferenceNumber;
                    }
                    var paymentInfo = writeSessionPaymentInfo(model, paymentSection, response);

                    // Step 4 Send Email
                    var emlresult = SendConfirmationEmail(GetEventDetail(model.EventGuid), account, pmt, paymentInfo, registrationGuid, model);
                    if (!emlresult.EmailSent)
                    { this.TempData["serverResp"] = emlresult.ErrorMessage + " " + this.TempData["serverResp"]; }
                    return response.ReferenceNumber;

                }
                writeSessionPaymentInfo(model, paymentSection, response);
                return response.ReferenceNumber;


            }

            var feeInfo = System.Web.HttpContext.Current.Session["PaymentInfo"] as PaymentModel;
            if (feeInfo != null)
            {
                feeInfo.PaymentSections = new List<PaymentSection> { paymentSection };
                feeInfo.Fee = Decimal.Zero;
                System.Web.HttpContext.Current.Session["PaymentInfo"] = feeInfo;
            }
            
            return "";
        }

        private ecc_payment CreatePayment(MonerisResponse response, RegistrationModel model, Account account, string eventName, Guid registrationId) 
        {
                    ecc_paymentdetail pmtDetailDiscount = null;

            var pmt = new ecc_payment() { ecc_moneristransactionnumber = "000-000" };
                    pmt.ecc_moneristransactionnumber = response.ReferenceNumber;
                    pmt.ecc_paymenttype = new OptionSetValue((int)ecc_paymentecc_paymenttype.EventRegistration);
                    pmt.ecc_FormofPayment = new OptionSetValue((int)ecc_paymentecc_FormofPayment.CreditCard);
                    pmt.ecc_cardtype = new OptionSetValue(Convert.ToInt32(model.Payment.Method));
                    pmt.ecc_Account = account.ToEntityReference();
                    pmt.ecc_Registration = new EntityReference
                    {
                Id = registrationId,
                        LogicalName = ecc_registration.EntityLogicalName
                    };
                    switch (model.Payment.Method)
                    {
                        case "Visa":
                            pmt.ecc_cardtype = new OptionSetValue((int)ecc_paymentecc_cardtype.Visa);
                            break;
                        case "MasterCard":
                            pmt.ecc_cardtype = new OptionSetValue((int)ecc_paymentecc_cardtype.MasterCard);
                            break;
                    }
                    pmt.statuscode = new OptionSetValue((int)ecc_payment_statuscode.Paid);
                    pmt.ecc_IsGI = account.ecc_isgroupinsurance;
                    DataContext.AddObject(pmt);
                    DataContext.SaveChanges();

                    //Add payment detail
                    if (model.MemberTicketTypes != null)
                    {
                        foreach (var eventTicketType in model.MemberTicketTypes)
                        {
                            if (eventTicketType.NumberPurchased > 0)
                            {
                                var pmtDetailEvent = new ecc_paymentdetail();
                                pmtDetailEvent.ecc_name = eventTicketType.Name + " tickets for " + eventName;
                                pmtDetailEvent.ecc_unitamount = eventTicketType.Price;
                                pmtDetailEvent.ecc_quantity = eventTicketType.NumberPurchased;
                                pmtDetailEvent.ecc_payment = new EntityReference(ecc_payment.EntityLogicalName,
                                    pmt.ecc_paymentId.Value);
                                DataContext.AddObject(pmtDetailEvent);
                            }
                        }
                    }

                    if (model.NoneMemberTicketTypes != null)
                    {
                        foreach (var eventTicketType in model.NoneMemberTicketTypes)
                        {
                            if (eventTicketType.NumberPurchased > 0)
                            {
                                var pmtDetailEvent = new ecc_paymentdetail();
                                pmtDetailEvent.ecc_name = eventTicketType.Name + " tickets for " + eventName;
                                pmtDetailEvent.ecc_unitamount = eventTicketType.Price;
                                pmtDetailEvent.ecc_quantity = eventTicketType.NumberPurchased;
                                pmtDetailEvent.ecc_payment = new EntityReference(ecc_payment.EntityLogicalName,
                                    pmt.ecc_paymentId.Value);
                                DataContext.AddObject(pmtDetailEvent);
                            }
                        }
                    }
                    DataContext.SaveChanges();

                    var sessionContext = System.Web.HttpContext.Current.Session;
            if (sessionContext != null && sessionContext["UserInvoiceList"] != null)
                    {
                        sessionContext.Remove("UserInvoiceList");
                    }

                    //add discount
                    var discount = DataContext.ecc_discountSet.SingleOrDefault(m => m.ecc_Code == model.Discount && (m.ecc_Events == null || m.ecc_Events.Id == model.EventGuid));
                    if (discount != null)
                    {
                        pmtDetailDiscount = new ecc_paymentdetail()
                        {
                            ecc_name = discount.ecc_number,
                            ecc_unitamount = new Money(Decimal.Parse(discount.ecc_Amount) * -1M),
                            ecc_GST = new Money(0M),
                            ecc_quantity = 1,
                            ecc_payment = new EntityReference(ecc_payment.EntityLogicalName, pmt.ecc_paymentId.Value)
                        };
                        DataContext.AddObject(pmtDetailDiscount);

                        if (!DataContext.IsAttached(pmt))
                        {
                            DataContext.Attach(pmt);
                        }
                        pmt.ecc_Discount = discount.ToEntityReference();
                        DataContext.UpdateObject(pmt);
                        DataContext.SaveChanges();
                    }
            return pmt;
        }

        private PaymentModel writeSessionPaymentInfo(RegistrationModel model, PaymentSection paymentSection, MonerisResponse response, string error = null)
        {
            
            var paymentInfo = System.Web.HttpContext.Current.Session["PaymentInfo"] as PaymentModel;
            paymentInfo.NameOnCard = model.Payment.NameOnCard;
            paymentInfo.CCExpiry = string.Format("{0}/{1}", model.Payment.ExpiryDateMonth,
                model.Payment.ExpiryDateYear);
            paymentInfo.RefNo = model.Payment.RefNo;
            paymentInfo.LastFourDigits = string.Format("************{0}", model.Payment.LastFourDigits);
            paymentInfo.SelectedPaymentMethod = model.Payment.SelectedPaymentMethod;
            paymentInfo.PaymentSections = new List<PaymentSection> { paymentSection };
            paymentInfo.ErrorMessage = error == null ? response.ResponseStatus.ToString() : error;
            System.Web.HttpContext.Current.Session["PaymentInfo"] = paymentInfo;
            return paymentInfo;
        }

        private Guid CreateEventRegistration(RegistrationModel model, EntityReference accountReference)
        {
            Guid returnId;
            try
            {
                var newEventRegistration = new ecc_registration
                {
                    ecc_account = accountReference,
                    ecc_Event = new EntityReference("ecc_event", model.EventGuid),
                    ecc_firstname = model.RegistrationContact.FirstName,
                    ecc_lastname = model.RegistrationContact.LastName,
                    ecc_address1 = model.RegistrationContact.AddressLine1,
                    ecc_address2 = model.RegistrationContact.AddressLine2,
                    ecc_postalcode = model.RegistrationContact.PostalCode,
                    ecc_city = new EntityReference(geo_city.EntityLogicalName, model.RegistrationContact.CityGuid),
                    ecc_province = new EntityReference(geo_province.EntityLogicalName, model.RegistrationContact.ProvinceGuid),
                    ecc_emailaddress = model.RegistrationContact.Email,
                    ecc_phonenumber = model.RegistrationContact.Phone,
                    ecc_displayinattendeelist=model.DisplayInAttendeeList,
                    ecc_companyname = model.RegistrationContact.CompanyName
                };
                DataContext.AddObject(newEventRegistration);
                DataContext.SaveChanges();
                if (!DataContext.IsAttached(newEventRegistration))
                {
                    DataContext.Attach(newEventRegistration);
                }
                returnId = newEventRegistration.ecc_registrationId.Value;
            }
            catch (Exception e)
            {
                returnId = Guid.Empty;
            }

            return returnId;
        }

        private void CreateEventTicketTypeRegistrations(RegistrationModel model, Guid registrationGuid)
        {
            var registration = DataContext.ecc_registrationSet.SingleOrDefault(m => m.ecc_registrationId == registrationGuid);

            if (registration != null)
            {
                ecc_eventtickettyperegistration newEventTicketTypeRegistration;
                ecc_eventtickettype eventTicketType;
                if (model.MemberTicketTypes != null)
                {
                    foreach (var eventTicketTypeRegistration in model.MemberTicketTypes)
                    {
                        if (eventTicketTypeRegistration.NumberPurchased > 0)
                        {
                            var typeRegistration = eventTicketTypeRegistration;
                            eventTicketType =
                                DataContext.ecc_eventtickettypeSet.SingleOrDefault(
                                    m => m.ecc_eventtickettypeId == typeRegistration.EventTicketTypeId);
                            if (eventTicketType != null)
                            {
                                newEventTicketTypeRegistration = new ecc_eventtickettyperegistration
                                {
                                    ecc_NumberofTicketTypes = eventTicketTypeRegistration.NumberPurchased,
                                    ecc_Registration = registration.ToEntityReference(),
                                    ecc_EventTicketType = eventTicketType.ToEntityReference()
                                };
                                DataContext.AddObject(newEventTicketTypeRegistration);
                                DataContext.SaveChanges();
                                if (!DataContext.IsAttached(newEventTicketTypeRegistration))
                                {
                                    DataContext.Attach(newEventTicketTypeRegistration);
                                }
                                var cachedTicket =
                                    cache.CachedEventTicketTypeList.EventTicketTypeList.FirstOrDefault(
                                        i => i.EventTicketTypeId == eventTicketTypeRegistration.EventTicketTypeId);
                                if (cachedTicket != null)
                                {
                                    var cachedTicketPool = cache.CachedTicketPoolList.TicketPoolList.FirstOrDefault(
                                    i => i.TicketPoolId == cachedTicket.TicketPool);

                                    cachedTicketPool.UnitsAvailable -= (eventTicketTypeRegistration.NumberPurchased * cachedTicket.TicketsPerUnit);
                                    cachedTicketPool.UnitsAvailableAfterCutoff -= (eventTicketTypeRegistration.NumberPurchased * cachedTicket.TicketsPerUnit);
                                }
                                else
                                    cache.CachedEventTicketTypeList = null;
                            }
                        }
                    }
                }
                if (model.NoneMemberTicketTypes != null)
                {
                    foreach (var eventTicketTypeRegistration in model.NoneMemberTicketTypes)
                    {
                        if (eventTicketTypeRegistration.NumberPurchased > 0)
                        {
                            var typeRegistration = eventTicketTypeRegistration;
                            eventTicketType =
                                DataContext.ecc_eventtickettypeSet.SingleOrDefault(
                                    m => m.ecc_eventtickettypeId == typeRegistration.EventTicketTypeId);
                            if (eventTicketType != null)
                            {
                                newEventTicketTypeRegistration = new ecc_eventtickettyperegistration
                                {
                                    ecc_NumberofTicketTypes = eventTicketTypeRegistration.NumberPurchased,
                                    ecc_Registration = registration.ToEntityReference(),
                                    ecc_EventTicketType = eventTicketType.ToEntityReference()
                                };
                                DataContext.AddObject(newEventTicketTypeRegistration);
                                DataContext.SaveChanges();
                                if (!DataContext.IsAttached(newEventTicketTypeRegistration))
                                {
                                    DataContext.Attach(newEventTicketTypeRegistration);
                                }

                                var cachedTicket =
                                    cache.CachedEventTicketTypeList.EventTicketTypeList.FirstOrDefault(
                                        i => i.EventTicketTypeId == eventTicketTypeRegistration.EventTicketTypeId);
                                if (cachedTicket != null)
                                {
                                    var cachedTicketPool = cache.CachedTicketPoolList.TicketPoolList.FirstOrDefault(
                                   i => i.TicketPoolId == cachedTicket.TicketPool);

                                    cachedTicketPool.UnitsAvailable -= (eventTicketTypeRegistration.NumberPurchased * cachedTicket.TicketsPerUnit);
                                    cachedTicketPool.UnitsAvailableAfterCutoff -= (eventTicketTypeRegistration.NumberPurchased * cachedTicket.TicketsPerUnit);
                                }
                                else
                                    cache.CachedEventTicketTypeList = null;
                            }
                        }
                    }
                }
            }
        }

        public Email.EmailStatus SendConfirmationEmail(EventModel eventModel, Account accountModel, ecc_payment payment, PaymentModel paymentInfo, Guid registrationGuid, RegistrationModel registrationModel)
        {
            var emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = string.Empty };
            try
            {
                // first get email parameters
                var eventNode = new Node(eventModel.EventNodeId);
                var notificationTemplateId = eventNode.GetNodeValue(DocumentFields.notificationTemplate.ToString()) != string.Empty
                ? int.Parse(eventNode.GetNodeValue(DocumentFields.notificationTemplate.ToString())) : 0;
                if (eventModel.Ticketmaster)
                {
                    notificationTemplateId = int.Parse(ConfigurationManager.AppSettings["ticketmasterEventTemplateId"]);
                }
                if (notificationTemplateId == 0)
                {
                    notificationTemplateId = int.Parse(ConfigurationManager.AppSettings["defaultEventTemplateId"]);
                }

                if (notificationTemplateId > 0)
                {
                    var notificationNode = new Node(notificationTemplateId);
                    var emailSubject = notificationNode.GetNodeValue(DocumentFields.emailSubject.ToString());
                    //var emailFrom = notificationNode.GetNodeValue(DocumentFields.emailFrom.ToString());
                    var emailMessage = notificationNode.GetNodeValue(DocumentFields.emailMessage.ToString());
                    var emailBcc = notificationNode.GetNodeValue(DocumentFields.emailBcc.ToString());

                    const string emailTemplate = "/Email/StandardTemplate.html";
                    var onlineTicketUrl = "";
                    if (!eventModel.Ticketmaster)
                        onlineTicketUrl =
                            String.Format( "<br/><span style='font-size: 14pt;'> If the ticket is not displayed properly, you can view it online by <a href=\"{0}/display-ticket?regId={1}\">clicking here</a> </span> <br/>", Request.Url.Host, registrationGuid);
                    else
                        onlineTicketUrl = "";//ticket master?

                    var replacements = DictionaryReplacement.EventConfirmation(
                        this.service,
                        this.DataContext,
                        eventModel,
                        accountModel,
                        paymentInfo,
                        onlineTicketUrl,
                        registrationModel
                    );

                    if (!eventModel.Ticketmaster)
                        emailMessage += GetTicketContents(payment.ecc_Registration.Id);
                    Contact mainContact = null;
                    if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
                    {
                        mainContact =
                            cache.CachedUserContacts.ContactList.FirstOrDefault(
                                c => c.ecc_MainContact.Value);
                    }
                    emailStatus = Email.SendEmail(
                    accountModel.ToEntityReference(),
                    emailSubject,
                    emailMessage,
                    emailTemplate,
                        replacements,
                        payment.ecc_Account,
                        //mainContact==null?null : mainContact.ToEntityReference(),
                        null,
                        emailBcc,
                        null,
                        "",
                        registrationModel.RegistrationContact.Email);
                }
            }
            catch (Exception ex)
            { 
                emailStatus = new Email.EmailStatus { EmailSent = false, ErrorMessage = ex.ToString() };
            }
            return emailStatus;
        }

        [HttpGet]
        public ViewResult DisplayTicket(Guid registrationId)
        {
            var model = GetTicketModel(registrationId);
            return View("Ticket", model);
        }

        public string GetTicketContents(Guid regId)
        {
            var rc = new ApiControllers.ReportController();
            var content = rc.TicketContents(regId);
            return content;
        }

        public TicketModel GetTicketModel(Guid registrationId)
        {
            // Get registration data
            var reg = DataContext.ecc_registrationSet.SingleOrDefault(r => r.ecc_registrationId == registrationId);
            if (reg == null) return null;
            
            // Load ticket model based on registration/event data
            var tm = new TicketModel();
            var account = DataContext.AccountSet.SingleOrDefault(a => a.AccountId == reg.ecc_account.Id);
            var regEvent = DataContext.ecc_eventSet.SingleOrDefault(e => e.ecc_eventId == reg.ecc_Event.Id);
            var etrs = (from etr in DataContext.ecc_eventtickettyperegistrationSet
                        join t in DataContext.ecc_eventtickettypeSet on etr.ecc_EventTicketType.Id equals t.ecc_eventtickettypeId
                        where etr.ecc_Registration.Id == reg.ecc_registrationId.Value
                        select new TicketItemModel() { TicketTypeName = etr.ecc_EventTicketType.Name, Price = t.ecc_Price.Value, Quantity = etr.ecc_NumberofTicketTypes.Value, TotalPrice = t.ecc_Price.Value * etr.ecc_NumberofTicketTypes.Value }
                        ).ToList();

            tm.AccountName = account.Name;
            tm.EventName = regEvent.ecc_number;

            DateTime eventStartDate = regEvent.ecc_StartDate.Value.ConvertFromCrmDateTime();
            DateTime eventEndDate = regEvent.ecc_EndDate.Value.ConvertFromCrmDateTime();
            
            var dtTime = eventStartDate.ToString("dddd MMM dd, yyyy h:mm tt");
            if (eventStartDate.Date == eventEndDate.Date)
            { dtTime += " to " + eventEndDate.ToString("h:mm tt"); }
            else
            { dtTime += " to " + eventEndDate.ToString("dddd MMM dd, yyyy h:mm tt"); }
            tm.EventDateAndTime = dtTime;

            tm.Address1 = regEvent.ecc_Address1;
            tm.Address2 = regEvent.ecc_Address2;
            tm.City = regEvent.ecc_City != null ? regEvent.ecc_City.Name : string.Empty;
            tm.Province = regEvent.ecc_ProvinceState != null ? regEvent.ecc_ProvinceState.Name : string.Empty;
            tm.PostalCode = regEvent.ecc_postalcode;
            tm.TicketItems = etrs;

            return tm;
        }

        public string RenderTicket(TicketModel model)
        {
            var stringResult = string.Empty;

            // Apply model to view and render
            using (var sw = new StringWriter())
            {
                var ctx = new HttpContextWrapper(System.Web.HttpContext.Current);
                var routeData = RouteTable.Routes.GetRouteData(this.UmbracoContext.HttpContext);
                var ctrlContext = new ControllerContext(new RequestContext(ctx, routeData), new EventController());
                var viewResult = ViewEngines.Engines.FindPartialView(ctrlContext, "Ticket");
                var viewContext = new ViewContext(ctrlContext, viewResult.View, new ViewDataDictionary(model), new TempDataDictionary(), sw);
                viewResult.View.Render(viewContext, sw);
                stringResult = sw.GetStringBuilder().ToString();
            }

            return stringResult;
        }
        #endregion

        public void testfun() { }

        #region Cache


        //public List<AccountModel> GetCachedWebAccounts()
        //{
        //    return cache.CachedAccountList.Accounts.ToList();
        //}

        public List<CityModel> GetCachedCities()
        {
            if (cache.CachedCityList != null)
            {
                return cache.CachedCityList.CityList.ToList();
            }
            return null;
        }

        public List<KeyValuePair<Guid, string>> GetCachedCitiesForProvince(Guid selectedProvince)
        {
            if (cache.CachedCityList != null)
            {
                return cache.CachedCityList.CityList.Where(c => c.ProvinceId == selectedProvince).ToDictionary(c => c.CityId, c => c.Name).ToList();
            }
            return null;
        }

        public List<ProvinceModel> GetCachedProvinces()
        {
            if (cache.CachedProvinceStateList != null)
            {
                return cache.CachedProvinceStateList.ProvinceStateList.ToList();
            }
            return null;
        }

        public List<CityModel> GetCityList()
        {
            var canadaId = DataContext.geo_countrySet.FirstOrDefault(i => i.geo_name.Equals("Canada")).geo_countryId;
            var americaId = DataContext.geo_countrySet.FirstOrDefault(i => i.geo_name.Equals("USA")).geo_countryId;
            var citiesList = 
                DataContext.
                geo_citySet.
                Join(DataContext.geo_provinceSet, 
                    i => i.geo_provinceid.Id, 
                    j => j.geo_provinceId,
                    (i, j) => new {i, j}).
                OrderBy(c => c.i.geo_name).
                Where(c => c.i.geo_cityId != null &&
                    c.i.geo_name != null &&
                    c.i.geo_provinceid != null && 
                    (c.j.geo_countryid.Id == canadaId || c.j.geo_countryid.Id == americaId)).
                ToList().
                Select(c => new CityModel { CityId = c.i.geo_cityId.Value, Name = c.i.geo_name, ProvinceId = c.i.geo_provinceid.Id }).ToList();
            return citiesList;
        }

        /// <summary>
        /// This will transfer geo_city to CityModel, save to cache. No Umbraco Content saved 
        /// </summary>
        /// <param name="cityDetails">
        /// The city details.
        /// </param>
        /// <returns>
        /// The <see cref="CityModel"/>.
        /// </returns>
        public CityModel GetCityModel(geo_city cityDetails)
        {
            var cityItem = new CityModel
            {
                CityId = cityDetails.geo_cityId ?? Guid.NewGuid(),
                ProvinceId = cityDetails.geo_provinceid.Id,
                Name = cityDetails.geo_name
            };

            return cityItem;
        }

        public List<ProvinceModel> GetProvinceStateList()
        {
            var canadaId = DataContext.geo_countrySet.FirstOrDefault(i => i.geo_name.Equals("Canada")).geo_countryId;
            var americaId = DataContext.geo_countrySet.FirstOrDefault(i => i.geo_name.Equals("USA")).geo_countryId;
            var provinceStatesList = DataContext.geo_provinceSet.ToList();
            var provinceStatesModelList = provinceStatesList.Where(i => i.geo_countryid.Id == canadaId || i.geo_countryid.Id == americaId).Select(e => GetProvinceStateModel(e)).ToList();
            return provinceStatesModelList.OrderBy(i => i.CountryId).ThenBy(i => i.Name).ToList();
        }

        /// <summary>
        /// This will transfer geo_province to ProvinceStateModel, save to cache. No Umbraco Content saved 
        /// </summary>
        /// <param name="provinceStateDetails">
        /// The province state details.
        /// </param>
        /// <returns>
        /// The <see cref="ProvinceModel"/>.
        /// </returns>
        public ProvinceModel GetProvinceStateModel(geo_province provinceStateDetails)
        {
            var country =
                DataContext.geo_countrySet.FirstOrDefault(i => i.geo_countryId == provinceStateDetails.geo_countryid.Id);

            var provinceStateItem = new ProvinceModel
            {
                ProvinceId = provinceStateDetails.geo_provinceId ?? Guid.NewGuid(),
                CountryId = country.geo_countryId.Value,
                CountryName=country.geo_name,
                Name = provinceStateDetails.geo_name,
                Abbreviation = provinceStateDetails.geo_abbreviation
            };

            return provinceStateItem;
        }

        #endregion

        #region Sponsors

        public List<SponsorshipModel> GetSponsorshipList()
        {
            return (
                from sponsorshipDetails in DataContext.ecc_sponsorshipSet
                join a in DataContext.AccountSet
                    on sponsorshipDetails.ecc_Account.Id equals a.AccountId
                where sponsorshipDetails.statecode==ecc_sponsorshipState.Active
                    select new SponsorshipModel
                    {
                        SponsorshipId = sponsorshipDetails.Id,
                        AccountId = sponsorshipDetails.ecc_Account.Id,
                        CompanyLogoUrl = a.ecc_CompanyLogoURL,
                        CompanyName = a.Name,
                        EventId = sponsorshipDetails.ecc_Event != null ? sponsorshipDetails.ecc_Event.Id : Guid.Empty,
                        EventName = sponsorshipDetails.ecc_Event != null ? sponsorshipDetails.ecc_Event.Name : "",
                        Details = sponsorshipDetails.ecc_Details,
                        DollarEquivalent = Convert.ToDouble(sponsorshipDetails.ecc_DollarEquivalent != null ? sponsorshipDetails.ecc_DollarEquivalent.Value : 0),
                        DollarEquivalentBase = Convert.ToDouble(sponsorshipDetails.ecc_dollarequivalent_Base != null ? sponsorshipDetails.ecc_dollarequivalent_Base.Value : 0),
                        Number = sponsorshipDetails.ecc_number,
                        CreatedDate=sponsorshipDetails.CreatedOn
                    }
                ).ToList();
            //= DataContext.ecc_sponsorshipSet.ToList();
            //var sponsorshipsModelList = sponsorshipList.Select(e => GetSponsorshipModel(e)).ToList();
            //return sponsorshipsModelList;
        }


        #endregion

        #region Attendees

        public List<Account> GetAttendees(Guid eventId, int numberToQuery = -1)
        {
            var attendees = (from r in DataContext.ecc_registrationSet
                             join a in DataContext.AccountSet on r.ecc_account.Id equals a.AccountId
                             where 
                                 r.ecc_Event.Id == eventId
                                 && r.ecc_displayinattendeelist.Value
                                 //&& a.ecc_listingtype != null 
                                 //&& a.ecc_listingtype.Value != (int)Accountecc_listingtype.Hidden 
                                 && a.ecc_accounttype.Value == (int)Accountecc_accounttype.Member
                             select a).Distinct();
            if(numberToQuery >= 0)
            {
                attendees = attendees.Take(numberToQuery);
            }

            return attendees.ToList();
        }

        public List<EventAttendeeAccountModel> GetAttendeesList(Guid eventId, int numberToQuery = -1)
        {
            //var attendees = (from r in DataContext.ecc_registrationSet
            //    join a in DataContext.AccountSet on r.ecc_account.Id equals a.AccountId
            //    where a.ecc_listingtype.Value != null && a.ecc_listingtype.Value != (int) Accountecc_listingtype.Hidden
            //          && a.ecc_accounttype.Value == (int) Accountecc_accounttype.Member
            //    select new EventAttendeeAccountModel {AccountId = a.AccountId.Value, AccountName = a.Name}).Distinct();

            var attendees = this.GetAttendees(eventId).Select(a => a.AccountId != null ? new EventAttendeeAccountModel {AccountId = a.AccountId.Value, AccountName = a.Name} : null);

            var distinctAttendees = this.GetDistinctAttendeeList(attendees.ToList());

            if (numberToQuery >= 0)
            {
                distinctAttendees = distinctAttendees.Take(numberToQuery).ToList();
            }
            return distinctAttendees;
        }

        /// <summary>
        /// For some reason, Distinct() is not workin on ths EventAttendeeAccountModel custom class?
        /// </summary>
        /// <param name="attendeeList"></param>
        /// <returns></returns>
        public List<EventAttendeeAccountModel> GetDistinctAttendeeList(List<EventAttendeeAccountModel> attendeeList)
        {
            var distinctAttendeeList = new List<EventAttendeeAccountModel>();
            foreach (var attendee in attendeeList)
            {
                if (!distinctAttendeeList.Select(i => i.AccountId).Contains(attendee.AccountId))
                {
                    distinctAttendeeList.Add(attendee);
                }
            }
            return distinctAttendeeList;
        }

        #endregion
        
        #region Speakers
        public List<EventSpeaker> GetSpeakers(Guid? eventId)
        {
            var eventSpeakers = new List<EventSpeaker>();

            if (eventId != null)
            {
                var eventNode = this.GetEventNode(eventId.ToString());
                if (eventNode != null)
                {
                    var speakerNodes = uQuery.GetNodesByType(DocumentTypes.eventSpeaker.ToString()).Where(i => i.Parent != null && i.Parent.Id == eventNode.Id).ToList();
                    if (speakerNodes.Any())
                    {
                        eventSpeakers.AddRange(speakerNodes.Select(i => i.GetSpeaker()));
                    }
                }
            }

            return eventSpeakers;
        }
        public List<ECC.Web.Helpers.CacheItemController.CachedUserEventModel> GetMemberEventHistory()
        {
            cache=new CacheItemController(this.service, this.DataContext);
            return cache.CachedUserEvent.UserEventList;
        }

        #endregion

        #region WebApis

        public string DiscountCheck(string DiscountCode, string EventGuid)
        {
            var discount = DataContext.ecc_discountSet.SingleOrDefault(
                                    m => m.ecc_Code == DiscountCode && (m.ecc_Events == null || m.ecc_Events.Id == new Guid(EventGuid)));
            if (discount != null)
            {
                if (discount.ecc_NumberofUses == null)
                {
                    discount.ecc_NumberofUses = 0;
                }
                if (discount.ecc_NumberofUses < discount.ecc_maximumuses)
                {
                    return discount.ecc_Amount;
                }
                return "max";
            }

            return "invalid";
        }

        #endregion
    }
}