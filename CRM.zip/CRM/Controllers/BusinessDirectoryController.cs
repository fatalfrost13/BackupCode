﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ECC.Web.Controllers
{
    using System.Configuration;

    using ECC.Web.Data.Crm;
    using ECC.Web.Extensions;
    using ECC.Web.Helpers;
    using ECC.Web.Models;
    using ECC.Web.SurfaceControllers;
    using IomerBase.Models;

    using Microsoft.Ajax.Utilities;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;

    using umbraco.NodeFactory;

    using log4net;

    public class BusinessDirectoryController : CrmController
    {
        private static readonly ILog Log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        private CacheItemController cache;

        public BusinessDirectoryController()
        {
            cache=new CacheItemController(this.service, this.DataContext);
        }

        public BusinessDirectoryController(IOrganizationService organizationService)
        {
            this.service = (OrganizationServiceProxy)organizationService;
            this.DataContext = new EccSvcContext(service);
            cache=new CacheItemController(this.service, this.DataContext);
        }

        public BusinessDirectoryController(IOrganizationService organizationService, EccSvcContext context)
        {
            this.service = (OrganizationServiceProxy)organizationService;
            this.DataContext = context;
            cache=new CacheItemController(this.service, this.DataContext);
        }

        //Used for Cache
        public List<AccountModel> GetAllAccounts()
        {
            
            // Force pre-cache of TimeZone conversion data
            DateTimeExtensions.CrmOrganizationService = this.service;
            var userSettings = DateTimeExtensions.CrmUserSettings;
            var userTimeZone = DateTimeExtensions.CrmTimeZoneInfo;
            
            // Retrieve option-set labels
            //var accountListingTypeOptions = this.service.GetOptionSetLabelsAndValues(Account.EntityLogicalName, "ecc_listingtype");

            // Retrieve related lookup sets
            var businessTypes = cache.CachedBusinessTypeList.BusinessTypes;
            var relationships = cache.AccountBusinessType.Relationships;

            // Load all Business Type relationships across all Accounts
            var accountBusinessTypeRelationships =
                (
                    from r in relationships
                    group r.BusinessTypeId by r.AccountId into g
                    select new
                    {
                        AccountId = g.Key,
                        BusinessTypes = g.Select(v => businessTypes.Single(bt => new Guid(bt.Value) == v)).ToList()
                    }
                )
                .ToDictionary(t => t.AccountId, t => t.BusinessTypes);
            
            // Retrieve CRM Account records
            var accounts =
                (
                    from a in this.DataContext.AccountSet
                    join c in this.DataContext.geo_citySet on a.ecc_city.Id equals c.geo_cityId.Value
                    join p in this.DataContext.geo_provinceSet on a.ecc_provincestate.Id equals p.geo_provinceId.Value
                    where
                        a.ecc_accounttype.Value == (int)Accountecc_accounttype.Member
                        && a.StateCode == AccountState.Active
                        && a.StatusCode.Value == (int)account_statuscode.Active
                    where
                        c.statecode == geo_cityState.Active
                    where
                        p.statecode == geo_provinceState.Active
                    select new
                    {
                        AccountId = a.AccountId.Value,
                        a.Name,
                        a.ecc_membershipstartdate,
                        a.ecc_membershipenddate,
                        a.ecc_listingtype,
                        a.ecc_accountdescription,
                        a.ecc_CompanyLogoURL,
                        a.ecc_autorenewal,
                        a.Address1_Line1,
                        a.Address1_Line2,
                        //ecc_cityId = a.ecc_city.Id,
                        a.ecc_city,
                        //ecc_provincestateId = a.ecc_provincestate.Id,
                        a.ecc_ispap,
                        a.ecc_isgroupinsurance,
                        a.ecc_provincestate,
                        a.Address1_PostalCode,
                        a.Telephone1,
                        a.EMailAddress1,
                        a.WebSiteURL,
                        a.ecc_featuredlisting,
                        a.ecc_Facebook,
                        a.ecc_Twitter,
                        a.ecc_LinkedIn,
                        a.ecc_youtube,
                        a.ecc_AdImageUrl,
                        a.ecc_AdLinkUrl,
                        a.ecc_accounttype,
                        a.ecc_representative
                    }
                )
                .ToList();

            /* Perform post-processing of CRM Account records to populate complex fields */
            var accountModelList = new List<AccountModel>();

            foreach (var account in accounts)
            {
                var accountModel = new AccountModel
                {
                    Id = account.AccountId,
                    AccountDescription = account.ecc_accountdescription,
                    CompanyLogoUrl = account.ecc_CompanyLogoURL,
                    AccountName = account.Name,
                    BusinessDirectory =
                        account.ecc_listingtype != null
                            ? account.ecc_listingtype.Value.ToString()
                            : string.Empty,
                    AutoRenew =
                        account.ecc_autorenewal != null
                        && account.ecc_autorenewal.Value,
                    ShowAddress =
                        account.ecc_listingtype == null
                        || account.ecc_listingtype.Value
                        != (int)Accountecc_listingtype.Limited,
                    Address1 = account.Address1_Line1,
                    Address2 = account.Address1_Line2,
                    CityId = account.ecc_city.Id,
                    City = account.ecc_city.Name,
                    IsGroupInsured = account.ecc_isgroupinsurance ?? false,
                    IsPAP = account.ecc_ispap ?? false,
                    ProvinceId = account.ecc_provincestate.Id,
                    Province=account.ecc_provincestate.Name,
                    PostCode = account.Address1_PostalCode,
                    Phone = account.Telephone1,
                    Email = account.EMailAddress1,
                    MembershipStart =
                        account.ecc_membershipstartdate != null
                            ? account.ecc_membershipstartdate.Value
                                .ConvertFromCrmDateTime(userTimeZone)
                            : (DateTime?)null,
                    MembershipExpiry =
                        account.ecc_membershipenddate != null
                            ? account.ecc_membershipenddate.Value
                                .ConvertFromCrmDateTime(userTimeZone)
                            : (DateTime?)null,
                    Website = account.WebSiteURL,
                    Featured =
                        account.ecc_featuredlisting != null
                        && account.ecc_featuredlisting.Value,
                    FaceBook = account.ecc_Facebook,
                    Twitter = account.ecc_Twitter,
                    LinkedIn = account.ecc_LinkedIn,
                    YouTube = account.ecc_youtube,
                    AdImageUrl = account.ecc_AdImageUrl??"",
                    AdLinkUrl=account.ecc_AdLinkUrl??"",
                    EccRepresentative=account.ecc_representative,
                    BusinessTypeList =
                        accountBusinessTypeRelationships.ContainsKey(account.AccountId)
                            ? accountBusinessTypeRelationships[account.AccountId]
                                .ToList()
                            : new List<GenericItem>()
                };
                accountModelList.Add(accountModel);
            }
            return accountModelList;

            //var accountList = DataContext.AccountSet.Where(a => a.ecc_accounttype.Value == (int)Accountecc_accounttype.Member && a.StatusCode.Value == (int)account_statuscode.Active).ToList();
            //var accountModelList = accountList.Select(e => GetAccountModel(e)).ToList();
            //return accountModelList;
        }

        //public AccountModel GetAccountModel(Account accountDetails)
        //{

        //    DateTime? localStartDate = accountDetails.ecc_membershipstartdate != null
        //        ? accountDetails.ecc_membershipstartdate.Value.ConvertFromCrmDateTime(this.service)
        //        : (DateTime?)null;
        //    DateTime? localEndDate = accountDetails.ecc_membershipenddate != null
        //        ? accountDetails.ecc_membershipenddate.Value.ConvertFromCrmDateTime(this.service)
        //        : (DateTime?)null;

        //    bool showAddr = accountDetails.ecc_listingtype==null || accountDetails.ecc_listingtype.Value != (int)Accountecc_listingtype.Limited;
        //    var accountItem = new AccountModel
        //    {
        //        Id = accountDetails.AccountId,
        //        AccountDescription = accountDetails.ecc_accountdescription ?? string.Empty,
        //        CompanyLogoUrl = accountDetails.ecc_CompanyLogoURL ?? string.Empty,
        //        AccountName = accountDetails.Name ?? string.Empty,
        //        BusinessDirectory = accountDetails.ecc_listingtype == null ? "" : accountDetails.ecc_listingtype.Value.ToString(),
        //        AutoRenew = accountDetails.ecc_autorenewal != null && accountDetails.ecc_autorenewal.Value,
        //        Address1 = accountDetails.Address1_Line1 != null && showAddr ? accountDetails.Address1_Line1 : string.Empty,
        //        Address2 = accountDetails.Address1_Line2 != null && showAddr ? accountDetails.Address1_Line2 : string.Empty,
        //        CityId = accountDetails.ecc_city != null ? accountDetails.ecc_city.Id.ToString() : "",
        //        ProvinceId = accountDetails.ecc_provincestate != null ? accountDetails.ecc_provincestate.Id.ToString() : "",
        //        PostCode = accountDetails.Address1_PostalCode != null && showAddr ? accountDetails.Address1_PostalCode : string.Empty,
        //        Phone = accountDetails.Telephone1 ?? string.Empty,
        //        Email = accountDetails.EMailAddress1 ?? string.Empty,
        //        MembershipStart = localStartDate,
        //        MembershipExpiry = localEndDate,
        //        Website = accountDetails.WebSiteURL ?? string.Empty,
        //        Featured = accountDetails.ecc_featuredlisting ?? false,
        //        //AccountContacts =  this.GetContactList(accountDetails),
        //        //AccountLocations = this.GetLocationList(accountDetails),
        //        FaceBook = accountDetails.ecc_Facebook ?? string.Empty,
        //        Twitter = accountDetails.ecc_Twitter ?? string.Empty,
        //        LinkedIn = accountDetails.ecc_LinkedIn ?? string.Empty,
        //        YouTube = accountDetails.ecc_youtube ?? string.Empty,
        //        IsMember = (accountDetails.ecc_accounttype.Equals(new OptionSetValue((int)Accountecc_accounttype.Member)))
        //    };

        //    //format website
        //    if (!string.IsNullOrEmpty(accountItem.Website) && !accountItem.Website.StartsWith("http://") && !accountItem.Website.StartsWith("https://"))
        //    {
        //        accountItem.Website = string.Format("http://{0}", accountItem.Website);
        //    }

        //    if (!String.IsNullOrEmpty(accountItem.CityId))
        //    {
        //        accountItem.City =
        //            cache.CachedCityList.CityList.ToList()
        //                .FirstOrDefault(c => c.Id == new Guid(accountItem.CityId)).geo_name;
        //    }

        //    if (!String.IsNullOrEmpty(accountItem.ProvinceId))
        //    {
        //        accountItem.Province =
        //                 cache.CachedProvinceStateList.ProvinceStateList.ToList()
        //                 .FirstOrDefault(p => p.ProvinceId == new Guid(accountItem.ProvinceId)).Name;
        //    }

        //    ////directory URL
        //    //var detailsNodeId = Int32.Parse(ConfigurationManager.AppSettings["businessDirectoryDetailId"]);
        //    //var detailNode = new Node(detailsNodeId);
        //    //if (detailNode.Id > 0)
        //    //{
        //    //    accountItem.DirectoryUrl = string.Format("{0}?accountId={1}", detailNode.Url, accountItem.Id);
        //    //}

        //    //todo load business types in cache
        //    var businessTypeList = new List<GenericItem>();
        //    //var existingBusinessTypeRelation =
        //    //    DataContext.ecc_account_ecc_businesstypeSet.Where(a => a.accountid == accountDetails.Id).ToList();
        //    //foreach (var relation in existingBusinessTypeRelation)
        //    //{
        //    //    var businessType = cache.CachedBusinessTypeList.BusinessTypes.SingleOrDefault(bt => new Guid(bt.Value) == relation.ecc_businesstypeid.Value);
        //    //    if (businessType.Value != null)
        //    //    {
        //    //        businessTypeList.Add(businessType);
        //    //    }
        //    //}
        //    var existingBusinessTypeRelation = cache.AccountBusinessType.Relationships.Where(i => i.AccountId == accountDetails.Id).ToList();
        //    foreach (var relation in existingBusinessTypeRelation)
        //    {
        //        var businessType = cache.CachedBusinessTypeList.BusinessTypes.SingleOrDefault(bt => new Guid(bt.Value) == relation.BusinessTypeId);
        //        if (businessType.Value != null)
        //        {
        //            businessTypeList.Add(businessType);
        //        }
        //    }
        //    accountItem.BusinessTypeList = businessTypeList;

        //    return accountItem;
        //}

        //public List<AccountContact> GetContactList(Account accountDetails)
        //{
        //    var contactList = cache.CachedContacts.ContactList.Where(c => c.ecc_Account.Id == accountDetails.Id).ToList();
        //    return contactList;
        //}

        public List<AccountLocation> GetLocationList(Account accountDetails)
        {
            var locationList =
                cache.CachedAccountLocations.LocationList.Where(l => l.AccountId == accountDetails.Id).ToList();
            return locationList;
        }

        /// <summary>
        /// Overload to Get Contact on demand.
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public List<AccountContact> GetContactList(Guid accountId)
        {
            var contactList = new List<AccountContact>();
            //var contactRelation = accountDetails.ecc_account_contact_Account;

            var contacts = DataContext.ContactSet.Where(i => i.ecc_Account.Id == accountId);
            foreach (var contact in contacts)
            {
                if (contact != null)
                {
                    //var contact = DataContext.ContactSet.SingleOrDefault(i => i.Id == relation.ContactId);
                    var contactType = string.Empty;
                    if (contact.ecc_ContactType != null)
                    {
                        var contactTypeValue = new OptionSetValue(contact.ecc_ContactType.Value);
                        contactType = service.GetOptionSetValueLabel(new Entity(Contact.EntityLogicalName), "ecc_contacttype", contactTypeValue);
                    }
                    var contactItem = new AccountContact
                    {
                        FirstName = contact.FirstName,
                        LastName = contact.LastName,
                        JobTitle = contact.JobTitle,
                        Email = contact.EMailAddress1,
                        MainContact = contact.ecc_MainContact ?? false,
                        Phone = contact.Telephone1,
                        ContactType = contactType
                    };
                    contactList.Add(contactItem);
                }
            }
            return contactList;
        }

        /// <summary>
        /// Overload to get Location on demand.
        /// </summary>
        /// <param name="accountId"></param>
        /// <returns></returns>
        public List<AccountLocation> GetLocationList(Guid accountId)
        {
            var locationList = new List<AccountLocation>();

            var locations = DataContext.CustomerAddressSet.Where(i => i.Account_CustomerAddress.AccountId.Value == accountId && i.AddressNumber > 2);   //first 2 addresses are the default address1/addres2 fields in the accounts.
            //var accountAddressRelation = accountDetails.Account_CustomerAddress;

            foreach (var location in locations)
            {
                if (location != null)
                {
                    //var location = DataContext.AccountSet.SingleOrDefault(i => i.Id == relation.CustomerAddressId);
                    var locationItem = new AccountLocation
                    {
                        LocationName = location.Name,
                        AddressLine1 = location.Line1,
                        City = location.City,
                        Country = location.Country,
                        Fax = location.Fax,
                        MainPhone = location.Telephone1,
                        Phone2 = location.Telephone2,
                        PostalZip = location.PostalCode,
                        ProvState = location.StateOrProvince,
                        Website = location.ecc_website
                    };
                    locationList.Add(locationItem);
                }
            }
            return locationList;
        }
    }
}
