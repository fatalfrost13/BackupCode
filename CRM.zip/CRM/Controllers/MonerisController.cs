﻿namespace ECC.Web.Controllers
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using Moneris.Data;
    using Moneris.Data.Models;

    using ECC.Web.Data.Crm;

    public class MonerisController
    {
        /********************* Post Request Variables ********************************/
        private readonly string host;
        private readonly string storeId;
        private readonly string apiToken;

        /********************* Transactional Variables *******************************/
        private string orderId;
        private string custId;
        private string amount;
        private string card;
        private string nameOnCard;
        private string expDateStr;
        private string cvd;
        private string cryptKeyCode;
        private string tax1Federal;
        private string tax2Prov;
        private string tax3Luxury;
        private string shippingCost;
        private string eventTitle;

        /********************* User Info Variables ****************************/
        private string firstName;
        private string lastName;
        private string companyName;
        private string address;
        private string city;
        private string province;
        private string postCode;
        private string country;
        private string phone;
        private string fax;
        private string email;

        private MonerisRecurringTransaction _recurringTransaction;

        public MonerisController(string host, string storeId, string apiToken)
        {
            this.host = host;
            this.storeId = storeId;
            this.apiToken = apiToken;
        }
        public MonerisController()
        {
            host = ConfigurationManager.AppSettings["monerisHost"];
            storeId = ConfigurationManager.AppSettings["monerisStoreId"];
            apiToken = ConfigurationManager.AppSettings["monerisApiToken"];
        }


        public void SetUserInfo(string firstName, string lastName, string companyName, string address, string city, string province,
            string postCode, string country, string phone, string fax, string email)
        {
            this.firstName = firstName ?? "";
            this.lastName = lastName ?? "";
            this.companyName = companyName ?? "";
            this.address = address ?? "";
            this.city = city ?? "";
            this.province = province ?? "";
            this.postCode = postCode ?? "";
            this.country = country ?? "";
            this.phone = phone ?? "";
            this.fax = fax ?? "";
            this.email = email ?? "";
        }

        public void SetNewTransaction(string orderId, string amount, string card, string nameOnCard, string expDateStr, string cvd, string tax1Federal,
            string tax2Prov, string tax3Luxury, string shippingCost, string eventTitle, MonerisRecurringTransaction recurringTransaction = null)
        {
            this.orderId = orderId ?? "";
            this.custId = "";
            this.amount = amount ?? "";
            this.amount = this.amount.Trim().Replace(",", "").Replace("$", "");
            if (!this.amount.Contains(".")) this.amount += ".00";

            this.card = card ?? "";
            this.card = this.card.Replace(" ", "").Replace("-", "");

            this.nameOnCard = nameOnCard ?? "";

            this.expDateStr = expDateStr ?? "";
            this.cvd = cvd ?? string.Empty;

            cryptKeyCode = "7";

            this.tax1Federal = tax1Federal ?? "";
            this.tax1Federal = this.tax1Federal.Trim().Replace(",", "").Replace("$", "");
            if (!this.tax1Federal.Contains(".")) this.tax1Federal += ".00";

            this.tax2Prov = tax2Prov ?? "";
            this.tax2Prov = this.tax2Prov.Trim().Replace(",", "").Replace("$", "");
            if (!this.tax2Prov.Contains(".")) this.tax2Prov += ".00";

            this.tax3Luxury = tax3Luxury ?? "";
            this.tax3Luxury = this.tax3Luxury.Trim().Replace(",", "").Replace("$", "");
            if (!this.tax3Luxury.Contains(".")) this.tax3Luxury += ".00";
            this.shippingCost = shippingCost ?? "";

            this.eventTitle = eventTitle ?? "";

            if (recurringTransaction != null)
            {
                _recurringTransaction = recurringTransaction;
            }
        }

        public MonerisResponse ProcessMonerisTransaction()
        {
            var monerisContact = new MonerisContact
            {
                FirstName = firstName,
                LastName = lastName,
                CompanyName = companyName,
                Address = address,
                City = city,
                Province = province,
                PostCode = postCode,
                Country = country,
                Phone = phone,
                Fax = fax,
                Email = email,
            };

            var billingInfo = new MonerisBillingInformation
            {
                Contact = monerisContact,
                ShippingCost = Convert.ToDecimal(shippingCost),
                Tax1 =
                    !string.IsNullOrEmpty(tax1Federal)
                        ? Convert.ToDecimal(tax1Federal)
                        : 0,
                Tax2 =
                    !string.IsNullOrEmpty(tax2Prov)
                        ? Convert.ToDecimal(tax2Prov)
                        : 0,
                Tax3 =
                    !string.IsNullOrEmpty(tax3Luxury)
                        ? Convert.ToDecimal(tax3Luxury)
                        : 0
            };

            var orderItem = new MonerisOrderLineItem { ItemName = eventTitle, Quantity = 1 };

            var cardVerfication = !string.IsNullOrEmpty(cvd)
                                      ? new MonerisCardVerification { CvdIndicator = 1, CvdValue = cvd }
                                      : null;

            var addressVerification = new MonerisAddressVerification { StreetName = address, StreetNumber = string.Empty, ZipCode = postCode }; 

            //var recurringTransaction = new MonerisRecurringTransaction
            //{
            //    Frequency = RecurringFrequency.Month,
            //    StartNow = true,
            //    //StartDate = DateTime.Now.AddMonths(12),
            //    RecurringCount = 99,
            //    Period = 12,
            //    RecurringAmount = Convert.ToDecimal(amount)
            //};

            //Purchase purchase = new Purchase(orderId, custId, amount, card, expDateStr, cryptKeyCode);
            var monerisTransaction = new MonerisTransaction
            {
                OrderId = orderId,
                CustId = custId,
                Amount = Convert.ToDecimal(amount),
                CreditCardNumber = card,
                NameOnCard = nameOnCard,
                ExpiryDate = expDateStr,
                RecurringTransaction = _recurringTransaction,
                Crypt = int.Parse(cryptKeyCode),
                BillingInformation = billingInfo,
                OrderLineItems = new List<MonerisOrderLineItem> { orderItem },
                CardVerification = cardVerfication,
                AddressVerification = addressVerification
            };

            var monerisService = new MonerisTransactionController(host, storeId, apiToken);
            var monerisResponse = monerisService.ProcessTransaction(monerisTransaction);
            return monerisResponse;
        }
    }
}