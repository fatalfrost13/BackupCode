﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ECC.Web.SurfaceControllers
{
    using System.Collections.Specialized;
    using MVCCrm.CrmCore;
    using ECC.Web.Data.Crm;
    using Microsoft.Xrm.Sdk;
    using Microsoft.Xrm.Sdk.Client;
    using Microsoft.Crm.Sdk.Messages;

    public abstract class CrmController : Umbraco.Web.Mvc.SurfaceController
    {
        readonly CrmConnectionManager crmManager = new CrmConnectionManager();

        private EccSvcContext _DataContext;
        public EccSvcContext DataContext
        {
            get
            {
                return this._DataContext
                       ?? (this._DataContext = new EccSvcContext(this.crmManager.GetOrganizationService()));
            }
            set
            {
                _DataContext = value;
            }
        }

        private OrganizationServiceProxy _service;
        public OrganizationServiceProxy service
        {
            get
            {
                return this._service ?? (this._service = this.crmManager.GetOrganizationService());
            }
            set
            {
                _service = value;
            }
        }


        public CrmController()
        {
        }

        public CrmController(IOrganizationService organizationService)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = new EccSvcContext(service);
        }

        public CrmController(IOrganizationService organizationService, EccSvcContext context)
        {
            service = (OrganizationServiceProxy)organizationService;
            DataContext = context;
        }
    }
}